-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)
local roar = keybinds:newKeybind("ROAR!", "key.keyboard.down")

function events.tick()
    local crouching = player:getPose() == "CROUCHING"
    -- This is the same line of code from the previous example
    local walking = player:getVelocity().xz:length() > .01
    -- walking == true when moving, and walking == false when still (or going directly up/down as we excluded the y axis)
    local sprinting = player:isSprinting()
    -- If you want to find more player functions, check out the Player Global page

    -- Now we're going to use a lot of logic to figure out when animations should/shouldn't play
    animations.model.Idle:setPlaying(not walking and not crouching)
    -- You're idle when not walking and not crouching
    animations.model.Walk:setPlaying(walking and not crouching and not sprinting)
    -- You're walking when... walking and not crouching, but you want to make sure you're not sprinting either
    animations.model.Sprint:setPlaying(sprinting and not crouching)
    -- You probably can catch my drift by now
    animations.model.Crouch:setPlaying(crouching)
end

function pings.playRoar(sound)
    if player:isLoaded() then
      sounds:playSound("roar", player:getPos(), 8, 1, false)
      animations.model.Roar:play()
    end
  end

function events.tick()
models:setPos(player:getVehicle() and vec(0,-6,0) or nil)
end

roar.press = function() pings.playRoar("roar") end