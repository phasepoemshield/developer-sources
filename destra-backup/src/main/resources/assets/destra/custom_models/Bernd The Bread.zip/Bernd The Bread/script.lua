-- Skin made by 'Dreaming_Moon'

vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
vanilla_model.PLAYER:setVisible(false)



function events.render()
    if player:isCrouching() then
		models.model.root.Body:setPos(0,-1.5,-2.5)
		models.model.root.LeftArm:setPos(0,1.5,2)
		models.model.root.RightArm:setPos(0,1.5,2)
	else
		models.model.root.Body:setPos(0,0,0)
		models.model.root.LeftArm:setPos(0,0,0)
		models.model.root.RightArm:setPos(0,0,0)
	end
end