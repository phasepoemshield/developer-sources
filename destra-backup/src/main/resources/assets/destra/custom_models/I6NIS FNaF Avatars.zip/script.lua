vanilla_model.PLAYER:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.HELMET:setVisible(true)

nameplate.ENTITY:setPos(vec(0,0.6,0))

--too lazy to learn how to have prettier script n shit n uhhgh so this is just setting the default to freddy manually
models.Freddy:setVisible(true)
models.Bonnie:setVisible(false)
models.Chica:setVisible(false)
models.Foxy:setVisible(false)
models.Freddy.Skull:setVisible(true)
models.Bonnie.Skull:setVisible(false)
models.Chica.Skull:setVisible(false)
models.Foxy.Skull:setVisible(false)

local anims = require("JimmyAnims")
anims(animations.Freddy)
local anims = require("JimmyAnims")
anims(animations.Bonnie)
local anims = require("JimmyAnims")
anims(animations.Chica)
local anims = require("JimmyAnims")
anims(animations.Foxy)

local fnafPage = action_wheel:newPage()

action_wheel:setPage(fnafPage)

local action = fnafPage:newAction()
    :title("CHICA")
    :item("minecraft:yellow_wool")
    :hoverColor(1, 0, 1)
    :onLeftClick(function()
models.Freddy:setVisible(false)
models.Bonnie:setVisible(false)
models.Chica:setVisible(true)
models.Foxy:setVisible(false)
models.Freddy.Skull:setVisible(false)
models.Bonnie.Skull:setVisible(false)
models.Chica.Skull:setVisible(true)
models.Foxy.Skull:setVisible(false)
    end)

local action = fnafPage:newAction()
    :title("FOXY")
    :item("minecraft:red_wool")
    :hoverColor(1, 0, 1)
    :onLeftClick(function()
models.Freddy:setVisible(false)
models.Bonnie:setVisible(false)
models.Chica:setVisible(false)
models.Foxy:setVisible(true)
models.Freddy.Skull:setVisible(false)
models.Bonnie.Skull:setVisible(false)
models.Chica.Skull:setVisible(false)
models.Foxy.Skull:setVisible(true)
    end)

local action = fnafPage:newAction()
    :title("BONNIE")
    :item("minecraft:purple_wool")
    :hoverColor(1, 0, 1)
    :onLeftClick(function()
models.Freddy:setVisible(false)
models.Bonnie:setVisible(true)
models.Chica:setVisible(false)
models.Foxy:setVisible(false)
models.Freddy.Skull:setVisible(false)
models.Bonnie.Skull:setVisible(true)
models.Chica.Skull:setVisible(false)
models.Foxy.Skull:setVisible(false)
    end)

local action = fnafPage:newAction()
    :title("FREDDY")
    :item("minecraft:brown_wool")
    :hoverColor(1, 0, 1)
    :onLeftClick(function()
models.Freddy:setVisible(true)
models.Bonnie:setVisible(false)
models.Chica:setVisible(false)
models.Foxy:setVisible(false)
models.Freddy.Skull:setVisible(true)
models.Bonnie.Skull:setVisible(false)
models.Chica.Skull:setVisible(false)
models.Foxy.Skull:setVisible(false)
    end)

--remove the '--' on the next line to be at animatronic eye-level!!
--renderer:setOffsetCameraPivot(0, 0.6, 0)

function events.item_render(item)
    if item:getName() == "Mic" then
        return models.Freddy.ItemMic
    end
end

function events.item_render(item)
    if item:getName() == "Cupcake" then
        return models.Chica.ItemCupcake
    end
end