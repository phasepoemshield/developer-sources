local visual = {}

local sync = require("layveri").sync
local prototype_pain = require("prototype_pain")

local Updates = true

visual.face = {}

local head_targets = {models.model.root.Frame.Head.Head, models.model.root.Frame.Head.HeadLayer}
local mouth_targets = {models.model.root.Frame.Head.Snout, models.model.root.Frame.Head.SnoutLayer}

visual.face.eyes ={
    normal = {id="normal",uvX = 0, uvY = 0, blinkable = true},
    narrow = {id="narrow",uvX = 1, uvY = 0, blinkable = true},
    panic = {id="panic",uvX = 2, uvY = 0},
    closed = {id="closed",uvX = 3, uvY = 0},
    cry = {id="cry",uvX = 4, uvY = 0, blinkable = true},
    scared = {id="scared",uvX = 5, uvY = 0, blinkable = true}
}
sync.current_eyes = visual.face.eyes.normal

visual.face.mouths = {
    closed = {uvX = 0, uvY = 0},
    open = {uvX = 1, uvY = 0}
}
sync.current_mouth = visual.face.mouths.closed


function visual.setFaceEyes(eye)
    sync.current_eyes = eye
    for _, target in ipairs(head_targets) do
        target:setUVPixels(sync.current_eyes.uvX * 34,
            sync.current_eyes.uvY * 38)
    end
end

function visual.setFaceMouth(mouth)
    sync.current_mouth = mouth
    for _, target in ipairs(mouth_targets) do
        target:setUVPixels(sync.current_mouth.uvX * 34,
            sync.current_mouth.uvY * 38)
    end
end


function isTheSameEyes(eyes)
    return  sync.current_eyes.id== eyes.id
end



function visual:setAutoUpdate(value)
    Updates = value;
    return self; 
end
function visual:toggleAutoUpdate()
    Updates = not Updates
    return self
end

local timer = 0
local eye_scare_time = 0
local eye_close_time = 0
local eye_cry_time = 0
local eye_panic_time = 0
local whimperTimer = 0

local function lerp(a, b, t)
    return a + (b - a) * t
end

function linearMin(x)
    if x <= 20 then
        return 400
    elseif x <= 100 then
        local t = (x - 20) / (100 - 20)
        return lerp(400, 60, t)
    elseif x < 140 then
        local t = (x - 100) / (140 - 100)
        return lerp(60, 50, t)
    else
        return 50
    end
end

function linearMax(x)
    if x <= 20 then
        return 500
    elseif x <= 100 then
        local t = (x - 20) / (100 - 20)
        return lerp(500, 120, t)
    elseif x < 140 then
        local t = (x - 100) / (140 - 100)
        return lerp(120, 100, t)
    else
        return 100
    end
end

local previous_eyes 
function events.tick()
    timer = timer + 1
    if timer>200 then
        timer = 0
    end
    if eye_close_time>0 then
        eye_close_time = eye_close_time-1
    end
    if eye_scare_time>0 then
        eye_scare_time = eye_scare_time-1
    end
    if eye_cry_time>0 then
        eye_cry_time = eye_cry_time-1
    end
    if eye_panic_time>0 then
        eye_panic_time = eye_panic_time-1
    end
    if Updates and prototype_pain:GetData()~=nil then
        if not player:isLoaded() then
            return
        end
        setupLimbSprites()
        if whimperTimer>0 then
            whimperTimer = whimperTimer-1
        elseif prototype_pain:GetData().TotalPain>20 and prototype_pain:GetData().Consciousness>30 then
                local pain =prototype_pain:GetData().TotalPain  
                local minVal = linearMin(pain)
                local maxVal = linearMax(pain)
                local timer = math.random() * (maxVal - minVal) + minVal
                whimperTimer =timer
                pings.painWhine()
        end
    end
    if animations.model.blink:isPlaying() then
        if previous_eyes==nil then
            previous_eyes =  sync.current_eyes;
        end
        if not isTheSameEyes(visual.face.eyes.closed) then
            visual.setFaceEyes(visual.face.eyes.closed)
        end
        return
    end
    if previous_eyes~=nil  then
        visual.setFaceEyes(previous_eyes)
        previous_eyes = nil
    end
    if Updates and prototype_pain:GetData()~=nil then
        if not player:isLoaded() then
            return
        end
        updateSprites()
        setupLimbSprites()
    end
    
end
function updateSprites()
    local Data = prototype_pain:GetData();
        local Consciousness = Data.Consciousness
        local Pain = Data.TotalPain
        local Hunger = player:getFood()
        local isBreating = Data.isBreathing
        local Adrenaline = Data.Adrenaline
        local Temp = Data.Temperature
        local Bleed = Data.TotalBleed
        local vertical_vel = player:getVelocity().y
        if ((vertical_vel<-2 or Pain>95) and Consciousness>30 ) then
            if not isTheSameEyes(visual.face.eyes.panic) then
                visual.setFaceEyes(visual.face.eyes.panic)
                visual.setFaceMouth(visual.face.mouths.open)
            end
        elseif (Consciousness<30 or Hunger<5)  then
            if not isTheSameEyes(visual.face.eyes.closed) then
                visual.setFaceEyes(visual.face.eyes.closed)
                visual.setFaceMouth(visual.face.mouths.closed)
            end
        elseif Pain>=70 then
            if not isTheSameEyes(visual.face.eyes.cry) then
                visual.setFaceEyes(visual.face.eyes.cry)
                visual.setFaceMouth(visual.face.mouths.closed)
            end
        elseif (Adrenaline>20 or isBreating~=1 or Bleed>0.3 or Pain>50 or vertical_vel<-1) then
            if not isTheSameEyes(visual.face.eyes.scared) then
                visual.setFaceEyes(visual.face.eyes.scared)
                visual.setFaceMouth(visual.face.mouths.closed)
            end
        elseif (Consciousness<70 or Hunger<10 or Pain>35 or Temp>40 or Temp<32) then 
            if not isTheSameEyes(visual.face.eyes.narrow) then
                visual.setFaceEyes(visual.face.eyes.narrow)
                visual.setFaceMouth(visual.face.mouths.closed)
            end
            
        elseif not isTheSameEyes(visual.face.eyes.normal) then
            visual.setFaceEyes(visual.face.eyes.normal)
            visual.setFaceMouth(visual.face.mouths.closed)
        end
end

local Larm_targets = {models.model.root.Frame.LeftArm.LeftArmLayerOverlay}
local Lhand_targets  = {models.model.root.Frame.LeftArm.LeftArmHand.LeftArmHandLayerOverlay}
local Rarm_targets  = {models.model.root.Frame.RightArm.RightArmLayerOverlay}
local Rhand_targets  = {models.model.root.Frame.RightArm.RightArmHand.RightArmHandLayerOverlay}     
local Head_targets  = {models.model.root.Frame.Head.HeadLayerOverlay,models.model.root.Frame.Head.SnoutLayerOverlay,models.model.root.Frame.Head.BackHeadLayerOverlay}
local Torso_targets  = {models.model.root.Frame.Body.BodyLayerOverlay,models.model.root.Frame.Body.LowerBodyLayerOverlay}
local LLeg_targets  = {models.model.root.LeftLeg.OverlayLayer}
local RLeg_targets  = {models.model.root.RightLeg.OverlayLayer}
local LFoot_targets  = {models.model.root.LeftLeg.LeftCalf.OverlayLayer,models.model.root.LeftLeg.LeftCalf.LeftFoot.OverlayLayer}
local RFoot_targets  = {models.model.root.RightLeg.RightCalf.OverlayLayer,models.model.root.RightLeg.RightCalf.RightFoot.OverlayLayer}
local limbTargets = {
    LArm =Larm_targets,
    LHand = Lhand_targets,
    RArm = Rarm_targets,
    RHand = Rhand_targets,
    Head =Head_targets,
    Torso = Torso_targets,
    LLeg =LLeg_targets,
    RLeg =RLeg_targets,
    LFoot =LFoot_targets,
    RFoot =RFoot_targets
}
damage = {}
damage.skin ={
    none = {uvX=0,uvY=0,id=0},
    light = {uvX=1,uvY=0,id=1},
    medium = {uvX=2,uvY=0,id=2},
    heavy = {uvX=3,uvY=0,id=3},
    full = {uvX=4,uvY=0,id=4},
}
sync.current_Limbs ={
    LHand = damage.skin.none.id,
    RHand = damage.skin.none.id,
    LArm = damage.skin.none.id,
    RArm = damage.skin.none.id,
    Torso = damage.skin.none.id,
    Head = damage.skin.none.id,
    LLeg = damage.skin.none.id,
    RLeg = damage.skin.none.id,
    LFoot = damage.skin.none.id,
    RFoot = damage.skin.none.id
}

function getFromId(id)
    for key, value in pairs(damage.skin) do
        if value.id == id then
            return value
        end
    end
end

function isTheSametable(eyes)
    for key, value in pairs(sync.current_Limbs) do  
        if eyes[key]~=value then
            
            return false
            
        end
        
    end
    return true
end

local function copyTable(t)
    local new = {}
    for k, v in pairs(t) do
        new[k] = v
    end
    return new
end

function setupLimbSprites()
    local Data = prototype_pain:GetData();
    local Limbs = Data.Limbs
    local srcData = copyTable(sync.current_Limbs)
    for key, value in pairs(Limbs) do
        
        local SkinScale = value.SkinHealth
        local skinDmg = damage.skin.none.id
        if SkinScale<20 then
            skinDmg = damage.skin.full.id
        elseif SkinScale<40 then
            skinDmg = damage.skin.heavy.id
        elseif SkinScale<60 then
            skinDmg = damage.skin.medium.id
        elseif SkinScale<80 then
            skinDmg = damage.skin.light.id
        end
        if key=="RIGHT_HAND" then
            srcData.RHand = skinDmg 
        elseif key=="RIGHT_LEG" then
            srcData.RLeg = skinDmg 
        elseif key=="CHEST" then
            srcData.Torso = skinDmg 
        elseif key=="HEAD" then
            srcData.Head = skinDmg 
        elseif key=="LEFT_FOOT" then
            srcData.LFoot = skinDmg 
        elseif key=="LEFT_ARM" then
            srcData.LArm = skinDmg 
        elseif key=="LEFT_LEG" then
            srcData.LLeg = skinDmg 
        elseif key=="LEFT_HAND" then
            srcData.LHand = skinDmg 
        elseif key=="RIGHT_FOOT" then
            srcData.RFoot = skinDmg 
        elseif key=="RIGHT_ARM" then
            srcData.RArm = skinDmg 
        end
    end
    if not isTheSametable(srcData) then
        sync.current_Limbs = srcData
        triggerUpdate()
    end
end

function triggerUpdate()
    syncData = sync.current_Limbs;
    for key, value in pairs(syncData) do
        local id = syncData[key] 
        local sprite = getFromId(id)
        for _, target in ipairs(limbTargets[key]) do
            
            target:setUVPixels(sprite.uvX * 24,
            sprite.uvY * 21)
        end
    end
end

function events.render(delta, context)
    if timer%200==0 and sync.current_eyes.blinkable then
        animations.model.blink:play()
    end
end

function pings.painWhine()
    local number = math.floor((math.random()*5)+1)
    if number<5 then
        sounds["sounds.pain"..number]:setSubtitle("Experiment Whipmers"):setPos(player:getPos()):setAttenuation(32):setVolume(2):setPitch(1):play()
    else
        sounds["sounds.bark"]:setSubtitle("Experiment Barks"):setPos(player:getPos()):setAttenuation(16):setVolume(2):setPitch(0.8 + math.random() * (1.2 - 0.8)):play()
    end
end

function pings.bark()
    sounds["sounds.bark"]:setSubtitle("Experiment Barks"):setPos(player:getPos()):setAttenuation(16):setVolume(2):setPitch(0.8 + math.random() * (1.2 - 0.8)):play()
end



















return visual