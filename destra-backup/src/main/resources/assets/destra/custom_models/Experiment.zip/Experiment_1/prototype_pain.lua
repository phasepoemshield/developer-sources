
local prototype_pain = {}
local Data = {}
local WasLogged = false

function events.tick()
    if player:isLoaded() then
            local success, result = pcall(function()
            return player:getNbt()
        end)

        if success and result and result.ForgeCaps and result.ForgeCaps["prototype_pain:properties"] then
            local nbt = result.ForgeCaps["prototype_pain:properties"]
            Data = {
            Oxygen = nbt.Oxygen,
            Consciousness = nbt.Consciousness,
            Adrenaline = nbt.Adrenaline,
            BrainHealth = nbt.BrainHealth,
            Blood = nbt.Blood,
            Dirtyness = nbt.Dirty,
            Temperature = nbt.Temp,
            TotalPain = nbt.TotalPain,
            Opioids = nbt.Opioids,
            isBreathing = nbt.IsBreathing,
            TotalBleed = TotalBleed(nbt.LimbStats);
            Limbs = ConvertToUsable(nbt.LimbStats);
            WasLogged = false
        }
        else
            if not WasLogged then
                log("Skipping ForgeCaps read (unavailable or unsafe to serialize)")
                WasLogged = true
            end
            Data = nil
        end

    end
end

function ConvertToUsable(arr)
    local out = {}
    for i, value in pairs(arr) do
        local Name = value.LimbName
        out[Name] = {
            SkinHealth = value.SkinHealth,
            Pain = value.FinalPain,
            Infection = value.Infection,
            HasSplint = value.HasSplint,
            HasTourniquet = value.Tourniquet,
            Shrapnel = value.Shrapnell,
            MuscleHealth = value.MuscleHealth,
            BleedRate = value.BleedRate,
            Amputated = value.Amputated,
            Fracture = value.FractureTimer
        }
    end
    return out
end

function TotalBleed(arr)
    local out = 0
    for key, value in pairs(arr) do
        out = out+ value.BleedRate
    end
    return out*20*60
end

function prototype_pain:GetData()
    return Data
end


return prototype_pain