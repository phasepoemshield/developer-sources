--[[
    Layveri (Les Veriables) by TaiAurori
    https://codeberg.org/TaiAurori/Layveri

    This module provides a simple way to replicate variables
    across clients without the need to manually make ping
    functions for each one.
]]

local __sync = {}
local sync = setmetatable({}, {
    __newindex = function(t, name, value)
        local key = "_lvri_set_"..name

        if not pings[key] then
            pings[key] = function(data)
                __sync[key] = data
            end
            __sync[key] = value
        end

        if host:isHost() then
            if __sync[key] ~= value then
                pings[key](value)
            end
            __sync[key] = value
        end
    end,

    __index = function(self, name)
        return __sync["_lvri_set_"..name]
    end
})

return { sync = sync }
