-- Auto generated script file --
local EZanim = require("EZAnims")
local GSAnim = require("GSAnimBlend")

local squapi = require("SquAPI")
--hide vanilla model
vanilla_model.PLAYER:setVisible(false)


--hide vanilla armor model
--vanilla_model.ARMOR:setVisible(false)
--re-enable the helmet item
vanilla_model.HELMET:setVisible(true)
--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
  --player functions goes here
  animations.model.walk:setBlendTime(4,1)
  animations.model.sprint:setBlendTime(4,1)
  animations.model.crouchwalk:setBlendTime(4,1)
  models.model.root.Frame.Head.HelmetPivot:setScale(1.15,1,1.15)
  vanilla_model.CHESTPLATE:setVisible(true)
  models.model.root.Frame.Body.ChestplatePivot:setScale(1,1,1.3)
  models.model.root.Frame.Body.LeggingsPivot:setScale(1.4,1,1.45)
  models.model.root.LeftLeg.LeftLeggingPivot:setScale(1.3,0.6,1.3)
  models.model.root.RightLeg.RightLeggingPivot:setScale(1.3,0.6,1.3)
  
  models.model.root.LeftLeg.LeftCalf.LeftFoot.LeftBootPivot:setScale(1.0,0.6,1.2)
  models.model.root.RightLeg.RightCalf.RightFoot.RightBootPivot:setScale(1.0,0.6,1.2)
end

function events.render(delta, context)
    if player:isCrouching() then
        models.model.root:setPos(0, 2.5, 0)
        models.model.root.Frame.Body:setPos(0, 1.5, -5.5)
        models.model.root.Frame.RightArm:setPos(0, 1.5, -4.5)
        models.model.root.Frame.LeftArm:setPos(0, 1.5, -4.5)
        models.model.root.Frame.Head:setPos(0, -2, -5.5)
        models.model.root.Frame:setPos(0, 0, 5)
        models.model.root.Frame.RightArm:setRot(10, 0, 0)
        models.model.root.Frame.LeftArm:setRot(10, 0, 0)
        models.model.root.Frame.Body.Tail:setRot(60, 0, 0)
        models.model.root.Frame.RightArm.RightArmHand:setPos(0,3.5,0)
        models.model.root.Frame.LeftArm.LeftArmHand:setPos(0,3.5,0)
        models.model.root.Frame.RightArm.RightArmHand:setRot(10,0,-10)
        models.model.root.Frame.LeftArm.LeftArmHand:setRot(10,0,10)
        models.model.root.Frame.Head.HelmetPivot:setPos(0,4,-0.2)
    else
        models.model.root:setPos(0, 0, 0)
        models.model.root.Frame.Body:setPos(0, 0, 0)
        models.model.root.Frame.RightArm:setPos(0, 0, 0)
        models.model.root.Frame.LeftArm:setPos(0, 0, 0)
        models.model.root.Frame.Head:setPos(0, 0, 0)
        models.model.root.Frame:setPos(0, 0, 0)
        models.model.root.Frame.RightArm:setRot(0, 0, 7.5)
        models.model.root.Frame.LeftArm:setRot(0, 0, -7.5)
        models.model.root.Frame.Body.Tail:setRot(30, 0, 0)
        models.model.root.Frame.RightArm.RightArmHand:setPos(0,0,0)
        models.model.root.Frame.LeftArm.LeftArmHand:setPos(0,0,0)
        models.model.root.Frame.RightArm.RightArmHand:setRot(0,0,-10)
        models.model.root.Frame.LeftArm.LeftArmHand:setRot(0,0,10)
        models.model.root.Frame.Head.HelmetPivot:setPos(0,0,0)
    end
    animations.model.crawl:setSpeed(player:getVelocity().xz:length())
    animations.model.swim:setSpeed(player:getVelocity().xz:length())
    animations.model.walk:setSpeed(player:getVelocity().xz:length()*3.5)
    animations.model.sprint:setSpeed(player:getVelocity().xz:length()*3.5)
end

squapi.smoothHead:new(
    {
        models.model.root.Frame.Head,
        models.model.root.Frame,
    },
	{
        0.75,
        0.25,
    },    --(1) strength(you can make this a table too)
    0.2,    --(0.1) tilt
    2.5,    --(1) speed
    nil,     --(true) keepOriginalHeadPos
    false
)

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)

