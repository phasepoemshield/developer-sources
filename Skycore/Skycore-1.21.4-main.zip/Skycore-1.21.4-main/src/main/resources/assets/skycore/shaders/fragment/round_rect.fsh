#version 150

in vec2 texCoord;
out vec4 fragColor;

uniform vec2 location, rectSize;
uniform vec4 color;
uniform float radius;

float roundSDF(vec2 p, vec2 b, float r) {
    return length(max(abs(p) - b, 0.0)) - r;
}

void main() {
    vec2 rectHalf = rectSize * .5;
    float smoothedAlpha = (1. - smoothstep(0.0, 1., roundSDF(rectHalf - (texCoord * rectSize), rectHalf - radius - 1., radius))) * color.a;
    fragColor = vec4(color.rgb, smoothedAlpha);
}
