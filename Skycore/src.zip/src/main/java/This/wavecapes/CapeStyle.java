package This.wavecapes;

public enum CapeStyle {
    BLOCKY, SMOOTH
}
