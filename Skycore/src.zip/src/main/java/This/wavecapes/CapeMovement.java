package This.wavecapes;

public enum CapeMovement {
    VANILLA, BASIC_SIMULATION
}
