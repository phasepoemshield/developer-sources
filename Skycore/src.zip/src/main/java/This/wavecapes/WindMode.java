package This.wavecapes;

public enum WindMode {
    NONE, WAVES
}
