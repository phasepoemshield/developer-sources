package This.skycore.base.modules;

import This.skycore.tyca1337.client.modules.impl.combat.*;
import This.skycore.tyca1337.client.modules.impl.misc.*;
import This.skycore.tyca1337.client.modules.impl.movement.*;
import This.skycore.tyca1337.client.modules.impl.player.*;
import This.skycore.tyca1337.client.modules.impl.render.*;
import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import net.minecraft.client.option.Perspective;
import net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket;
import net.minecraft.util.math.MathHelper;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.input.EventKey;
import This.skycore.base.events.impl.other.EventGameUpdate;
import This.skycore.base.events.impl.render.EventHudRender;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.base.macro.Macro;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.setting.Setting;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.tyca1337.client.ui.menu.MenuScreen;
import This.skycore.util.component.RotationComponent;
import This.skycore.util.game.player.rotation.Rotation;
import This.skycore.util.interfaces.IMinecraft;

public final class ModuleManager implements IMinecraft {
   private final List<Module> modules = new ArrayList<>();
   private boolean isBack;
   private boolean isRotated;
   private float acceleration;

   private long lastKeyPressTime = 0;
   private int lastKeyCode = -1;
   private static final long DEBOUNCE_THRESHOLD_MS = 200;

   public ModuleManager() {
      init();
      EventManager.register(this);
   }

   private void init() {
      registerCombat();
      registerMovement();
      registerRender();
      registerPlayer();
      registerMisc();
   }

   private void registerCombat() {
      registerModule(AntiBot.INSTANCE);
      registerModule(AntiThorns.INSTANCE);
      registerModule(Aura.INSTANCE);
      registerModule(AimBot.INSTANCE);
      registerModule(NoVelocity.INSTANCE);
      registerModule(ElytraTarget.INSTANCE);
      registerModule(NoFriendDamage.INSTANCE);
      registerModule(AutoExplosion.INSTANCE);
      registerModule(AutoSwap.INSTANCE);
      registerModule(NoControllerWeb.INSTANCE);
      registerModule(AutoTotem.INSTANCE);

   }

   private void registerMovement() {
      registerModule(AutoSprint.INSTANCE);
      registerModule(ElytraBooster.INSTANCE);
      registerModule(ElytraRecast.INSTANCE);
      registerModule(GuiMove.INSTANCE);
      registerModule(NoSlow.INSTANCE);
      registerModule(Speed.INSTANCE);
      registerModule(AirStuck.INSTANCE);
      registerModule(GrimGlide.INSTANCE);
      registerModule(ElytraMotion.INSTANCE);
      registerModule(GrimNoFall.INSTANCE);
      registerModule(NoWeb.INSTANCE);
   }

   private void registerRender() {
      registerModule(Interface.INSTANCE);
      registerModule(Ambience.INSTANCE);
      registerModule(AntiInvisible.INSTANCE);
      registerModule(Arrows.INSTANCE);
      registerModule(Menu.INSTANCE);
      registerModule(NoRender.INSTANCE);
      registerModule(Predictions.INSTANCE);
      registerModule(SwingAnimation.INSTANCE);
      registerModule(Crosshair.INSTANCE);
      registerModule(ViewModel.INSTANCE);
      registerModule(CustomFog.INSTANCE);
      registerModule(PacketCriticals.INSTANCE);
      registerModule(FullBright.INSTANCE);
      registerModule(CustomSky.INSTANCE);
      registerModule(BlockOutline.INSTANCE);
       registerModule(WorldTime.INSTANCE);
      registerModule(EntityESP.INSTANCE);
      registerModule(TargetESP.INSTANCE);
      registerModule(Pets.INSTANCE);
      registerModule(BabyMod.INSTANCE);
      registerModule(KillEffect.INSTANCE);
      registerModule(FireworkESP.INSTANCE);
   }

   private void registerPlayer() {
      registerModule(AutoTool.INSTANCE);
      registerModule(AutoArmor.INSTANCE);
      registerModule(Blink.INSTANCE);
      registerModule(NoDelay.INSTANCE);
      registerModule(FastBreak.INSTANCE);
      registerModule(ItemAim.INSTANCE);
      registerModule(LockSlot.INSTANCE);
      registerModule(NoPush.INSTANCE);
      registerModule(TargetPearl.INSTANCE);
      registerModule(ClickPearl.INSTANCE);
   }

   private void registerMisc() {
      registerModule(ServerHelper.INSTANCE);
      registerModule(ElytraHelper.INSTANCE);
      registerModule(ItemScroller.INSTANCE);
      registerModule(ClickAction.INSTANCE);
      registerModule(FreeCam.INSTANCE);
      registerModule(AHHelper.INSTANCE);
      registerModule(NoInteract.INSTANCE);
      registerModule(AutoAccept.INSTANCE);
      registerModule(AutoRespawn.INSTANCE);
      registerModule(NameProtect.INSTANCE);
      registerModule(AutoDuel.INSTANCE);
      registerModule(ScoreboardHealth.INSTANCE);
      registerModule(ClientSounds.INSTANCE);
      registerModule(NoPlaceHeadSphere.INSTANCE);
   }

   private void registerModule(Module module) {
      modules.add(module);
   }

    public Module getModule(String name) {
        return modules.stream()
                .filter(module -> module.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    // Метод для получения модулей по категории (нужен для нового GUI)
    public List<Module> getModulesByCategory(Category category) {
        return modules.stream()
                .filter(module -> module.getCategory() == category)
                .collect(Collectors.toList());
    }

    public Set<Module> getActiveModules() {
        Set<Module> active = new HashSet<>();
        for (Module module : modules) {
            if (module.isEnabled()) {
                active.add(module);
            }
        }
        return active;
    }

    @EventTarget
    public void onKey(EventKey event) {
        if (mc.currentScreen == null && event.getAction() == 1) {
            int keyCode = event.getKeyCode();
            long currentTime = System.currentTimeMillis();

            if (keyCode == lastKeyCode && (currentTime - lastKeyPressTime) < DEBOUNCE_THRESHOLD_MS) {
                return;
            }

            lastKeyCode = keyCode;
            lastKeyPressTime = currentTime;

            for (Module module : modules) {
                if (module.getKeyCode() == keyCode && module.getKeyCode() != -1) {
                    module.toggle();
                }
            }

            for (Macro macro : SkyCore.getInstance().getMacroManager().getItems()) {
                if (keyCode == macro.getBind()) {
                    mc.getNetworkHandler().sendChatMessage(macro.getText());
                }
            }
        }
    }

    @EventTarget
    public void onRender(EventHudRender e) {
        // Обновление анимаций темы
        SkyCore.getInstance().getThemeManager().getCurrentTheme().getAnimation().update(true);

        // Обновление анимаций модулей и настроек
        for (Module module : modules) {
            module.getAnimation().update(module.isEnabled());

            for (Setting setting : module.getSettings()) {
                if (setting instanceof BooleanSetting booleanSetting) {
                    booleanSetting.getAnimation().update(booleanSetting.isEnabled());
                } else if (setting instanceof ModeSetting modeSetting) {
                    for (ModeSetting.Value value : modeSetting.getValues()) {
                        value.getAnimation().update(value.isSelected());
                    }
                } else if (setting instanceof MultiBooleanSetting multiBooleanSetting) {
                    for (MultiBooleanSetting.Value value : multiBooleanSetting.getBooleanSettings()) {
                        value.getAnimation().update(value.isEnabled());
                    }
                }
            }
        }

        // УДАЛЕНО: Логика взаимодействия с MenuScreen.
        // Новый MenuScreen управляет собой сам.
    }

    @EventTarget
    private void onPacket(EventPacket e) {
        if (e.getPacket() instanceof CloseScreenS2CPacket && mc.currentScreen instanceof MenuScreen) {
            e.cancel();
        }
    }

    @EventTarget
    private void onGameUpdate(EventGameUpdate e) {
        if (mc.player == null) return;

        if (!Aura.INSTANCE.isEnabled() || Aura.INSTANCE.getTarget() == null) {
            float cameraYaw = mc.gameRenderer.getCamera().getYaw();
            float cameraPitch = mc.gameRenderer.getCamera().getPitch();

            if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
                Aura.INSTANCE.lastYaw = cameraYaw - 180.0F;
                Aura.INSTANCE.lastPitch = -cameraPitch;
            } else {
                Aura.INSTANCE.lastYaw = cameraYaw;
                Aura.INSTANCE.lastPitch = cameraPitch;
            }

            if (Aura.INSTANCE.rotationMode.is("Vanilla")) {
                return;
            }

            Rotation current = new Rotation(mc.player.getYaw(), mc.player.getPitch());
            float deltaYaw = MathHelper.wrapDegrees(cameraYaw - current.getYaw());
            float deltaPitch = cameraPitch - current.getPitch();

            if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
                deltaYaw = MathHelper.wrapDegrees(cameraYaw - 180.0F - current.getYaw());
                deltaPitch = -cameraPitch - current.getPitch();
            }

            acceleration += 0.0024F;
            float smooth = MathHelper.clamp(acceleration, 0.0F, 1.0F);
            float newYaw = current.getYaw() + deltaYaw * smooth;
            float newPitch = current.getPitch() + deltaPitch * (smooth / 2.0F);

            Rotation smoothRot = new Rotation(newYaw, newPitch);
            RotationComponent.update(smoothRot, 360.0F, 360.0F, 360.0F, 360.0F, 0, 2, false);
        }
    }


    public List<Module> getModules() {
        return modules;
    }

    public boolean isBack() {
        return isBack;
    }

    public boolean isRotated() {
        return isRotated;
    }

    public float getAcceleration() {
        return acceleration;
    }

    public void setBack(boolean isBack) {
        this.isBack = isBack;
    }

    public void setRotated(boolean isRotated) {
        this.isRotated = isRotated;
    }

    public void setAcceleration(float acceleration) {
        this.acceleration = acceleration;
    }
}
