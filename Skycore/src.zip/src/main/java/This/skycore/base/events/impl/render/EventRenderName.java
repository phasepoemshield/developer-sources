package This.skycore.base.events.impl.render;

import This.skycore.base.events.callables.EventCancellable;

public final class EventRenderName extends EventCancellable {
}
