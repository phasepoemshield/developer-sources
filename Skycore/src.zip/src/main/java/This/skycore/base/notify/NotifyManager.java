package This.skycore.base.notify;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.RequestCommandCompletionsC2SPacket;
import net.minecraft.text.Text;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.other.EventModuleToggle;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.Interface.elements.component.NotifyComponent;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.impl.misc.ClientSounds;
import This.skycore.util.game.Sound;
import This.skycore.util.game.other.NetworkUtils;

public class NotifyManager {
   private static NotifyManager instance;
   private NotifyComponent notifyComponent;

   public NotifyManager() {
      EventManager.register(this);
   }

   public static NotifyManager getInstance() {
      if (instance == null) {
         instance = new NotifyManager();
      }

      return instance;
   }

   public void setNotifyComponent(NotifyComponent component) {
      this.notifyComponent = component;
   }

   @EventTarget
   @Native
   private void onPacket(EventPacket e) {
      if (!e.isSent()) {
         return;
      }

      Packet packet = e.getPacket();
      if (!(packet instanceof RequestCommandCompletionsC2SPacket req)) {
         return;
      }

      if (MinecraftClient.getInstance().getCurrentServerEntry() != null
            && MinecraftClient.getInstance().getCurrentServerEntry().address.contains("legendsgrief")) {
         NetworkUtils.sendSilentPacket(
               new RequestCommandCompletionsC2SPacket(req.getCompletionId(), req.getPartialCommand().replace("[", "").replace("]", "")));
         e.cancel();
      }
   }

   @EventTarget
   @Native
   public void onModuleToggle(EventModuleToggle event) {
      if (this.notifyComponent != null) {
         this.notifyComponent.addNotification(event.getModule(), event.isEnabled());
      }

      ClientSounds sounds = ClientSounds.INSTANCE;
      if (sounds != null && sounds.isEnabled()) {
         String t = sounds.soundType.get();
         boolean enabled = event.isEnabled();

         String soundFile;
         if ("2".equals(t)) {
            soundFile = enabled ? "MODULE_ON2.wav" : "MODULE_OFF2.wav";
         } else if ("3".equals(t)) {
            soundFile = enabled ? "MODULE_ON3.wav" : "MODULE_OFF3.wav";
         } else if ("4".equals(t)) {
            soundFile = enabled ? "MODULE_ON4.wav" : "MODULE_OFF4.wav";
         } else {
            soundFile = enabled ? "MODULE_ON.wav" : "MODULE_OFF.wav";
         }

         double vol = sounds.volume.getCurrent() / sounds.volume.getMax();
         Sound.playSound(soundFile, vol, 1.0f);
      }

   }

   public void addNotification(Module module, boolean enabled) {
      if (this.notifyComponent != null) {
         this.notifyComponent.addNotification(module, enabled);
      }

   }

   /** Оставлено для совместимости; на экран выводятся только уведомления о модуле. */
   public void addNotification(String icon, Text module) {
   }
}
