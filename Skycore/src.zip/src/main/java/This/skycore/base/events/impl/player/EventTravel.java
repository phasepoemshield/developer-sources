package This.skycore.base.events.impl.player;

import lombok.Getter;
import net.minecraft.entity.LivingEntity;
import This.skycore.base.events.callables.EventCancellable;

/**
 * Как в skycore 1.16.5: вызывается из {@link net.minecraft.entity.LivingEntity#travel}
 * до обработки движения по вводу / гравитации в travel.
 */
public final class EventTravel extends EventCancellable {

    @Getter
    private final LivingEntity entity;

    public EventTravel(LivingEntity entity) {
        this.entity = entity;
    }
}
