package This.skycore.base.events.impl.render;

import lombok.Generated;
import This.skycore.base.events.callables.EventCancellable;

public class EventFov extends EventCancellable {
   private int fov;
   private final int vanillaFov;

   public EventFov(int vanillaFov) {
      this.vanillaFov = vanillaFov;
      this.fov = vanillaFov;
   }

   @Generated
   public int getFov() {
      return this.fov;
   }

   @Generated
   public void setFov(int fov) {
      this.fov = fov;
   }

   @Generated
   public int getVanillaFov() {
      return this.vanillaFov;
   }
}
