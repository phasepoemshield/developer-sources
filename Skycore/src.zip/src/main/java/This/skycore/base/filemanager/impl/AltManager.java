package This.skycore.base.filemanager.impl;

import com.google.common.reflect.TypeToken;
import java.util.HashSet;
import java.util.Set;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.filemanager.api.ManagerFileAbstract;

public class AltManager extends ManagerFileAbstract<String> {
   public AltManager() {
      super("alts.json", "", (new TypeToken<Set<String>>() {
      }).getType(), HashSet::new);
   }

   public boolean isAlt(String name) {
      return this.getItems().contains(name);
   }

   public void addAlt(String name) {
      this.getItems().add(name);
   }

   @Native
   public boolean removeAlt(String name) {
      return this.getItems().remove(name);
   }
}

