package This.skycore.base.discord.callbacks;

import com.sun.jna.Callback;
import This.skycore.base.discord.utils.DiscordUser;

public interface ReadyCallback extends Callback {
   void apply(DiscordUser var1);
}
