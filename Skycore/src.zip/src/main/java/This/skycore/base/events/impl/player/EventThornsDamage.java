package This.skycore.base.events.impl.player;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import This.skycore.base.events.callables.EventCancellable;

@Data
@EqualsAndHashCode(callSuper = false)
public class EventThornsDamage extends EventCancellable {
    private final Entity attacker;
    private final LivingEntity user;
    private final int level;
    private float damage;

    public EventThornsDamage(Entity attacker, LivingEntity user, int level, float damage) {
        this.attacker = attacker;
        this.user = user;
        this.level = level;
        this.damage = damage;
    }
}
