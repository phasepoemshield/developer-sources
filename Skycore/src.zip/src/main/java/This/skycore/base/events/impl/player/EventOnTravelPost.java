package This.skycore.base.events.impl.player;

import com.darkmagician6.eventapi.events.Event;
import lombok.Data;
import net.minecraft.util.math.Vec3d;

@Data
public class EventOnTravelPost implements Event {
    private Vec3d oldVelocity;

    public EventOnTravelPost(Vec3d oldVelocity) {
        this.oldVelocity = oldVelocity;
    }
}
