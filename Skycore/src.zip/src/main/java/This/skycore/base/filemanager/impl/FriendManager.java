package This.skycore.base.filemanager.impl;

import com.google.common.reflect.TypeToken;
import java.util.HashSet;
import java.util.Set;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.filemanager.api.ManagerFileAbstract;

public class FriendManager extends ManagerFileAbstract<String> {
   public FriendManager() {
      super("friends.json", "", (new TypeToken<Set<String>>() {
      }).getType(), HashSet::new);
   }

   public boolean isFriend(String name) {
      return this.getItems().contains(name);
   }

   @Native
   public boolean removeFriend(String name) {
      return this.getItems().remove(name);
   }
}
