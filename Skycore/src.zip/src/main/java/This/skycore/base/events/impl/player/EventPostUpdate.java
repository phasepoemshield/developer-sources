package This.skycore.base.events.impl.player;

import com.darkmagician6.eventapi.events.Event;

public class EventPostUpdate implements Event {
}

