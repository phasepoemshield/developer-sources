package This.skycore.base.events.impl.other;

import com.darkmagician6.eventapi.events.Event;

public class EventWindowResize implements Event {
}
