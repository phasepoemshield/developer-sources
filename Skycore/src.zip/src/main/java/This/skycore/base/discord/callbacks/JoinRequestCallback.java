package This.skycore.base.discord.callbacks;

import com.sun.jna.Callback;
import This.skycore.base.discord.utils.DiscordUser;

public interface JoinRequestCallback extends Callback {
   void apply(DiscordUser var1);
}
