package This.skycore.base.events.impl.player;

import This.skycore.base.events.callables.EventCancellable;

public class EventSprintUpdate extends EventCancellable {
}
