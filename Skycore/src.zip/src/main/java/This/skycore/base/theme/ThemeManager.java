package This.skycore.base.theme;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import lombok.Generated;
import This.nexusguard.protection.annotations.Native;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;

public class ThemeManager {
    private Theme currentTheme;
    private final List<Theme> themes = new ArrayList();
    private final Theme defaultTheme =  new Theme("Nurik", (new Color(130, 200, 255)).getRGB(), (new Color(130, 200, 255)).getRGB());


    public ThemeManager() {
        this.initThemes();
    }

    @Native
    private void initThemes() {
        if (this.currentTheme == null) {
            this.currentTheme = this.defaultTheme;
        }

        this.themes.addAll(List.of(new Theme[]{
                this.defaultTheme,
                new Theme("IvanZoloPenis", (new Color(201,160,218, 255)).getRGB(), (new Color(143,116,171, 255)).getRGB()),
                new Theme("Red", (new Color(255, 58, 58, 255)).getRGB(), (new Color(200, 35, 35, 255)).getRGB()),
                new Theme("Blue", (new Color(58, 111, 255, 255)).getRGB(), (new Color(35, 78, 200, 255)).getRGB()),
                new Theme("LightBlue", (new Color(126, 220, 255, 255)).getRGB(), (new Color(88, 183, 222, 255)).getRGB()),
                new Theme("Rose", (new Color(255, 120, 190, 255)).getRGB(), (new Color(255, 120, 190, 255)).getRGB()),
                new Theme("Gold", (new Color(252, 192, 88, 255)).getRGB(), (new Color(252, 192, 88, 255)).getRGB()),
                new Theme("Diamond", (new Color(125, 217, 250, 255)).getRGB(), (new Color(125, 217, 250, 255)).getRGB()),
                new Theme("Sun", (new Color(252, 231, 88, 255)).getRGB(), (new Color(252, 231, 88, 255)).getRGB()),
                new Theme("Lavender", (new Color(190, 143, 255, 255)).getRGB(), (new Color(190, 143, 255, 255)).getRGB()),
                new Theme("Blood", (new Color(230, 50, 57, 255)).getRGB(), (new Color(230, 50, 57, 255)).getRGB()),
                new Theme("Ocean", (new Color(95, 113, 191, 255)).getRGB(), (new Color(95, 113, 191, 255)).getRGB()),
                new Theme("Emerald", (new Color(60, 220, 140, 255)).getRGB(), (new Color(60, 220, 140, 255)).getRGB()),









        }));
    }

    public ColorRGBA getClientColor(int index) {
        return this.currentTheme == null ? new ColorRGBA(255, 255, 255, 255) : ColorUtil.gradient(3, index, this.currentTheme.getColor(), this.currentTheme.getSecondColor());
    }

    @Generated
    public Theme getCurrentTheme() {
        return this.currentTheme;
    }

    @Generated
    public List<Theme> getThemes() {
        return this.themes;
    }

    @Generated
    public Theme getDefaultTheme() {
        return this.defaultTheme;
    }

    @Generated
    public void setCurrentTheme(Theme currentTheme) {
        this.currentTheme = currentTheme;
    }

    @Generated
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof ThemeManager)) {
            return false;
        } else {
            ThemeManager other = (ThemeManager)o;
            if (!other.canEqual(this)) {
                return false;
            } else {
                label47: {
                    Object this$currentTheme = this.getCurrentTheme();
                    Object other$currentTheme = other.getCurrentTheme();
                    if (this$currentTheme == null) {
                        if (other$currentTheme == null) {
                            break label47;
                        }
                    } else if (this$currentTheme.equals(other$currentTheme)) {
                        break label47;
                    }

                    return false;
                }

                Object this$themes = this.getThemes();
                Object other$themes = other.getThemes();
                if (this$themes == null) {
                    if (other$themes != null) {
                        return false;
                    }
                } else if (!this$themes.equals(other$themes)) {
                    return false;
                }

                Object this$defaultTheme = this.getDefaultTheme();
                Object other$defaultTheme = other.getDefaultTheme();
                if (this$defaultTheme == null) {
                    if (other$defaultTheme != null) {
                        return false;
                    }
                } else if (!this$defaultTheme.equals(other$defaultTheme)) {
                    return false;
                }

                return true;
            }
        }
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof ThemeManager;
    }

    @Generated
    public int hashCode() {
        int PRIME = 1;
        int result = 1;
        Object $currentTheme = this.getCurrentTheme();
        result = result * 59 + ($currentTheme == null ? 43 : $currentTheme.hashCode());
        Object $themes = this.getThemes();
        result = result * 59 + ($themes == null ? 43 : $themes.hashCode());
        Object $defaultTheme = this.getDefaultTheme();
        result = result * 59 + ($defaultTheme == null ? 43 : $defaultTheme.hashCode());
        return result;
    }

    @Generated
    public String toString() {
        String var10000 = String.valueOf(this.getCurrentTheme());
        return "ThemeManager(currentTheme=" + var10000 + ", themes=" + String.valueOf(this.getThemes()) + ", defaultTheme=" + String.valueOf(this.getDefaultTheme()) + ")";
    }
}
