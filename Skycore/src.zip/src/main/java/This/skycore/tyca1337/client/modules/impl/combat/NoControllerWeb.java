package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import This.nexusguard.protection.annotations.Native;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.utils.events.EventBlockCollide;

@ModuleAnnotation(
        name = "Web Ignore",
        category = Category.MOVEMENT,
        description = "Позволяет ломать и бить сквозь паутину"
)
public final class NoControllerWeb extends Module {

    public static final NoControllerWeb INSTANCE = new NoControllerWeb();

    private NoControllerWeb() {
    }

    @EventTarget
    @Native
    public void onBlockCollide(EventBlockCollide e) {
        if (mc.world == null || e.getPos() == null) {
            return;
        }
        if (mc.world.getBlockState(e.getPos()).getBlock() == Blocks.COBWEB) {
            e.setCancelled(true);
        }
    }
}
