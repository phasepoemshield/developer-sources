package This.skycore.tyca1337.client.modules.impl.misc;

import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.util.Hand;

@ModuleAnnotation(
        name = "NoPlayerSpHere",
        category = Category.MISC,
        description = "Блокирует установку PLAYER_HEAD"
)
public final class NoPlaceHeadSphere extends Module {
    public static final NoPlaceHeadSphere INSTANCE = new NoPlaceHeadSphere();

    @EventTarget
    @Native
    public void onPacket(EventPacket event) {
        if (mc.player == null || !event.isSent()) {
            return;
        }

        if (mc.player.getOffHandStack().getItem() != Items.PLAYER_HEAD) {
            return;
        }

        if (event.getPacket() instanceof PlayerInteractBlockC2SPacket) {
            event.cancel();
            return;
        }

        if (event.getPacket() instanceof PlayerInteractItemC2SPacket itemPacket
                && itemPacket.getHand() == Hand.OFF_HAND) {
            event.cancel();
        }
    }
}
