package This.skycore.tyca1337.helpers;


import com.darkmagician6.eventapi.events.Event;

public class EventWorldChanged implements Event {
}
