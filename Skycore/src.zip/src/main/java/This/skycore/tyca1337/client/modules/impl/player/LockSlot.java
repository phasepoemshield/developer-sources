package This.skycore.tyca1337.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.util.game.other.MessageUtil;

@ModuleAnnotation(
        name = "LockSlot",
        category = Category.PLAYER,
        description = "Блокирует выброс предметов из выбранных слотов"
)
public final class LockSlot extends Module {

    public static final LockSlot INSTANCE = new LockSlot();

    private final MultiBooleanSetting slots = new MultiBooleanSetting(
            "Слоты",
            MultiBooleanSetting.Value.of("1", false),
            MultiBooleanSetting.Value.of("2", false),
            MultiBooleanSetting.Value.of("3", false),
            MultiBooleanSetting.Value.of("4", false),
            MultiBooleanSetting.Value.of("5", false),
            MultiBooleanSetting.Value.of("6", false),
            MultiBooleanSetting.Value.of("7", false),
            MultiBooleanSetting.Value.of("8", false),
            MultiBooleanSetting.Value.of("9", false)
    );

    private LockSlot() {
    }

    @EventTarget
    @Native
    public void onPacket(EventPacket event) {
        if (mc.player == null || !event.isSent()) {
            return;
        }
        if (mc.currentScreen instanceof HandledScreen<?>) {
            return;
        }

        if (event.getPacket() instanceof PlayerActionC2SPacket packet) {
            PlayerActionC2SPacket.Action action = packet.getAction();
            if (action != PlayerActionC2SPacket.Action.DROP_ITEM && action != PlayerActionC2SPacket.Action.DROP_ALL_ITEMS) {
                return;
            }
            if (this.isCurrentSlotLockedForDrop()) {
                event.setCancelled(true);
                this.sendLockedMessage(mc.player.getInventory().selectedSlot);
            }
            return;
        }

        if (event.getPacket() instanceof ClickSlotC2SPacket packet && packet.getActionType() == SlotActionType.THROW) {
            int hotbarSlot = this.getHotbarSlotFromClick(packet.getSlot());
            if (hotbarSlot >= 0 && this.isHotbarSlotLocked(hotbarSlot)) {
                event.setCancelled(true);
                this.sendLockedMessage(hotbarSlot);
            }
        }
    }

    public boolean isCurrentSlotLockedForDrop() {
        if (!this.isEnabled() || mc.player == null || mc.player.getMainHandStack().isEmpty()) {
            return false;
        }
        if (mc.currentScreen instanceof HandledScreen<?>) {
            return false;
        }
        return this.isHotbarSlotLocked(mc.player.getInventory().selectedSlot);
    }

    private boolean isHotbarSlotLocked(int slot) {
        if (slot < 0 || slot > 8) {
            return false;
        }
        return this.slots.isEnable(String.valueOf(slot + 1));
    }

    private int getHotbarSlotFromClick(int slotId) {
        if (mc.player == null || slotId < 0 || slotId >= mc.player.currentScreenHandler.slots.size()) {
            return -1;
        }
        Slot slot = mc.player.currentScreenHandler.getSlot(slotId);
        if (mc.player.getInventory() != mc.player.getInventory()) {
            return -1;
        }
        int inventoryIndex = slot.getIndex();
        if (inventoryIndex >= 0 && inventoryIndex <= 8) {
            return inventoryIndex;
        }
        return -1;
    }

    private void sendLockedMessage(int slot) {
        if (mc.player == null) {
            return;
        }
        MessageUtil.displayInfo("Выброс предмета из слота " + (slot + 1) + " заблокирован");
    }
}
