package This.skycore.tyca1337.client.modules.impl.misc;

import lombok.Generated;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(
        name = "ClientSounds",
        category = Category.MISC,
        description = "Добавляет звуки клиента"
)
public final class ClientSounds extends Module {
    public static final ClientSounds INSTANCE = new ClientSounds();

    public final NumberSetting volume = new NumberSetting("Громкость", 50.0F, 1.0F, 100.0F, 0.5F);
    // как в skycore recode: значения добавляем через ModeSetting.Value, сам конструктор без начальных модов
    public final ModeSetting soundType = new ModeSetting("Тип звуков", new String[0]);

    private final ModeSetting.Value type1;
    private final ModeSetting.Value type2;
    private final ModeSetting.Value type3;
    private final ModeSetting.Value type4;

    private ClientSounds() {
        this.type1 = new ModeSetting.Value(this.soundType, "1", "");
        this.type2 = new ModeSetting.Value(this.soundType, "2", "");
        this.type3 = new ModeSetting.Value(this.soundType, "3", "");
        this.type4 = new ModeSetting.Value(this.soundType, "4", "");
        this.soundType.setValue(this.type1);
    }

    @Generated
    public NumberSetting getVolume() {
        return volume;
    }

    @Generated
    public ModeSetting getSoundType() {
        return soundType;
    }
}
