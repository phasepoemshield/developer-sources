package This.skycore.tyca1337.client.modules.api.setting.impl;

import com.google.gson.JsonObject;
import lombok.Getter;
import lombok.Setter;
import This.skycore.tyca1337.client.modules.api.setting.Setting;

import java.util.function.Supplier;

@Getter
@Setter
public class StringSetting extends Setting {
    private String value;
    private final String description;
    private final boolean onlyNumber;

    public StringSetting(String name, String defaultValue) {
        super(name);
        this.value = defaultValue;
        this.description = "";
        this.onlyNumber = false;
    }

    public StringSetting(String name, String defaultValue, String description) {
        super(name);
        this.value = defaultValue;
        this.description = description;
        this.onlyNumber = false;
    }

    public StringSetting(String name, String defaultValue, boolean onlyNumber) {
        super(name);
        this.value = defaultValue;
        this.description = "";
        this.onlyNumber = onlyNumber;
    }

    public StringSetting(String name, String defaultValue, String description, Supplier<Boolean> visible) {
        super(name);
        this.value = defaultValue;
        this.description = description;
        this.onlyNumber = false;
        this.setVisible(visible);
    }

    public static StringSetting of(String name, String defaultValue) {
        return new StringSetting(name, defaultValue);
    }

    public String get() {
        return value;
    }

    public void set(String value) {
        this.value = value;
    }

    @Override
    public void safe(JsonObject propertiesObject) {
        propertiesObject.addProperty(String.valueOf(this.name), this.value);
    }

    @Override
    public void load(JsonObject propertiesObject) {
        if (propertiesObject.has(String.valueOf(this.name))) {
            this.value = propertiesObject.get(String.valueOf(this.name)).getAsString();
        }
    }
}