package This.skycore.tyca1337.client.modules.impl.combat;

import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;

@ModuleAnnotation(
        name = "Velocity",
        category = Category.COMBAT,
        description = "Убирает откидывание"
)
public final class NoVelocity extends Module {
    public static final NoVelocity INSTANCE = new NoVelocity();
    private final ModeSetting mode = new ModeSetting("Мод", new String[]{"Обычный", "RW"});

    private NoVelocity() {
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        if (!e.isReceive() || mc.player == null) {
            return;
        }
        if (!(e.getPacket() instanceof EntityVelocityUpdateS2CPacket packet)) {
            return;
        }
        if (packet.getEntityId() != mc.player.getId()) {
            return;
        }
        // In this codebase there is no old 1.16 damage pipeline for RW mode,
        // so both modes keep the same behavior from the user's old "обычный" setup.
        if (this.mode.is("Обычный") || this.mode.is("RW")) {
            e.cancel();
        }
    }
}
