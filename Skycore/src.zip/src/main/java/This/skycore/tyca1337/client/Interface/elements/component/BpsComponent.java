package This.skycore.tyca1337.client.Interface.elements.component;

import This.nexusguard.protection.annotations.Native;
import This.skycore.base.font.Fonts;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;

import java.util.Locale;

public class BpsComponent extends DraggableHudElement {

   public BpsComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
      super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
   }

   @Native
   public void render(CustomDrawContext ctx) {
      if (mc.player == null) {
         return;
      }

      double deltaX = mc.player.getX() - mc.player.prevX;
      double deltaZ = mc.player.getZ() - mc.player.prevZ;
      double deltaY = mc.player.getY() - mc.player.prevY;
      double horizontal = Math.hypot(deltaX, deltaZ);
      double distance = Math.hypot(horizontal, deltaY);
      String bpsText = String.format(Locale.US, "%.1f", distance * 20.0D);
      
      float textWidth = Fonts.MEDIUM.getWidth(bpsText, 7.0f);
      float rectWidth = textWidth + 8.0f;
      float rectHeight = 12.0f;

      ctx.drawText(Fonts.MEDIUM.getFont(7.0f), bpsText, this.x + 4.0f, this.y + 2.5f, ColorRGBA.WHITE);
      
      this.width = rectWidth;
      this.height = rectHeight;
   }
}