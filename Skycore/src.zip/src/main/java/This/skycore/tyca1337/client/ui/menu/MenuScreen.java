package This.skycore.tyca1337.client.ui.menu;

import This.skycore.SkyCore;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.ui.menu.components.CategoryPanel;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.math.MathUtil;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.impl.render.Menu;
import This.skycore.util.game.player.PlayerInventoryComponent;
import This.skycore.util.interfaces.IClient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MenuScreen extends Screen implements IClient {

    public static String searchText = "";

    private final List<CategoryPanel> panels = new ArrayList<>();

    private static final float FIXED_COLUMN_WIDTH = 110.0f;
    private float layoutStartY;
    private Category[] layoutCategories;
    private final float layoutSpacing = 8;
    private final float layoutMargin = 12;

    public boolean search;
    public boolean needToClose;

    private final Animation openAnimation = new Animation(250L, Easing.CUBIC_OUT);

    private float searchX;
    private float searchY;
    private float searchW;
    private float searchH;

    private static final float THEME_BOX_SIZE = 14;
    private static final float THEME_BOX_SPACING = 6;

    public MenuScreen() {
        super(Text.of("DropDown"));
    }

    @Override
    protected void init() {
        super.init();

        panels.clear();

        Category[] categories = Arrays.stream(Category.values())
                .filter(c -> c != Category.THEMES)
                .toArray(Category[]::new);

        layoutCategories = categories;

        layoutStartY = (height - 280) / 2.0f;
        if (layoutStartY < 10) {
            layoutStartY = 10;
        }

        for (Category category : categories) {
            panels.add(new CategoryPanel(category, 0, layoutStartY, FIXED_COLUMN_WIDTH));
        }

        layoutPanels();

        searchW = 170;
        searchH = 16;
        searchX = (width - searchW) / 2.0f;
        searchY = layoutStartY + 310;
    }

    private void layoutPanels() {
        if (layoutCategories == null || layoutCategories.length == 0) {
            return;
        }

        float totalWidth = layoutCategories.length * FIXED_COLUMN_WIDTH + (layoutCategories.length - 1) * layoutSpacing;
        float startX = (width - totalWidth) / 2.0f;

        if (startX < layoutMargin) {
            startX = layoutMargin;
        }

        for (int i = 0; i < panels.size(); i++) {
            CategoryPanel panel = panels.get(i);
            float x = startX + i * (FIXED_COLUMN_WIDTH + layoutSpacing);
            panel.setX(x);
            panel.setY(layoutStartY);
            panel.setWidth(FIXED_COLUMN_WIDTH);
        }
    }

    @Native
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
        openAnimation.update(!needToClose);
        float alpha = openAnimation.getValue();

        if (needToClose && openAnimation.isDone() && alpha <= 0.0f) {
            IMinecraft.mc.setScreen(null);
            return;
        }

        PlayerInventoryComponent.updateMoveKeys();

        CustomDrawContext ctx = CustomDrawContext.of(context);

        // Затемнение всего экрана
        ctx.drawRect(0, 0, width, height, new ColorRGBA(0, 0, 0, (int) (120 * alpha)));

        boolean hoveredSearch = MathUtil.isHovered(mouseX, mouseY, searchX, searchY, searchW, searchH);
        ctx.drawRoundedRect(searchX, searchY, searchW, searchH, BorderRadius.all(4),
                new ColorRGBA(20, 20, 20, (int) (180 * alpha)));

        String shown = searchText.isEmpty() ? (search ? "..." : "Search") : searchText;
        ColorRGBA textColor = searchText.isEmpty() && !search
                ? new ColorRGBA(130, 130, 130, (int) (220 * alpha))
                : new ColorRGBA(255, 255, 255, (int) (255 * alpha));

        ctx.drawText(Fonts.REGULAR.getFont(7), shown, searchX + 6, searchY + 5.5f,
                hoveredSearch ? theme.getColor().withAlpha((int) (255 * alpha)) : textColor);

        List<Theme> themes = SkyCore.getInstance().getThemeManager().getThemes();

        float themesTotalWidth = themes.size() * THEME_BOX_SIZE + (themes.size() - 1) * THEME_BOX_SPACING;
        float themesStartX = (width - themesTotalWidth) / 2.0f;

        float themesY = searchY + searchH + 8;

        for (int i = 0; i < themes.size(); i++) {
            Theme swatchTheme = themes.get(i);

            float bx = themesStartX + i * (THEME_BOX_SIZE + THEME_BOX_SPACING);
            float by = themesY;

            float boxAlpha = 255 * alpha;

            ColorRGBA c1 = ColorRGBA.fromInt(swatchTheme.getColor1());
            ColorRGBA c2 = ColorRGBA.fromInt(swatchTheme.getColor2());

            DrawUtil.drawRoundedRect(ctx.getMatrices(), bx, by, THEME_BOX_SIZE, THEME_BOX_SIZE, BorderRadius.all(3.0f), c1, c2, c2, c1);

            Theme currentTheme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
            if (currentTheme != swatchTheme) {
                DrawUtil.drawRoundedRect(ctx.getMatrices(), bx, by, THEME_BOX_SIZE, THEME_BOX_SIZE, BorderRadius.all(3.0f), new ColorRGBA(0,0,0, (int)(100 * alpha)));
            }
        }

        for (CategoryPanel panel : panels) {
            panel.render(ctx, mouseX, mouseY, alpha, theme);
        }
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Обработка биндинга кнопок мыши для KeySetting и Module
        for (CategoryPanel panel : panels) {
            if (panel.handleMouseBinding(button)) {
                return true;
            }
        }

        if (button == 0) {
            List<Theme> themes = SkyCore.getInstance().getThemeManager().getThemes();
            Theme currentTheme = SkyCore.getInstance().getThemeManager().getCurrentTheme();

            float themesTotalWidth = themes.size() * THEME_BOX_SIZE + (themes.size() - 1) * THEME_BOX_SPACING;
            float themesStartX = (width - themesTotalWidth) / 2.0f;
            float themesY = searchY + searchH + 8;

            for (int i = 0; i < themes.size(); i++) {
                Theme swatchTheme = themes.get(i);
                float bx = themesStartX + i * (THEME_BOX_SIZE + THEME_BOX_SPACING);
                float by = themesY;

                if (MathUtil.isHovered(mouseX, mouseY, bx, by, THEME_BOX_SIZE, THEME_BOX_SIZE) && currentTheme != swatchTheme) {
                    SkyCore.getInstance().getThemeManager().setCurrentTheme(swatchTheme);
                    return true;
                }
            }
        }

        if (MathUtil.isHovered(mouseX, mouseY, searchX, searchY, searchW, searchH)) {
            if (button == 0) {
                search = true;
                return true;
            }
        } else {
            search = false;
        }

        for (int i = panels.size() - 1; i >= 0; i--) {
            CategoryPanel panel = panels.get(i);
            if (panel.mouseClicked(mouseX, mouseY, button)) {
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (CategoryPanel panel : panels) {
            panel.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (int i = panels.size() - 1; i >= 0; i--) {
            CategoryPanel panel = panels.get(i);
            if (panel.mouseScrolled(mouseX, mouseY, verticalAmount)) {
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            needToClose = true;
            Menu.INSTANCE.setEnabled(false);
            return true;
        }

        if (search) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!searchText.isEmpty()) {
                    searchText = searchText.substring(0, searchText.length() - 1);
                }
                return true;
            }

            if (keyCode == GLFW.GLFW_KEY_ENTER) {
                search = false;
                return true;
            }

            if (keyCode == GLFW.GLFW_KEY_V && (modifiers & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = IMinecraft.mc.keyboard.getClipboard();
                if (clip != null && !clip.isEmpty()) {
                    searchText = searchText + clip;
                }
                return true;
            }
        }

        for (CategoryPanel panel : panels) {
            if (panel.keyPressed(keyCode)) {
                return true;
            }
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (search) {
            if (!Character.isISOControl(chr)) {
                searchText = searchText + chr;
            }
            return true;
        }

        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}