package This.skycore.tyca1337.client.modules.impl.misc;


import com.darkmagician6.eventapi.EventTarget;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import java.util.Locale;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.util.math.Timer;

@ModuleAnnotation(
        name = "Auto Duel",
        category = Category.MISC,
        description = "Автоматически вызывает игрока на дуэль"
)
public final class AutoDuel extends Module {
    public static final AutoDuel INSTANCE = new AutoDuel();
    private static final Pattern pattern = Pattern.compile("^\\w{3,16}$");

    private final MultiBooleanSetting mode = MultiBooleanSetting.create("Кит", List.of("Щит", "Шипы 3", "Лук", "Тотемы", "Исцеление", "Шары", "Классик", "Читерский рай", "Незерка"));

    private final BooleanSetting noFriends = new BooleanSetting("Пропускать друзей", true);

    private double lastPosX;
    private double lastPosY;
    private double lastPosZ;
    private final List<String> sent = Lists.newArrayList();
    private final Timer counter = new Timer();
    private final Timer counter2 = new Timer();
    private final Timer counterChoice = new Timer();
    private final Timer counterTo = new Timer();
    private final HashMap<String, Long> duelTimestamps = new HashMap<>();

    private AutoDuel() {
    }

    @EventTarget
    @Native
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        List<String> players = this.getOnlinePlayers();

        double distance = Math.sqrt(
                Math.pow(this.lastPosX - mc.player.getX(), 2.0D) +
                        Math.pow(this.lastPosY - mc.player.getY(), 2.0D) +
                        Math.pow(this.lastPosZ - mc.player.getZ(), 2.0D)
        );

        if (distance > 500.0D) {
            this.toggle();
        }

        this.lastPosX = mc.player.getX();
        this.lastPosY = mc.player.getY();
        this.lastPosZ = mc.player.getZ();

        if (counter2.getElapsedTime() >= 80L * players.size()) {
            this.sent.clear();
            this.counter2.reset();
        }

        for (String player : players) {
            if (this.sent.contains(player)) continue;
            if (player.equals(mc.getSession().getUsername())) continue;
            if (counter.getElapsedTime() < 600L) continue;
            if (this.noFriends.isEnabled() && SkyCore.getInstance().getFriendManager().isFriend(player)) continue;

            if (this.duelTimestamps.containsKey(player)) {
                long lastDuelTime = this.duelTimestamps.get(player);
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastDuelTime < 31000L) continue;
            }

            mc.player.networkHandler.sendChatCommand("duel " + player);
            this.sent.add(player);
            this.duelTimestamps.put(player, System.currentTimeMillis());
            this.counter.reset();
        }

        if (mc.currentScreen instanceof GenericContainerScreen) {
            GenericContainerScreen screen = (GenericContainerScreen) mc.currentScreen;
            GenericContainerScreenHandler handler = (GenericContainerScreenHandler) screen.getScreenHandler();

            if (screen.getTitle().getString().contains("Выбор набора (1/1)")) {
                List<Integer> slotsID = new ArrayList<>();

                int index = 0;

                for (int i = 0; i < mode.getBooleanSettings().size(); i++) {
                    if (!mode.get(i).isEnabled()) {
                        index++;
                    } else {
                        slotsID.add(index);
                        index++;
                    }
                }

                Collections.shuffle(slotsID);
                if (!slotsID.isEmpty() && counterChoice.finished(80L)) {
                    int slotID = slotsID.get(0);
                    mc.interactionManager.clickSlot(handler.syncId, slotID, 0, SlotActionType.QUICK_MOVE, mc.player);
                    counterChoice.reset();
                }

            } else if (screen.getTitle().getString().contains("Настройка поединка") && counterTo.finished(80L)) {
                mc.interactionManager.clickSlot(handler.syncId, 0, 0, SlotActionType.QUICK_MOVE, mc.player);
                counterTo.reset();
            }
        }
    }

    @EventTarget
    @Native
    public void onPacket(EventPacket eventReceivePacket) {
        if (mc.player == null || mc.world == null) return;

        if (eventReceivePacket.isReceive()) {
            Packet<?> packet = eventReceivePacket.getPacket();
            if (packet instanceof GameMessageS2CPacket) {
                GameMessageS2CPacket chat = (GameMessageS2CPacket) packet;
                String text = chat.content().getString().toLowerCase(Locale.ROOT);
                if ((text.contains("начало") && text.contains("через") && text.contains("секунд!")) ||
                        text.equals("дуэли » во время поединка запрещено использовать команды")) {

                    this.toggle();
                }
            }
        }
    }

    private List<String> getOnlinePlayers() {
        if (mc.getNetworkHandler() == null) {
            return new ArrayList<>();
        }
        return mc.getNetworkHandler().getPlayerList().stream()
                .map(PlayerListEntry::getProfile)
                .map(GameProfile::getName)
                .filter(profileName -> pattern.matcher(profileName).matches())
                .collect(Collectors.toList());
    }
}

