package This.skycore.tyca1337.client.handlers.richidog;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector2f;
import This.skycore.util.animation.advanced.InfinityAnimation;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.math.MathUtil;
import This.skycore.util.math.Timer;

public class RichiBrain implements IMinecraft {

    private Vec3d pos;
    private Vec3d motion = Vec3d.ZERO;
    private float direction = MathUtil.random(0, 360);
    private float yaw;
    private float body;

    private final InfinityAnimation x = new InfinityAnimation();
    private final InfinityAnimation y = new InfinityAnimation();
    private final InfinityAnimation z = new InfinityAnimation();

    private final InfinityAnimation bodyAnim = new InfinityAnimation();
    private final InfinityAnimation yawAnim = new InfinityAnimation();
    private final InfinityAnimation pitchAnim = new InfinityAnimation();

    private boolean lay;
    private final Timer staying = new Timer();

    public float prevLimbSwingAmount;
    public float limbSwingAmount;
    public float limbSwing;

    private PlayerEntity entity;

    public void setEntity(PlayerEntity entity) {
        this.entity = entity;
    }

    public void reset() {
        this.pos = null;
        this.motion = Vec3d.ZERO;
        this.direction = MathUtil.random(0, 360);
        this.yaw = 0.0F;
        this.body = 0.0F;
        this.lay = false;
        this.prevLimbSwingAmount = 0.0F;
        this.limbSwingAmount = 0.0F;
        this.limbSwing = 0.0F;
    }

    public void onUpdate() {
        if (entity == null || mc.world == null) {
            return;
        }

        Vec3d playerPos = entity.getPos();
        float playerYawRad = (float) Math.toRadians(entity.getYaw());
        Vec3d followPos = playerPos.add(Math.sin(playerYawRad) * 1.4, 0.0, -Math.cos(playerYawRad) * 1.4);

        if (pos == null || pos.distanceTo(playerPos) > 10) {
            pos = followPos;
            x.animate((float) pos.x, 1);
            y.animate((float) pos.y, 1);
            z.animate((float) pos.z, 1);
        }

        double distToFollow = pos.distanceTo(followPos);
        if (distToFollow > 6.0) {
            pos = followPos;
            motion = Vec3d.ZERO;
        } else {
            Vec3d horizontalDelta = new Vec3d(followPos.x - pos.x, 0.0, followPos.z - pos.z);
            Vec3d horizontalMotion = horizontalDelta.lengthSquared() > 1.0E-4
                    ? horizontalDelta.normalize().multiply(Math.min(0.22, horizontalDelta.length() * 0.35))
                    : Vec3d.ZERO;

            double groundY = playerPos.y;
            motion = new Vec3d(horizontalMotion.x, groundY - pos.y, horizontalMotion.z);
            pos = pos.add(motion);
        }

        handleRotation();

        int animSpeed = 150;
        x.animate((float) pos.x, animSpeed);
        y.animate((float) pos.y, animSpeed);
        z.animate((float) pos.z, animSpeed);

        limbTick();

        if (Math.abs(pos.x - x.get()) > 0.1f || Math.abs(pos.z - z.get()) > 0.1f) {
            staying.reset();
        }

        lay = staying.getElapsedTime() >= 1000;
    }

    private static boolean isBlockSolid(double x, double y, double z) {
        if (mc.world == null) {
            return false;
        }
        BlockPos bp = BlockPos.ofFloored(x, y, z);
        return !mc.world.getBlockState(bp).getCollisionShape(mc.world, bp).isEmpty();
    }

    private void handleRotation() {
        if (motion.x != 0 || motion.z != 0) {
            double angle = Math.atan2(motion.z, motion.x);
            yaw = (float) Math.toDegrees(angle) - 90;
            yaw %= 360;
            if (yaw < 0) {
                yaw += 360;
            }
        }

        Vec3d eye = entity.getPos().add(0, entity.getEyeHeight(entity.getPose()), 0);
        Vector2f rotation = rotationToward(getPos(), eye);

        float gradus = lay ? 200 : 150;
        float gradus1 = lay ? 100 : 50;
        if (rotation.x - yaw < -gradus || rotation.x - yaw > gradus) {
            yaw = rotation.x;
        }

        float shortestYawPath = (float) (((((yaw - body) % 360) + 540) % 360) - 180);

        if (!lay) {
            bodyAnim.animate(body + shortestYawPath, 150);
        }
        yawAnim.animate(MathHelper.clamp(rotation.x - yaw, -gradus1, gradus1), 150);
        pitchAnim.animate(rotation.y, 150);

        body += shortestYawPath;
    }

    private static Vector2f rotationToward(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double h = MathHelper.sqrt((float) (dx * dx + dz * dz));
        float yaw = (float) (Math.atan2(dz, dx) * (180 / Math.PI)) - 90.0F;
        float pitch = (float) (-(Math.atan2(dy, h) * (180 / Math.PI)));
        return new Vector2f(yaw, pitch);
    }

    public void limbTick() {
        prevLimbSwingAmount = limbSwingAmount;
        double d0 = x.get() - pos.x;
        double d1 = 0.0D;
        double d2 = z.get() - pos.z;
        float f = MathHelper.sqrt((float) (d0 * d0 + d1 * d1 + d2 * d2)) * 4.0F;

        if (f > 1.0F) {
            f = 1.0F;
        }

        limbSwingAmount += (f - limbSwingAmount) * 0.4F;
        limbSwing += limbSwingAmount;
    }

    public float getBody() {
        return bodyAnim.get();
    }

    public float getYaw() {
        return yawAnim.get();
    }

    public float getPitch() {
        return pitchAnim.get();
    }

    public Vec3d getPos() {
        return new Vec3d(x.get(), y.get(), z.get());
    }

    public boolean isLay() {
        return lay;
    }
}
