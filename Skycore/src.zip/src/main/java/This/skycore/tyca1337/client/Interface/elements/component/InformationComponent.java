package This.skycore.tyca1337.client.Interface.elements.component;

import java.util.Locale;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.font.Fonts;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
public class InformationComponent extends DraggableHudElement {
    public InformationComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Native
    public void render(CustomDrawContext ctx) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        int px = (int)Math.floor(mc.player.getX());
        int py = (int)Math.floor(mc.player.getY());
        int pz = (int)Math.floor(mc.player.getZ());

        String coordsText = String.format(Locale.US, "X: %d  Y: %d  Z: %d", px, py, pz);
        float textSize = 8.5f;
        float textWidth = Fonts.SEMIBOLD.getWidth(coordsText, textSize);
        float textHeight = Fonts.SEMIBOLD.getFont(textSize).height();

        float x = 4.0f;
        float y = mc.getWindow().getScaledHeight() - textHeight - 4.0f;

        ctx.drawText(Fonts.SEMIBOLD.getFont(textSize), coordsText, x, y, ColorRGBA.WHITE);

        this.width = textWidth;
        this.height = textHeight;
    }
}
