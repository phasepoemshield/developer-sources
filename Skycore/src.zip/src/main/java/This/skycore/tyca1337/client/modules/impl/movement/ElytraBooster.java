package This.skycore.tyca1337.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.MathHelper;
import This.skycore.base.events.impl.render.EventRender2D;
import This.skycore.base.font.Fonts;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.tyca1337.client.modules.impl.combat.Aura;
import This.skycore.util.render.display.base.color.ColorRGBA;

@ModuleAnnotation(
        name = "Super Firework",
        category = Category.MOVEMENT,
        description = "Ускоряет полёт на элитрах"
)
public final class ElytraBooster extends Module {

    public static final ElytraBooster INSTANCE = new ElytraBooster();

    private final BooleanSetting boost = new BooleanSetting("Ускорение", true);
    private final ModeSetting mode = new ModeSetting("Режим ускорения", boost::isEnabled, "ReallyWorld", "Bravo", "BravoGrief", "Кастомный");
    private final MultiBooleanSetting render = new MultiBooleanSetting("Отображать");
    private final BooleanSetting individualY = new BooleanSetting("Индивидуальный Y", false, () -> boost.isEnabled() && mode.is("Кастомный"));

    private final NumberSetting xz0_5 = new NumberSetting("XZ 0-5°", 1.52F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));
    private final NumberSetting xz5_10 = new NumberSetting("XZ 5-10°", 1.53F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));
    private final NumberSetting xz10_15 = new NumberSetting("XZ 10-15°", 1.54F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));
    private final NumberSetting xz15_20 = new NumberSetting("XZ 15-20°", 1.55F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));
    private final NumberSetting xz20_25 = new NumberSetting("XZ 20-25°", 1.56F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));
    private final NumberSetting xz25_30 = new NumberSetting("XZ 25-30°", 1.57F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));
    private final NumberSetting xz30_35 = new NumberSetting("XZ 30-35°", 1.58F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));
    private final NumberSetting xz35_40 = new NumberSetting("XZ 35-40°", 1.59F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));
    private final NumberSetting xz40_45 = new NumberSetting("XZ 40-45°", 1.60F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный"));

    private final NumberSetting y0_5 = new NumberSetting("Y 0-5°", 1.51F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y5_10 = new NumberSetting("Y 5-10°", 1.52F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y10_15 = new NumberSetting("Y 10-15°", 1.53F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y15_20 = new NumberSetting("Y 15-20°", 1.54F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y20_25 = new NumberSetting("Y 20-25°", 1.55F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y25_30 = new NumberSetting("Y 25-30°", 1.56F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y30_35 = new NumberSetting("Y 30-35°", 1.57F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y35_40 = new NumberSetting("Y 35-40°", 1.58F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y40_45 = new NumberSetting("Y 40-45°", 1.59F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y45_50 = new NumberSetting("Y 45-50°", 1.60F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());
    private final NumberSetting y50_55 = new NumberSetting("Y 50-55°", 1.61F, 1.5F, 3.0F, 0.01F, () -> boost.isEnabled() && mode.is("Кастомный") && !individualY.isEnabled());

    private final NumberSetting[] individualYSettings = new NumberSetting[56];
    private final NumberSetting[] xzSliders;
    private final NumberSetting[] yGroupSliders;

    private static final float[] BRAVO_GRIEF_XZ = {1.67f, 1.68f, 1.69f, 1.72f, 1.72f, 1.73f, 1.74f, 1.75f, 1.76f};
    private static final float[] BRAVO_GRIEF_Y = {1.72f, 1.72f, 1.72f, 1.72f, 1.72f, 1.73f, 1.74f, 1.76f, 1.8f};
    private static final float[] REALLY_WORLD_XZ = {1.6f, 1.63f, 1.66f, 1.71f, 1.73f, 1.81f, 1.81f, 1.81f, 1.81f};
    private static final float[] REALLY_WORLD_Y = {1.6f, 1.62f, 1.6f, 1.62f, 1.64f, 1.68f, 1.75f, 1.9f, 2.16f};

    private ElytraBooster() {
        new MultiBooleanSetting.Value(render, "Углы", false);
        xzSliders = new NumberSetting[]{xz0_5, xz5_10, xz10_15, xz15_20, xz20_25, xz25_30, xz30_35, xz35_40, xz40_45};
        yGroupSliders = new NumberSetting[]{y0_5, y5_10, y10_15, y15_20, y20_25, y25_30, y30_35, y35_40, y40_45, y45_50, y50_55};

        for (int i = 0; i <= 55; i++) {
            float defaultValue = 1.5f + (i / 55f) * 1.5f;
            final int degree = i;
            individualYSettings[i] = new NumberSetting("Y " + degree + "°", defaultValue, 1.5F, 3.0F, 0.01F,
                    () -> boost.isEnabled() && mode.is("Кастомный") && individualY.isEnabled());
        }
    }

    public record BoostValues(float speedXZ, float speedY) {
    }

    public BoostValues computeBoost(float yaw, float pitch) {
        if (!boost.isEnabled() || mc.player == null) {
            return new BoostValues(1.5F, 1.5F);
        }

        Aura aura = Aura.INSTANCE;
        if (aura != null && aura.isEnabled()) {
            yaw = MathHelper.wrapDegrees(aura.lastYaw);
            pitch = aura.lastPitch;
        }

        if (mode.is("Кастомный")) {
            float speedXZ = getCustomSpeed(yaw, xzSliders);
            float speedY = individualY.isEnabled() ? getIndividualYSpeed(pitch) : getCustomSpeed(pitch, yGroupSliders);
            if (speedY > speedXZ) {
                speedXZ = speedY;
            }
            return new BoostValues(speedXZ, speedY);
        }
        if (mode.is("Bravo")) {
            return new BoostValues(getBravoSpeedXZ(pitch, yaw), getBravoSpeedY(pitch));
        }
        if (mode.is("BravoGrief")) {
            return new BoostValues(getTableSpeed(BRAVO_GRIEF_XZ, yaw, 9), getTableSpeed(BRAVO_GRIEF_Y, pitch, 9));
        }
        if (mode.is("ReallyWorld")) {
            float speedXZ = getTableSpeed(REALLY_WORLD_XZ, yaw, 9);
            float speedY = getTableSpeed(REALLY_WORLD_Y, pitch, 9);
            if (speedY > speedXZ) {
                speedXZ = speedY;
            }
            return new BoostValues(speedXZ, speedY);
        }
        return new BoostValues(1.5F, 1.5F);
    }

    private float getIndividualYSpeed(float pitch) {
        float absPitch = convertAngleForIndividual(pitch);
        int degree = Math.round(absPitch);
        if (degree < 0) degree = 0;
        if (degree > 55) degree = 55;
        return individualYSettings[degree].getCurrent();
    }

    private float convertAngleForIndividual(float angle) {
        float absAngle = Math.abs(angle);
        if (absAngle > 90.0f) {
            absAngle = 180.0f - absAngle;
        }
        return absAngle;
    }

    private float getCustomSpeed(float angle, NumberSetting[] sliders) {
        float converted = convertAngle(angle);
        int index = (int) (converted / 5.0f);
        if (index >= sliders.length) {
            index = sliders.length - 1;
        }
        if (index < 0) {
            index = 0;
        }
        return sliders[index].getCurrent();
    }

    private float convertAngle(float angle) {
        float absAngle = Math.abs(angle);
        if (absAngle > 90.0f) {
            absAngle = 180.0f - absAngle;
        }
        if (absAngle > 45.0f) {
            absAngle = 90.0f - absAngle;
        }
        return absAngle;
    }

    private static float getTableSpeed(float[] table, float angle, int tableLength) {
        int index = (int) (convertAngleStatic(angle) / 5.0f);
        if (index >= tableLength) {
            index = tableLength - 1;
        }
        if (index < 0) {
            index = 0;
        }
        return table[index];
    }

    private static float convertAngleStatic(float angle) {
        float absAngle = Math.abs(angle);
        if (absAngle > 90.0f) {
            absAngle = 180.0f - absAngle;
        }
        if (absAngle > 45.0f) {
            absAngle = 90.0f - absAngle;
        }
        return absAngle;
    }

    private float getBravoSpeedXZ(float pitch, float yaw) {
        float absPitch = Math.abs(pitch);
        float absYaw = Math.abs(MathHelper.wrapDegrees(yaw) % 90.0f);
        float speed = absPitch >= 38.0f && absPitch <= 52.0f ? 2.0f
                : absPitch >= 32.0f && absPitch <= 58.0f ? 1.96f
                : absPitch >= 28.0f && absPitch <= 62.0f ? 1.95f
                : (absYaw >= 29.0f && absYaw <= 61.0f) || (absPitch >= 29.0f && absPitch <= 61.0f) ? 1.963f
                : (absYaw >= 28.0f && absYaw <= 60.0f) || (absPitch >= 28.0f && absPitch <= 60.0f) ? 1.954f
                : (absYaw >= 26.0f && absYaw <= 64.0f) || (absPitch >= 26.0f && absPitch <= 64.0f) ? 1.874f
                : (absYaw >= 24.0f && absYaw <= 66.0f) || (absPitch >= 24.0f && absPitch <= 66.0f) ? 1.75f
                : (absYaw >= 15.0f && absYaw <= 75.0f) || (absPitch >= 15.0f && absPitch <= 75.0f) ? 1.75f
                : (absYaw >= 13.0f && absYaw <= 77.0f) || (absPitch >= 13.0f && absPitch <= 77.0f) ? 1.75f
                : (absYaw >= 12.0f && absYaw <= 78.0f) || (absPitch >= 12.0f && absPitch <= 78.0f) ? 1.75f
                : (absYaw >= 8.0f && absYaw <= 82.0f) || (absPitch >= 11.0f && absPitch <= 79.0f) ? 1.75f
                : (absYaw >= 5.0f && absYaw <= 85.0f) || (absPitch >= 8.0f && absPitch <= 82.0f) ? 1.67f
                : (absYaw <= 90.0f || absPitch <= 90.0f) ? 1.67f : 1.66f;
        return pitch > 15.0f ? speed - 0.068f : speed;
    }

    private float getBravoSpeedY(float pitch) {
        float absPitch = Math.abs(pitch);
        if (absPitch >= 37.0f && absPitch <= 38.0f) return 2.03f;
        if (absPitch >= 25.0f && absPitch <= 30.0f) return 2.0f;
        if (absPitch >= 35.0f && absPitch <= 45.0f) return 1.99f;
        if (absPitch >= 40.0f && absPitch <= 50.0f) return 1.97f;
        if (absPitch >= 50.0f && absPitch <= 60.0f) return 1.96f;
        if (absPitch >= 51.0f && absPitch <= 61.0f) return 1.85f;
        if (absPitch >= 52.0f && absPitch <= 65.0f) return 1.8f;
        return 1.59f;
    }

    @EventTarget
    private void onRender(EventRender2D event) {
        if (mc.player == null || mc.world == null || (mc.getDebugHud() != null && mc.getDebugHud().shouldShowDebugHud())) {
            return;
        }
        if (!mode.is("Кастомный") || !render.isEnable("Углы")) {
            return;
        }

        int screenCenterX = mc.getWindow().getScaledWidth() / 2;
        String pitch = String.valueOf((int) mc.player.getPitch());
        String pitchText = "Pitch: " + pitch;
        float pitchWidth = Fonts.INTER.getWidth(pitchText, 8.0F);
        float x = screenCenterX - pitchWidth / 2f;
        float y = mc.getWindow().getScaledHeight() / 2f + 12f;
        event.getContext().drawText(Fonts.INTER.getFont(8.0F), pitchText, x, y + 13, ColorRGBA.WHITE);
    }
}
