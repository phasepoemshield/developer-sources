package This.skycore.tyca1337.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import This.skycore.base.events.impl.input.EventKey;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.KeySetting;
import This.skycore.tyca1337.helpers.InventoryUtil;

@ModuleAnnotation(
        name = "ClickPearl",
        category = Category.PLAYER,
        description = "Позволяет мгновенно бросать эндер-жемчуг, нажатием на определенную кнопку"
)
public final class ClickPearl extends Module {
    public static final ClickPearl INSTANCE = new ClickPearl();

    public final KeySetting clickKey = new KeySetting("Кнопка");
    public final BooleanSetting legit = new BooleanSetting("Легитный", false);

    private ClickPearl() {
        this.clickKey.setKeyCode(-98);
    }

    @EventTarget
    private void onKey(EventKey e) {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) {
            return;
        }
        if (e.getAction() != 1) {
            return;
        }
        if (e.getKeyCode() == this.clickKey.getKeyCode()) {
            this.handleClickPearl();
        }
    }

    private void handleClickPearl() {
        if (mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL.getDefaultStack())
                || InventoryUtil.getItemSlot(Items.ENDER_PEARL) == -1) {
            return;
        }

        if (this.legit.isEnabled()) {
            InventoryUtil.inventorySwapClick(Items.ENDER_PEARL);
            return;
        }

        if (this.isFunOrSpooky()) {
            int hbSlot = this.findItem(Items.ENDER_PEARL, true);
            int invSlot = this.findItem(Items.ENDER_PEARL, false);
            this.findAndThrowItem(hbSlot, invSlot);
        } else {
            InventoryUtil.inventorySwapClick(Items.ENDER_PEARL);
            this.useItem(Hand.MAIN_HAND);
        }
    }

    private boolean isFunOrSpooky() {
        if (mc.getNetworkHandler() == null || mc.getNetworkHandler().getServerInfo() == null) {
            return false;
        }
        String ip = mc.getNetworkHandler().getServerInfo().address.toLowerCase();
        return ip.contains("funtime") || ip.contains("spooky");
    }

    private int findItem(Item item, boolean hotbarOnly) {
        int start = hotbarOnly ? 0 : 9;
        int end = hotbarOnly ? 9 : 36;
        for (int i = start; i < end; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() == item) {
                return i;
            }
        }
        return -1;
    }

    private void findAndThrowItem(int hbSlot, int invSlot) {
        int oldSlot = mc.player.getInventory().selectedSlot;
        if (hbSlot != -1) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(hbSlot));
            this.useItem(Hand.MAIN_HAND);
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(oldSlot));
            return;
        }
        if (invSlot != -1) {
            int syncId = mc.player.currentScreenHandler.syncId;
            mc.interactionManager.clickSlot(syncId, invSlot, oldSlot, SlotActionType.SWAP, mc.player);
            this.useItem(Hand.MAIN_HAND);
            mc.interactionManager.clickSlot(syncId, invSlot, oldSlot, SlotActionType.SWAP, mc.player);
        }
    }

    private void useItem(Hand hand) {
        mc.getNetworkHandler().sendPacket(new PlayerInteractItemC2SPacket(hand, 0, mc.player.getYaw(), mc.player.getPitch()));
    }
}
