package This.skycore.tyca1337.client.Interface.elements.component;

import java.util.ArrayList;
import java.util.List;

import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.client.gui.screen.ChatScreen;
import org.lwjgl.glfw.GLFW;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.impl.render.Hud2;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;

public class KeybindsWaveComponent extends DraggableHudElement {
    private final Animation widthAnimation;
    private final Animation heightAnimation;
    private final List<BindItem> bindItems = new ArrayList<>();
    private float maxTextWidth = 0.0F;

    private static final float ITEM_HEIGHT = 14.0F;
    private static final float HEADER_HEIGHT = 18.0F;
    private static final float PADDING = 8.0F;
    private static final float MIN_WIDTH = 80.0F;
    private static final float ICON_SIZE = 10.0F;
    private static final float ICON_SPACING = 6.0F;

    public KeybindsWaveComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
        this.widthAnimation = new Animation(300L, Easing.CUBIC_OUT);
        this.heightAnimation = new Animation(200L, Easing.CUBIC_OUT);
    }

    @Native
    public void render(CustomDrawContext ctx) {
        float posX = this.getX();
        float posY = this.getY();

        updateBindItems();

        maxTextWidth = Fonts.REGULAR.getFont(7.0F).width("keybinds");
        for (BindItem item : bindItems) {
            if (item.active) {
                String moduleName = item.module.getName();
                String keyName = getKeyName(item.module.getKeyCode());
                float moduleWidth = Fonts.REGULAR.getFont(6.5F).width(moduleName);
                float keyWidth = Fonts.REGULAR.getFont(6.5F).width(keyName);
                float totalWidth = moduleWidth + 20.0F + keyWidth;
                if (totalWidth > maxTextWidth) {
                    maxTextWidth = totalWidth;
                }
            }
        }

        float targetWidth = Math.max(MIN_WIDTH, maxTextWidth + PADDING * 2);
        widthAnimation.update(1.0F);
        float currentWidth = targetWidth * widthAnimation.getValue();

        int visibleCount = 0;
        for (BindItem item : bindItems) {
            if (item.active) {
                visibleCount++;
            }
        }

        boolean shouldShow = visibleCount > 0 || mc.currentScreen instanceof ChatScreen;

        if (!shouldShow && heightAnimation.getValue() <= 0.01F) {
            this.width = currentWidth;
            this.height = HEADER_HEIGHT;
            return;
        }

        heightAnimation.update(shouldShow ? 1.0F : 0.0F);

        float currentHeight = HEADER_HEIGHT + (visibleCount * ITEM_HEIGHT * heightAnimation.getValue());

        posY = this.adjustRenderYAboveChat(posY, currentHeight);

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();

        ColorRGBA background = Hud2.INSTANCE.getBackgroundColor();

        DrawUtil.drawRect(ctx.getMatrices(), posX, posY, currentWidth, currentHeight, background);

        float topLineHeight = 1.5F;
        for (float i = 0; i < currentWidth; i++) {
            float hue = (float)(System.currentTimeMillis() % 6000L) / 6000.0F + (i / currentWidth);
            if (hue > 1.0F) hue -= 1.0F;
            int rainbowColor = java.awt.Color.HSBtoRGB(hue, 0.6F, 1.0F);
            ColorRGBA rainbowRGBA = new ColorRGBA(
                (rainbowColor >> 16) & 0xFF,
                (rainbowColor >> 8) & 0xFF,
                rainbowColor & 0xFF,
                255
            );
            DrawUtil.drawRect(ctx.getMatrices(), posX + i, posY, 1.0F, topLineHeight, rainbowRGBA);
        }

        float titleY = posY + 5.0F;
        float alpha = widthAnimation.getValue();

        ctx.drawText(Fonts.REGULAR.getFont(7.0F), "keybinds", posX + PADDING, titleY, ColorRGBA.WHITE.withAlpha(alpha * 255.0F));

        float lineY = posY + HEADER_HEIGHT - 1.5F;
        float lineHeight = 1.5F;
        for (float i = 0; i < currentWidth; i++) {
            float hue = (float)(System.currentTimeMillis() % 6000L) / 6000.0F + (i / currentWidth);
            if (hue > 1.0F) hue -= 1.0F;
            int rainbowColor = java.awt.Color.HSBtoRGB(hue, 0.6F, 1.0F);
            ColorRGBA rainbowRGBA = new ColorRGBA(
                (rainbowColor >> 16) & 0xFF,
                (rainbowColor >> 8) & 0xFF,
                rainbowColor & 0xFF,
                255
            );
            DrawUtil.drawRect(ctx.getMatrices(), posX + i, lineY, 1.0F, lineHeight, rainbowRGBA);
        }

        float itemY = posY + HEADER_HEIGHT;
        for (BindItem item : bindItems) {
            if (item.active && item.animation.getValue() > 0.01F) {
                float itemAlpha = item.animation.getValue() * alpha;

                String moduleName = item.module.getName();
                float textX = posX + PADDING;
                float textY = itemY + 3.0F;
                ctx.drawText(Fonts.REGULAR.getFont(6.5F), moduleName, textX, textY, ColorRGBA.WHITE.withAlpha(itemAlpha * 255.0F));

                String keyName = getKeyName(item.module.getKeyCode());
                float keyX = posX + currentWidth - PADDING - Fonts.REGULAR.getFont(6.5F).width(keyName);
                ctx.drawText(Fonts.REGULAR.getFont(6.5F), keyName, keyX, textY, ColorRGBA.WHITE.withAlpha(itemAlpha * 255.0F));

                itemY += ITEM_HEIGHT * item.animation.getValue();
            }
        }

        this.width = currentWidth;
        this.height = currentHeight;
    }

    private void drawModuleIcon(CustomDrawContext ctx, float x, float y, float size, ColorRGBA color) {
        float half = size / 2.0F;
        float quarter = size / 4.0F;

        DrawUtil.drawRect(ctx.getMatrices(), x + quarter, y, half, half, color);
        DrawUtil.drawRect(ctx.getMatrices(), x, y + half, half, half, color);
        DrawUtil.drawRect(ctx.getMatrices(), x + half, y + half, half, half, color);
    }

    private String getKeyName(int keyCode) {
        if (keyCode == -1 || keyCode == 0) return "NONE";
        String name = GLFW.glfwGetKeyName(keyCode, 0);
        if (name != null) {
            return name.toUpperCase();
        }
        return switch (keyCode) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_GRAVE_ACCENT -> "GRAVE";
            default -> "KEY" + keyCode;
        };
    }

    private void updateBindItems() {
        List<BindableItem> activeItems = new ArrayList<>();

        // Добавляем модули с кейбиндами
        for (Module module : SkyCore.getInstance().getModuleManager().getModules()) {
            if (module.isEnabled() && module.getKeyCode() != 0 && module.getKeyCode() != -1) {
                activeItems.add(new BindableItem(module, null));
            }
        }

        // Добавляем bindable настройки из модулей
        for (Module module : SkyCore.getInstance().getModuleManager().getModules()) {
            for (var setting : module.getSettings()) {
                if (setting instanceof BooleanSetting boolSetting) {
                    if (boolSetting.isBindable() && boolSetting.getKeyCode() != 0 && boolSetting.getKeyCode() != -1 && boolSetting.isEnabled()) {
                        activeItems.add(new BindableItem(module, boolSetting));
                    }
                } else if (setting instanceof NumberSetting numSetting) {
                    if (numSetting.isBindable() && numSetting.getKeyCode() != 0 && numSetting.getKeyCode() != -1) {
                        activeItems.add(new BindableItem(module, numSetting));
                    }
                }
            }
        }

        bindItems.removeIf(item -> !activeItems.stream().anyMatch(ai ->
            ai.module == item.module &&
            ((ai.setting == null && item.setting == null) ||
             (ai.setting != null && item.setting != null && ai.setting == item.setting))
        ));

        for (BindableItem activeItem : activeItems) {
            boolean exists = false;
            for (BindItem item : bindItems) {
                if (item.module == activeItem.module &&
                    ((activeItem.setting == null && item.setting == null) ||
                     (activeItem.setting != null && item.setting != null && activeItem.setting == item.setting))) {
                    exists = true;
                    item.active = true;
                    item.animation.update(1.0F);
                    break;
                }
            }
            if (!exists) {
                BindItem newItem = new BindItem(activeItem.module, activeItem.setting);
                newItem.active = true;
                bindItems.add(newItem);
            }
        }

        for (BindItem item : bindItems) {
            if (!item.active) {
                item.animation.update(0.0F);
            }
        }
    }

    private static class BindableItem {
        Module module;
        Object setting;

        BindableItem(Module module, Object setting) {
            this.module = module;
            this.setting = setting;
        }
    }

    private static class BindItem {
        Module module;
        Object setting;
        boolean active;
        Animation animation;

        BindItem(Module module, Object setting) {
            this.module = module;
            this.setting = setting;
            this.active = false;
            this.animation = new Animation(200L, Easing.CUBIC_OUT);
        }
    }
}
