package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.util.component.MoveComponent;
import This.skycore.util.game.player.MovingUtil;

import java.util.List;

@ModuleAnnotation(
        name = "Auto Totem",
        category = Category.COMBAT,
        description = "У этого модуля нет описания!"
)
public final class AutoTotem extends Module {

    public static final AutoTotem INSTANCE = new AutoTotem();

    private static final int SWAP_COOLDOWN_TICKS = 5;

    private final NumberSetting health = new NumberSetting("Уровень здоровья", 4.0F, 1.0F, 20.0F, 0.5F);
    private final NumberSetting elytraHealth = new NumberSetting("Здоровье на элитре", 8.0F, 1.0F, 20.0F, 0.5F);
    private final BooleanSetting swapBack = new BooleanSetting("Возвращать предмет", true);
    private final BooleanSetting noBallSwitch = new BooleanSetting("Игнорировать проверки, если в руке шар", false);
    private final BooleanSetting saveEnchanted = new BooleanSetting("Сохранять зачарованный", true);
    private final BooleanSetting ignoreDragonidTotem = new BooleanSetting("Не брать тотем Драконида", true);
    private final BooleanSetting stop = new BooleanSetting("Синхронизировать с GuiMove", false);
    private final MultiBooleanSetting mode = MultiBooleanSetting.create(
            "Проверки на",
            List.of("Золотые сердца", "Кристаллы", "Падение", "Динамит", "Трезубец")
    );
    private final NumberSetting distancecrystall = new NumberSetting(
            "Дистанция проверки на кристалл",
            6.0F,
            1.0F,
            6.0F,
            1.0F,
            () -> mode.isEnable("Кристаллы")
    );

    private int nonEnchantedTotems;
    private int oldItem = -1;
    private int ticks;
    private ItemStack oldOffhandStack = ItemStack.EMPTY;
    private boolean totemLocked;
    private int slotToSwap = -1;

    private AutoTotem() {
    }

    @EventTarget
    private void totemSwap(EventUpdate e) {
        if (slotToSwap != -1) {
            doSwap(slotToSwap);
        }
    }

    @EventTarget
    private void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        ticks++;
        Slot slot = findTotemSlotAndUpdateCount();

        if (isTotemLockActive() && !hasTotemInHand() && slot != null && ticks >= SWAP_COOLDOWN_TICKS && !isSwapBlockedByBall()) {
            doSwap(slot.id);
            return;
        }

        if (shouldReturnSavedItem(slot)) {
            int returnSlot = findReturnSlot();
            if (returnSlot != -1) {
                doSwap(returnSlot);
                return;
            }
        }

        if (ticks >= SWAP_COOLDOWN_TICKS) {
            if (!isSwapBlockedByBall() && !hasTotemInHand()) {
                if (mode.isEnable("Кристаллы")) {
                    if (!mc.world.getEntitiesByClass(EndCrystalEntity.class, mc.player.getBoundingBox().expand(distancecrystall.getCurrent()), entity -> true).isEmpty()
                            && slot != null) {
                        doSwap(slot.id);
                        return;
                    }
                }
                if (mode.isEnable("Динамит")) {
                    if (!mc.world.getEntitiesByClass(TntEntity.class, mc.player.getBoundingBox().expand(8.0D), entity -> true).isEmpty()
                            && slot != null) {
                        doSwap(slot.id);
                        return;
                    }
                    if (!mc.world.getEntitiesByClass(TntMinecartEntity.class, mc.player.getBoundingBox().expand(8.0D), entity -> true).isEmpty()
                            && slot != null) {
                        doSwap(slot.id);
                        return;
                    }
                }
                if (mode.isEnable("Трезубец")) {
                    List<TridentEntity> nearbyTridents = mc.world.getEntitiesByClass(
                            TridentEntity.class,
                            mc.player.getBoundingBox().expand(10.0D),
                            entity -> true
                    );
                    boolean isAnyTridentMoving = nearbyTridents.stream().anyMatch(trident ->
                            trident.getX() != trident.prevX
                                    || trident.getY() != trident.prevY
                                    || trident.getZ() != trident.prevZ
                    );
                    if (isAnyTridentMoving && slot != null) {
                        doSwap(slot.id);
                        return;
                    }
                }
            }

            if (needTotem()) {
                if (slot != null && !hasTotemInHand()) {
                    doSwap(slot.id);
                }
            } else if (canSwapBack()) {
                int returnSlot = findReturnSlot();
                if (returnSlot == -1) {
                    oldItem = -1;
                    oldOffhandStack = ItemStack.EMPTY;
                    slotToSwap = -1;
                    return;
                }
                if (mode.isEnable("Кристаллы")
                        && !mc.world.getEntitiesByClass(EndCrystalEntity.class, mc.player.getBoundingBox().expand(distancecrystall.getCurrent()), entity -> true).isEmpty()) {
                    slotToSwap = -1;
                    return;
                }
                if (mode.isEnable("Динамит")
                        && (!mc.world.getEntitiesByClass(TntMinecartEntity.class, mc.player.getBoundingBox().expand(8.0D), entity -> true).isEmpty()
                        || !mc.world.getEntitiesByClass(TntEntity.class, mc.player.getBoundingBox().expand(8.0D), entity -> true).isEmpty())) {
                    slotToSwap = -1;
                    return;
                }
                if (mode.isEnable("Трезубец")) {
                    List<TridentEntity> nearbyTridents = mc.world.getEntitiesByClass(
                            TridentEntity.class,
                            mc.player.getBoundingBox().expand(10.0D),
                            entity -> true
                    );
                    boolean isAnyTridentMoving = nearbyTridents.stream().anyMatch(trident ->
                            trident.getX() != trident.prevX
                                    || trident.getY() != trident.prevY
                                    || trident.getZ() != trident.prevZ
                    );
                    if (isAnyTridentMoving) {
                        slotToSwap = -1;
                        return;
                    }
                }
                doSwap(returnSlot);
            }
        }
    }

    @EventTarget
    private void onPacket(EventPacket event) {
        if (!event.isReceive() || mc.player == null || mc.world == null) {
            return;
        }

        if (!(event.getPacket() instanceof EntitySpawnS2CPacket packet)) {
            return;
        }

        if (packet.getEntityType() != EntityType.END_CRYSTAL || !mode.isEnable("Кристаллы") || isSwapBlockedByBall()) {
            return;
        }

        EndCrystalEntity crystal = new EndCrystalEntity(mc.world, packet.getX(), packet.getY(), packet.getZ());
        if (mc.player.squaredDistanceTo(crystal) > distancecrystall.getCurrent() * distancecrystall.getCurrent() || hasTotemInHand()) {
            return;
        }

        Slot crystalSlot = findTotemSlotAndUpdateCount();
        if (crystalSlot == null) {
            return;
        }

        doSwap(crystalSlot.id);
    }

    private boolean hasTotemInHand() {
        for (Hand hand : Hand.values()) {
            ItemStack stack = mc.player.getStackInHand(hand);
            if (isUsableTotem(stack)) {
                return true;
            }
        }
        return false;
    }

    private boolean isUsableTotem(ItemStack stack) {
        if (stack.isEmpty() || !stack.isOf(Items.TOTEM_OF_UNDYING) || isDragonidTotem(stack)) {
            return false;
        }
        return !saveEnchanted.isEnabled() || !stack.hasEnchantments() || nonEnchantedTotems <= 0;
    }

    private boolean isDragonidTotem(ItemStack stack) {
        if (!ignoreDragonidTotem.isEnabled() || stack.isEmpty() || !stack.isOf(Items.TOTEM_OF_UNDYING)) {
            return false;
        }
        return stack.getName().getString().contains("Тотем Драконида");
    }

    private boolean needTotem() {
        boolean blockByBall = isSwapBlockedByBall();
        if (!blockByBall && mode.isEnable("Падение")
                && !mc.player.isTouchingWater()
                && !mc.player.isGliding()
                && mc.player.fallDistance > 10.0F) {
            return true;
        }
        return getEffectiveHealth() <= getTotemHealthThreshold();
    }

    private boolean shouldReturnSavedItem(Slot totemSlot) {
        if (!swapBack.isEnabled() || oldItem == -1) {
            return false;
        }
        if (isSameReturnItem(mc.player.getOffHandStack(), oldOffhandStack)) {
            oldItem = -1;
            oldOffhandStack = ItemStack.EMPTY;
            totemLocked = false;
            return false;
        }
        if (isTotemLockActive()) {
            return false;
        }
        return totemSlot == null && !isUsableTotem(mc.player.getOffHandStack());
    }

    private boolean canSwapBack() {
        if (!totemLocked || oldItem == -1 || !swapBack.isEnabled()) {
            return false;
        }
        if (isCriticalHalfHeart()) {
            return false;
        }
        return getEffectiveHealth() >= getSwapBackHealthThreshold();
    }

    private boolean isTotemLockActive() {
        return totemLocked && getEffectiveHealth() < getSwapBackHealthThreshold();
    }

    private float getEffectiveHealth() {
        float currentHealth = mc.player.getHealth();
        if (mode.isEnable("Золотые сердца") && !mc.player.isGliding() && mc.player.hasStatusEffect(StatusEffects.ABSORPTION)) {
            currentHealth += mc.player.getAbsorptionAmount();
        }
        return currentHealth;
    }

    private float getTotemHealthThreshold() {
        return mc.player.isGliding() ? elytraHealth.getCurrent() : health.getCurrent();
    }

    private float getSwapBackHealthThreshold() {
        return getTotemHealthThreshold() + 2.0F;
    }

    private boolean isCriticalHalfHeart() {
        return mc.player.getHealth() <= 1.0F;
    }

    private int findReturnSlot() {
        if (isValidSwapSlot(oldItem) && isSameReturnItem(mc.player.currentScreenHandler.getSlot(oldItem).getStack(), oldOffhandStack)) {
            return oldItem;
        }
        if (oldOffhandStack.isEmpty()) {
            return isValidSwapSlot(oldItem) ? oldItem : -1;
        }
        for (Slot slot : mc.player.currentScreenHandler.slots) {
            if (slot.id == 45) {
                continue;
            }
            if (isSameReturnItem(slot.getStack(), oldOffhandStack)) {
                oldItem = slot.id;
                return slot.id;
            }
        }
        return -1;
    }

    private boolean isSameReturnItem(ItemStack current, ItemStack expected) {
        if (current.isEmpty() || expected.isEmpty()) {
            return false;
        }
        return current.getItem() == expected.getItem() && ItemStack.areItemsAndComponentsEqual(current, expected);
    }

    private Slot findTotemSlotAndUpdateCount() {
        nonEnchantedTotems = (int) mc.player.currentScreenHandler.slots.stream()
                .filter(s -> s.getStack().isOf(Items.TOTEM_OF_UNDYING) && !isDragonidTotem(s.getStack()) && !s.getStack().hasEnchantments())
                .count();
        return mc.player.currentScreenHandler.slots.stream()
                .filter(s -> s.getStack().isOf(Items.TOTEM_OF_UNDYING) && !isDragonidTotem(s.getStack())
                        && (!saveEnchanted.isEnabled() || !s.getStack().hasEnchantments() || nonEnchantedTotems <= 0))
                .findFirst()
                .orElse(null);
    }

    private void doSwap(int fromSlot) {
        if (!isValidSwapSlot(fromSlot)) {
            slotToSwap = -1;
            return;
        }

        ItemStack fromStack = mc.player.currentScreenHandler.getSlot(fromSlot).getStack();
        boolean swappingTotemToOffhand = fromStack.isOf(Items.TOTEM_OF_UNDYING);
        boolean swappingSavedItemBack = oldItem != -1 && isSameReturnItem(fromStack, oldOffhandStack);

        if (MovingUtil.hasPlayerMovement()) {
            MoveComponent.setStopTicks(3);
        }
        if (stop.isEnabled()) {
            MoveComponent.setStop(true);
        }

        if (!MovingUtil.hasPlayerMovement() || (!stop.isEnabled() && !mc.player.isSprinting())) {
            if (oldItem != -1 && oldItem == fromSlot) {
                oldItem = -1;
                oldOffhandStack = ItemStack.EMPTY;
                totemLocked = false;
            } else if (!mc.player.getOffHandStack().isEmpty() && oldItem == -1) {
                oldItem = fromSlot;
                oldOffhandStack = mc.player.getOffHandStack().copy();
            }
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, fromSlot, 40, SlotActionType.SWAP, mc.player);
            if (swappingTotemToOffhand) {
                totemLocked = true;
            } else if (swappingSavedItemBack) {
                totemLocked = false;
            }
            slotToSwap = -1;
            ticks = 0;
        } else {
            slotToSwap = fromSlot;
        }
    }

    private boolean isValidSwapSlot(int slot) {
        return slot >= 0 && slot < mc.player.currentScreenHandler.slots.size();
    }

    private boolean isSwapBlockedByBall() {
        return noBallSwitch.isEnabled()
                && mc.player.getOffHandStack().isOf(Items.PLAYER_HEAD)
                && !(mode.isEnable("Падение") && mc.player.fallDistance > 5.0F);
    }

    @Override
    public void onDisable() {
        oldItem = -1;
        oldOffhandStack = ItemStack.EMPTY;
        totemLocked = false;
        ticks = 0;
        slotToSwap = -1;
        super.onDisable();
    }
}
