package This.skycore.tyca1337.helpers;

/** Флаг активности CrystalOptimizer (sky.core 1.16.5). */
public final class CrystalOptimizerState {
    public static boolean Rabotaet;

    private CrystalOptimizerState() {
    }
}
