package This.skycore.tyca1337.client.Interface.elements.component;

import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;
import This.skycore.util.render.display.shader.DrawUtil;

public class HudWaveComponent extends DraggableHudElement {
    private final Animation widthAnimation;

    public HudWaveComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
        this.widthAnimation = new Animation(300L, Easing.CUBIC_OUT);
    }

    @Native
    public void render(CustomDrawContext ctx) {
        if (mc.player == null) return;

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();

        // Получаем информацию
        int fps = mc.getCurrentFps();
        int ping = 0;
        if (mc.player != null && mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null) {
            ping = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency();
        }

        // Получаем username из TYPE
        String username = SkyCore.TYPE.isEmpty() ? "DEV" : SkyCore.TYPE;

        // Текст: "Static.tech ◆ username | fps | ping"
        String text = String.format("Static.tech ◆ %s  |  %d fps  |  %d ms", username, fps, ping);

        // Вычисляем ширину текста
        float textWidth = Fonts.REGULAR.getFont(6.0F).width(text);
        float targetWidth = textWidth + 20.0F; // Отступы (было 10.0F, стало 20.0F для большей ширины)

        // Анимация расширения
        widthAnimation.update(1.0F);
        float currentWidth = targetWidth * widthAnimation.getValue();

        float height = 14.0F;
        float posX = this.x;
        float posY = this.y;

        ColorRGBA accent = theme.getColor();
        ColorRGBA darkBase = new ColorRGBA(6, 6, 6, 255);
        ColorRGBA topMixed = ColorUtil.interpolate(accent, darkBase, 0.95F);
        ColorRGBA bottomMixed = ColorUtil.interpolate(accent, darkBase, 0.92F);
        ColorRGBA top = topMixed.withAlpha(180);
        ColorRGBA bottom = bottomMixed.withAlpha(180);

        DrawUtil.drawRect(ctx.getMatrices(), posX, posY, currentWidth, height, top);

        float alpha = widthAnimation.getValue();

        // Радужная полоска СВЕРХУ (над текстом)
        float topLineHeight = 1.5F;
        for (float i = 0; i < currentWidth; i++) {
            float hue = (float)(System.currentTimeMillis() % 6000L) / 6000.0F + (i / currentWidth);
            if (hue > 1.0F) hue -= 1.0F;
            int rainbowColor = java.awt.Color.HSBtoRGB(hue, 0.6F, 1.0F);
            ColorRGBA rainbowRGBA = new ColorRGBA(
                (rainbowColor >> 16) & 0xFF,
                (rainbowColor >> 8) & 0xFF,
                rainbowColor & 0xFF,
                (int)(alpha * 255.0F)
            );
            DrawUtil.drawRect(ctx.getMatrices(), posX + i, posY, 1.0F, topLineHeight, rainbowRGBA);
        }

        // Текст с анимацией прозрачности
        float textY = posY + 5.0F;  // Выровнял по Y
        float textX = posX + 8.0F;  // Выровнял по X (было 4.0F, стало 8.0F для большего отступа слева)

        // Радужная полоска снизу (под текстом)
        float bottomLineY = posY + height - 1.5F;
        float bottomLineHeight = 1.5F;
        for (float i = 0; i < currentWidth; i++) {
            float hue = (float)(System.currentTimeMillis() % 6000L) / 6000.0F + (i / currentWidth);
            if (hue > 1.0F) hue -= 1.0F;
            int rainbowColor = java.awt.Color.HSBtoRGB(hue, 0.6F, 1.0F);
            ColorRGBA rainbowRGBA = new ColorRGBA(
                (rainbowColor >> 16) & 0xFF,
                (rainbowColor >> 8) & 0xFF,
                rainbowColor & 0xFF,
                (int)(alpha * 255.0F)
            );
            DrawUtil.drawRect(ctx.getMatrices(), posX + i, bottomLineY, 1.0F, bottomLineHeight, rainbowRGBA);
        }

        ctx.drawText(Fonts.REGULAR.getFont(6.0F), text, textX, textY, ColorRGBA.WHITE.withAlpha(alpha * 255.0F));

        this.width = currentWidth;
        this.height = height;
    }
}
