package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import com.mojang.blaze3d.systems.RenderSystem;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.other.EventGameUpdate;
import This.skycore.base.events.impl.render.EventRender3D;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.util.component.RotationComponent;
import This.skycore.util.game.player.rotation.Rotation;

/**
 * Наведение на цель при натяжении лука / арбалета (порт с Wonderful AimBot).
 */
@ModuleAnnotation(
        name = "Projectile Helper",
        category = Category.COMBAT,
        description = "Авто-наведение для лука и арбалета"
)
public final class AimBot extends Module {

    public static final AimBot INSTANCE = new AimBot();

    private final MultiBooleanSetting targetTypes = new MultiBooleanSetting("Типы целей",
            MultiBooleanSetting.Value.of("Игроки", true),
            MultiBooleanSetting.Value.of("В броне", true),
            MultiBooleanSetting.Value.of("Без брони", false),
            MultiBooleanSetting.Value.of("Мобы", false),
            MultiBooleanSetting.Value.of("Зомби", false)
    );
    private final NumberSetting range = new NumberSetting("Дистанция", 40.0F, 10.0F, 100.0F, 1.0F);
    private final NumberSetting aimTime = new NumberSetting("Время наводки (тики)", 10.0F, 0.0F, 40.0F, 1.0F);
    private final BooleanSetting silentRotations = new BooleanSetting("Тихие повороты", true);
    private final BooleanSetting showCrosshair = new BooleanSetting("Показать прицел", true);
    private final NumberSetting crosshairSize = new NumberSetting("Размер прицела", 1.0F, 0.3F, 3.0F, 0.1F);

    private LivingEntity target;
    private boolean isAiming;
    private float aimProgress;
    private Rotation targetRotation;

    private AimBot() {
    }

    private boolean isHoldingBowOrCrossbow() {
        if (mc.player == null) {
            return false;
        }
        ItemStack mainHand = mc.player.getMainHandStack();
        ItemStack offHand = mc.player.getOffHandStack();
        return mainHand.getItem() instanceof BowItem
                || mainHand.getItem() instanceof CrossbowItem
                || offHand.getItem() instanceof BowItem
                || offHand.getItem() instanceof CrossbowItem;
    }

    private boolean isUsingBowOrCrossbow() {
        return mc.player != null && mc.player.isUsingItem() && this.isHoldingBowOrCrossbow();
    }

    private boolean isValidTarget(LivingEntity entity) {
        if (entity == mc.player) {
            return false;
        }
        if (!entity.isAlive() || entity.getHealth() <= 0.0F) {
            return false;
        }

        if (entity instanceof PlayerEntity player) {
            if (!this.targetTypes.isEnable("Игроки")) {
                return false;
            }
            if (SkyCore.getInstance().getFriendManager().isFriend(player.getName().getString())) {
                return false;
            }

            boolean hasArmor = false;
            for (ItemStack armor : player.getArmorItems()) {
                if (!armor.isEmpty()) {
                    hasArmor = true;
                    break;
                }
            }

            if (this.targetTypes.isEnable("В броне") && hasArmor) {
                return true;
            }
            if (this.targetTypes.isEnable("Без брони") && !hasArmor) {
                return true;
            }
            return !this.targetTypes.isEnable("В броне") && !this.targetTypes.isEnable("Без брони");
        }

        if (entity instanceof ZombieEntity) {
            return this.targetTypes.isEnable("Зомби");
        }

        if (entity instanceof HostileEntity) {
            return this.targetTypes.isEnable("Мобы");
        }

        return false;
    }

    private LivingEntity findBestTarget() {
        if (mc.player == null || mc.world == null) {
            return null;
        }

        List<LivingEntity> targets = new ArrayList<>();
        float r = this.range.getCurrent();
        Box searchBox = mc.player.getBoundingBox().expand(r);

        for (LivingEntity entity : mc.world.getEntitiesByClass(LivingEntity.class, searchBox, e -> true)) {
            if (!this.isValidTarget(entity)) {
                continue;
            }
            if (mc.player.squaredDistanceTo(entity) > r * r) {
                continue;
            }
            targets.add(entity);
        }

        if (targets.isEmpty()) {
            return null;
        }

        targets.sort(Comparator.comparingDouble(mc.player::distanceTo));
        return targets.get(0);
    }

    private Rotation calculateBowRotation(LivingEntity aimTarget) {
        Vec3d eyes = mc.player.getEyePos();
        Vec3d targetPos = aimTarget.getBoundingBox().getCenter();
        double dx = targetPos.x - eyes.x;
        double dy = targetPos.y - eyes.y;
        double dz = targetPos.z - eyes.z;
        double distance = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, distance));
        return new Rotation(yaw, pitch);
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (!this.isEnabled() || !this.showCrosshair.isEnabled() || this.target == null || !this.isAiming) {
            return;
        }

        float partialTicks = event.getPartialTicks();
        Vec3d targetPos = new Vec3d(
                MathHelper.lerp(partialTicks, this.target.lastRenderX, this.target.getX()),
                MathHelper.lerp(partialTicks, this.target.lastRenderY, this.target.getY()) + (double) this.target.getHeight() / 2.0D,
                MathHelper.lerp(partialTicks, this.target.lastRenderZ, this.target.getZ())
        );

        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        MatrixStack matrices = event.getMatrix();

        double renderX = targetPos.x - cameraPos.x;
        double renderY = targetPos.y - cameraPos.y;
        double renderZ = targetPos.z - cameraPos.z;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();

        matrices.push();
        matrices.translate(renderX, renderY, renderZ);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-mc.gameRenderer.getCamera().getYaw()));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(mc.gameRenderer.getCamera().getPitch()));

        float size = this.crosshairSize.getCurrent() * 0.5F;
        int alpha = (int) (255.0F * this.aimProgress);
        int color = SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB();
        int r = color >> 16 & 0xFF;
        int g = color >> 8 & 0xFF;
        int b = color & 0xFF;

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buffer.vertex(matrix, -size, -size, 0).color(r, g, b, alpha);
        buffer.vertex(matrix, -size, size, 0).color(r, g, b, alpha);
        buffer.vertex(matrix, size, size, 0).color(r, g, b, alpha);
        buffer.vertex(matrix, size, -size, 0).color(r, g, b, alpha);
        BufferRenderer.drawWithGlobalProgram(buffer.end());

        matrices.pop();

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }

    @EventTarget
    public void onGameUpdate(EventGameUpdate ignored) {
        if (!this.isEnabled() || mc.player == null || mc.world == null) {
            return;
        }

        this.isAiming = this.isUsingBowOrCrossbow();

        if (this.isAiming) {
            LivingEntity newTarget = this.findBestTarget();

            if (newTarget != null) {
                if (this.target != newTarget) {
                    this.target = newTarget;
                    this.aimProgress = 0.0F;
                }

                Rotation newRotation = this.calculateBowRotation(this.target);
                float maxStep = 1.0F / Math.max(1.0F, this.aimTime.getCurrent());
                this.aimProgress = Math.min(this.aimProgress + maxStep, 1.0F);

                float currentYaw = mc.player.getYaw();
                float currentPitch = mc.player.getPitch();
                float targetYaw = newRotation.getYaw();
                float targetPitch = newRotation.getPitch();

                float yawDiff = MathHelper.wrapDegrees(targetYaw - currentYaw);
                float pitchDiff = targetPitch - currentPitch;

                float stepYaw = yawDiff * this.aimProgress;
                float stepPitch = pitchDiff * this.aimProgress;

                this.targetRotation = new Rotation(currentYaw + stepYaw, currentPitch + stepPitch);
            }
        } else {
            this.target = null;
            this.targetRotation = null;
            this.aimProgress = 0.0F;
        }

        if (this.target != null && this.isAiming && this.targetRotation != null) {
            if (this.silentRotations.isEnabled()) {
                float yaw = Rotation.applyGCD(this.targetRotation.getYaw(), mc.player.getYaw());
                float pitch = Rotation.applyGCD(this.targetRotation.getPitch(), mc.player.getPitch());
                RotationComponent.update(new Rotation(yaw, pitch), 180.0F, 180.0F, 45.0F, 45.0F, 0, 2, false);
            } else {
                mc.player.setYaw(this.targetRotation.getYaw());
                mc.player.setPitch(this.targetRotation.getPitch());
            }
        }
    }

    public LivingEntity getTarget() {
        return this.target;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.target = null;
        this.isAiming = false;
        this.aimProgress = 0.0F;
        this.targetRotation = null;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.target = null;
        this.isAiming = false;
        this.aimProgress = 0.0F;
        this.targetRotation = null;
    }
}
