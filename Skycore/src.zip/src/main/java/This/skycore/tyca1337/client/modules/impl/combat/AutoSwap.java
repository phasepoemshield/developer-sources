package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.input.EventKey;
import This.skycore.base.events.impl.player.EventMoveInput;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.KeySetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;

/**
 * Быстрая смена предметов в офф-хенде по бинду (как Wonderful AutoSwap).
 */
@ModuleAnnotation(
        name = "AutoSwap",
        category = Category.COMBAT,
        description = "Быстрая смена предметов в офф-хенде"
)
public final class AutoSwap extends Module {

    public static final AutoSwap INSTANCE = new AutoSwap();

    /** Слот оффхенда в {@link net.minecraft.screen.PlayerScreenHandler}. */
    private static final int OFFHAND_SLOT_ID = 45;

    private final ModeSetting firstItem = new ModeSetting("Первый предмет", "Руна", "Руна", "Тотем", "Шар", "Гепл", "Щит");
    private final ModeSetting secondItem = new ModeSetting("Второй предмет", "Тотем", "Руна", "Тотем", "Шар", "Гепл", "Щит");
    private final KeySetting swapKey = new KeySetting("Кнопка свапа", -98);
    private final BooleanSetting bypassGrim = new BooleanSetting("Обходить Grim", true);

    private int bypassTicks;
    private boolean sprintPaused;
    private int swapCooldown;
    private int targetSlot = -1;
    private boolean needSwap;

    private AutoSwap() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.needSwap = false;
        this.targetSlot = -1;
        this.bypassTicks = 0;
        this.swapCooldown = 0;
        this.sprintPaused = false;
    }

    @EventTarget
    @Native
    public void onKey(EventKey event) {
        if (mc.currentScreen != null) {
            return;
        }
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (event.getAction() != 1) {
            return;
        }
        if (event.getKeyCode() != this.swapKey.getKeyCode() || this.swapKey.getKeyCode() == -1) {
            return;
        }
        if (this.swapCooldown == 0) {
            this.needSwap = true;
        }
    }

    @EventTarget
    @Native
    public void onMoveInput(EventMoveInput e) {
        if (!this.bypassGrim.isEnabled() || this.bypassTicks <= 0) {
            return;
        }
        if (mc.player == null) {
            return;
        }
        mc.player.setSprinting(false);
        e.setForward(0.0F);
        e.setStrafe(0.0F);
    }

    @EventTarget
    @Native
    public void onUpdate(EventUpdate e) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (this.swapCooldown > 0) {
            this.swapCooldown--;
        }

        if (this.bypassGrim.isEnabled() && this.bypassTicks > 0) {
            mc.player.setSprinting(false);
            mc.options.sprintKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sneakKey.setPressed(false);
            this.bypassTicks--;

            if (this.bypassTicks == 1) {
                this.performSwap();
            }

            if (this.bypassTicks == 0) {
                this.restoreSprint();
            }
            return;
        }

        if (this.needSwap && this.targetSlot == -1) {
            this.needSwap = false;

            Item offhand = mc.player.getOffHandStack().getItem();
            Item first = this.getItem(this.firstItem.get());
            Item second = this.getItem(this.secondItem.get());

            int firstSlot = this.findItemSlot(first);
            int secondSlot = this.findItemSlot(second);

            if (firstSlot == -1 && secondSlot == -1) {
                return;
            }

            int slot;
            if (offhand == first && secondSlot != -1) {
                slot = secondSlot;
            } else if (firstSlot != -1) {
                slot = firstSlot;
            } else {
                slot = secondSlot;
            }

            if (slot == -1) {
                return;
            }

            this.targetSlot = slot;

            if (this.bypassGrim.isEnabled()) {
                this.disableSprint();
                this.bypassTicks = 2;
                this.swapCooldown = 2;
            } else {
                this.performSwap();
                this.swapCooldown = 2;
            }
        }
    }

    private void performSwap() {
        if (this.targetSlot == -1) {
            return;
        }
        this.doSwap(this.targetSlot);
        int syncId = mc.player.currentScreenHandler.syncId;
        mc.player.networkHandler.sendPacket(new CloseHandledScreenC2SPacket(syncId));
        this.targetSlot = -1;
    }

    private void doSwap(int slot) {
        int syncId = mc.player.currentScreenHandler.syncId;
        if (slot >= 36 && slot <= 44) {
            int hotbarSlot = slot - 36;
            mc.interactionManager.clickSlot(syncId, OFFHAND_SLOT_ID, hotbarSlot, SlotActionType.SWAP, mc.player);
        } else {
            mc.interactionManager.clickSlot(syncId, slot, 0, SlotActionType.SWAP, mc.player);
            mc.interactionManager.clickSlot(syncId, OFFHAND_SLOT_ID, 0, SlotActionType.SWAP, mc.player);
            mc.interactionManager.clickSlot(syncId, slot, 0, SlotActionType.SWAP, mc.player);
        }
    }

    private int findItemSlot(Item item) {
        if (item == Items.AIR) {
            return -1;
        }
        for (int i = 9; i < 45; i++) {
            ItemStack stack = mc.player.playerScreenHandler.getSlot(i).getStack();
            if (stack.getItem() == item) {
                return i;
            }
        }
        return -1;
    }

    private Item getItem(String name) {
        return switch (name) {
            case "Руна" -> Items.FIREWORK_STAR;
            case "Тотем" -> Items.TOTEM_OF_UNDYING;
            case "Шар" -> Items.PLAYER_HEAD;
            case "Гепл" -> Items.GOLDEN_APPLE;
            case "Щит" -> Items.SHIELD;
            default -> Items.AIR;
        };
    }

    private void disableSprint() {
        if (this.sprintPaused) {
            return;
        }
        this.sprintPaused = true;
        mc.options.sprintKey.setPressed(false);
        mc.player.setSprinting(false);
    }

    private void restoreSprint() {
        if (!this.sprintPaused) {
            return;
        }
        this.sprintPaused = false;
    }

    @Override
    public void onDisable() {
        this.bypassTicks = 0;
        this.swapCooldown = 0;
        this.needSwap = false;
        this.targetSlot = -1;
        this.restoreSprint();
        super.onDisable();
    }
}
