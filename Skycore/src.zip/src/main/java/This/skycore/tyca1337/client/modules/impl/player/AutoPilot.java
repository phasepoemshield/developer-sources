package This.skycore.tyca1337.client.modules.impl.player;

public class AutoPilot {
}
