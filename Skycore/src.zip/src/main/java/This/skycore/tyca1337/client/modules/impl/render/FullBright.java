package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(
   name = "Brightness",
   category = Category.RENDER,
   description = "Максимальное освещение"
)
public final class FullBright extends Module {
   public static final FullBright INSTANCE = new FullBright();

   private final ModeSetting mode = new ModeSetting("Режим", "Фиксирующий", "Фиксирующий", "Гамма", "Эффект");
   private final NumberSetting strengthSlider = new NumberSetting("Сила яркости", 1.0F, 0.1F, 2.0F, 0.01F);

   private FullBright() {
   }

   @EventTarget
   private void onUpdate(EventUpdate event) {
      updateBrightness();
   }

   private void updateBrightness() {
      if (mc.player != null && !mode.is("Эффект") && mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
         mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
      }

      if (mode.is("Эффект")) {
         if (mc.player != null) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1337, 1, false, false));
         }
      } else if (mode.is("Гамма")) {
         mc.options.getGamma().setValue(1000.0D);
      } else if (mode.is("Фиксирующий")) {
         mc.options.getGamma().setValue((double)strengthSlider.getCurrent());
      }
   }

   @Override
   public void onEnable() {
      super.onEnable();
      updateBrightness();
   }

   @Override
   public void onDisable() {
      if (mc.player != null) {
         mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
      }
      if (mc.options != null) {
         mc.options.getGamma().setValue(1.0D);
      }
      super.onDisable();
   }
}
