package This.skycore.tyca1337.client.modules.api;

import lombok.Generated;

public enum Category {
   COMBAT("Combat", "l"),
   MOVEMENT("Movement", "m"), RENDER("Render", "i"),
   PLAYER("Player", "b"),
   MISC("Misc", "j"),
   THEMES("Themes", "s");

   private final String name;
   private final String icon;

   private Category(String name, String icon) {
      this.name = name;
      this.icon = icon;
   }

   @Generated
   public String getIcon() {
      return this.icon;
   }

   @Generated
   public String getName() {
      return this.name;
   }


   private static Category[] $values() {
      return new Category[]{COMBAT, MOVEMENT, PLAYER, RENDER, MISC, THEMES};
   }
}
