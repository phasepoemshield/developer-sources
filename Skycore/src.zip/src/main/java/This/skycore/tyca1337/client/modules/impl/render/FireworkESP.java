package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import This.skycore.base.font.Fonts;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.render.EventRender2D;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.animation.client.ClientAnimationUtil;
import This.skycore.util.animation.client.ClientEasings;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.math.ProjectionUtil;
import This.skycore.util.math.Timer;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@ModuleAnnotation(
        name = "FireworkESP",
        category = Category.RENDER,
        description = "Метка на экране при запуске фейерверка"
)
public final class FireworkESP extends Module implements IMinecraft {

    public static final FireworkESP INSTANCE = new FireworkESP();

    private final BooleanSetting time = new BooleanSetting("Отображать время", true);
    private final List<Firework> fireworks = new CopyOnWriteArrayList<>();

    private FireworkESP() {
    }

    @EventTarget
    private void onUpdate(EventUpdate e) {
        if (mc.world == null) {
            fireworks.clear();
        }
    }

    @EventTarget
    private void onPacket(EventPacket e) {
        if (!this.isEnabled() || !e.isReceive() || !(e.getPacket() instanceof PlaySoundS2CPacket packet)) {
            return;
        }
        if (mc.world == null) {
            return;
        }
        Identifier sid = mc.world.getRegistryManager().getOrThrow(RegistryKeys.SOUND_EVENT).getId(packet.getSound().value());
        if (sid == null || !sid.equals(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH.id())) {
            return;
        }
        Vec3d pos = new Vec3d(packet.getX(), packet.getY(), packet.getZ());
        if (!hasActiveFireworkInRadius(pos, 5.0)) {
            fireworks.add(new Firework(pos));
        }
    }

    @EventTarget
    private void onRender2D(EventRender2D e) {
        if (!this.isEnabled() || mc.world == null || fireworks.isEmpty()) {
            return;
        }
        updateAndCleanFireworks();
        CustomDrawContext ctx = e.getContext();
        for (Firework firework : fireworks) {
            firework.updateAlpha();
            Vec3d pos = firework.getPosition();
            Vec3d screen = ProjectionUtil.worldSpaceToScreenSpace(pos);
            if (screen.z <= 0.0 || screen.z >= 1.0) {
                continue;
            }
            renderFirework(ctx, firework, (float) screen.x, (float) screen.y, this.time.isEnabled());
        }
    }

    private void renderFirework(CustomDrawContext ctx, Firework firework, float posX, float posY, boolean showTime) {
        float alpha = firework.getAlpha();
        float bx = posX - 20.0F;
        float by = posY;
        var font = Fonts.INTER.getFont(7.0F);
        String timeStr = String.format("%.1f сек", Math.max(0.0, (firework.getLifetimeMs() - firework.timer.getElapsedTime()) / 1000.0));
        float boxW = showTime ? Math.max(28.0F, font.width(timeStr) + 18.0F) : 10.0F;
        int a = (int) (120 * alpha);
        int c = (int) (255 * alpha);

        DrawUtil.drawRoundedRect(ctx.getMatrices(), bx, by, boxW, 11.0F, BorderRadius.ZERO, new ColorRGBA(0, 0, 0, a));
        DrawUtil.drawTexture(ctx.getMatrices(), Identifier.ofVanilla("textures/item/firework_rocket.png"), bx + 0.5F, by + 1.5F, 8.0F, 8.0F, new ColorRGBA(255, 255, 255, c));
        if (showTime) {
            ctx.drawText(font, timeStr, bx + 11.0F, by + 3.0F, new ColorRGBA(255, 255, 255, c));
        }
    }

    private boolean hasActiveFireworkInRadius(Vec3d position, double radius) {
        double r2 = radius * radius;
        return fireworks.stream().filter(Firework::isActive).anyMatch(f -> f.getPosition().squaredDistanceTo(position) <= r2);
    }

    private void updateAndCleanFireworks() {
        fireworks.removeIf(firework -> {
            if (firework.timer.getElapsedTime() >= firework.getLifetimeMs()) {
                if (!firework.isFading()) {
                    firework.startFade();
                }
                return firework.shouldRemove();
            }
            return false;
        });
    }

    @Override
    public void onDisable() {
        fireworks.clear();
        super.onDisable();
    }

    public static final class Firework {
        private final Vec3d position;
        private final Timer timer = new Timer();
        private final long lifetimeMs = 5000L;
        private boolean fading;
        private final ClientAnimationUtil alpha = new ClientAnimationUtil(1.0f, 6.0f, ClientEasings.LINEAR);

        Firework(Vec3d position) {
            this.position = position;
        }

        void startFade() {
            if (!fading) {
                fading = true;
                alpha.update(0.0f);
            }
        }

        boolean isFading() {
            return fading;
        }

        boolean shouldRemove() {
            return fading && alpha.isDone();
        }

        float getAlpha() {
            return alpha.getValue();
        }

        void updateAlpha() {
            if (fading) {
                alpha.update(0.0f);
            }
        }

        boolean isActive() {
            return !fading || getAlpha() > 0.1f;
        }

        Vec3d getPosition() {
            return position;
        }

        long getLifetimeMs() {
            return lifetimeMs;
        }
    }
}
