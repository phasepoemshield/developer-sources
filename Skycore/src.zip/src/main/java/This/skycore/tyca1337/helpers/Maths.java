package This.skycore.tyca1337.helpers;

import lombok.experimental.UtilityClass;
import net.minecraft.util.math.MathHelper;
import org.joml.Vector3d;

import java.math.BigDecimal;
import java.math.RoundingMode;

@UtilityClass
public class Maths implements QuickImports {
    public static FastRandom fastRandomize = new FastRandom();

    public double roundHalfUp(double num, double increment) {
        double v = (double) java.lang.Math.round(num / increment) * increment;
        BigDecimal bd = new BigDecimal(v);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    public float interpolate(double oldValue, double newValue, double interpolationValue){
        return (float) (oldValue + (newValue - oldValue) * interpolationValue);
    }

    public int getPercentage(int percentage, int totalValue) {
        return (int) (totalValue * (percentage / 100.0F));
    }
    public float randomNew(double min, double max) {
        if (min > max) return (float) (fastRandomize.nextFloat() * (min - max) + max);
        return (float) (fastRandomize.nextFloat() * (max - min) + min);
    }


    public int lerp(int input, int target, double step) {
        return (int) (input + step * (target - input));
    }

    public double round(double target, int decimal) {
        return Math.round(target * Math.pow(10, decimal)) / Math.pow(10, decimal);
    }
    public float random(float min, float max) {
        return (new CustRandom().randomNumber(0,1,false) * (max - min) + min);
    }
    public double randomSimple(double min, double max) {
        return (Math.random() * (max - min)) + min;
    }
    public int randomInt(int min, int max) {
        return (int) (min + (max - min) * Math.random());
    }



    public <T extends Number> T lerp(T input, T target, double step) {
        double start = input.doubleValue();
        double end = target.doubleValue();
        double result = start + step * (end - start);

        if (input instanceof Integer) {
            return (T) Integer.valueOf((int) Math.round(result));
        } else if (input instanceof Double) {
            return (T) Double.valueOf(result);
        } else if (input instanceof Float) {
            return (T) Float.valueOf((float) result);
        } else if (input instanceof Long) {
            return (T) Long.valueOf(Math.round(result));
        } else if (input instanceof Short) {
            return (T) Short.valueOf((short) Math.round(result));
        } else if (input instanceof Byte) {
            return (T) Byte.valueOf((byte) Math.round(result));
        } else {
            throw new IllegalArgumentException("Unsupported type: " + input.getClass().getSimpleName());
        }
    }

    public static float wrapAngleTo180(float v) {
        return 0;
    }
}
