package This.skycore.tyca1337.client.modules.impl.render;

import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.util.client.PackCustomSkyPreference;
import This.skycore.util.render.sky.OptifineSkyLoader;

/**
 * Небо из ресурс-пака (OptiFine {@code optifine/sky/world0|world1}).
 * С Sodium часто недоступен пункт в настройках графики — включай здесь.
 */
@ModuleAnnotation(
        name = "CustomSky",
        category = Category.RENDER,
        description = "Небо из RP (OptiFine sky). Дубль: настройки графики Minecraft"
)
public final class CustomSky extends Module {
    public static final CustomSky INSTANCE = new CustomSky();

    private CustomSky() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        OptifineSkyLoader.INSTANCE.reloadFromClient();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        OptifineSkyLoader.INSTANCE.reloadFromClient();
    }

    /** Модуль включён или флаг из настроек графики / {@code skycore_optifine_sky.txt}. */
    public static boolean affectsSky() {
        return INSTANCE.isEnabled() || PackCustomSkyPreference.isEnabled();
    }
}
