package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.impl.combat.Aura;
import This.skycore.util.interfaces.IMinecraft;

@ModuleAnnotation(
        name = "KillEffect",
        category = Category.RENDER,
        description = "Молния при убийстве цели из AttackAura"
)
public final class KillEffect extends Module implements IMinecraft {

    public static final KillEffect INSTANCE = new KillEffect();

    private LivingEntity trackedTarget;
    private int trackedId = Integer.MIN_VALUE;
    private double lastX;
    private double lastY;
    private double lastZ;
    private boolean lightningSpawned;
    private int ticksSinceLostTarget;
    private boolean hadTarget;

    private KillEffect() {
    }

    @EventTarget
    private void onUpdate(EventUpdate e) {
        if (!this.isEnabled() || mc.player == null || mc.world == null) {
            return;
        }

        LivingEntity current = Aura.INSTANCE.getTarget();

        if (current != null) {
            if (current.getId() != trackedId) {
                trackedTarget = current;
                trackedId = current.getId();
                lightningSpawned = false;
                ticksSinceLostTarget = 0;
            }

            hadTarget = true;

            if (current.isAlive() && !current.isRemoved()) {
                lastX = current.getX();
                lastY = current.getY();
                lastZ = current.getZ();
            }

            if (!lightningSpawned && isDeadOrRemoved(current)) {
                spawnLightning(lastX, lastY, lastZ);
                lightningSpawned = true;
            }
            return;
        }

        if (trackedTarget != null && !lightningSpawned) {
            if (trackedTarget.isAlive() && !trackedTarget.isRemoved()) {
                lastX = trackedTarget.getX();
                lastY = trackedTarget.getY();
                lastZ = trackedTarget.getZ();
            }

            if (isDeadOrRemoved(trackedTarget)) {
                spawnLightning(lastX, lastY, lastZ);
                lightningSpawned = true;
            } else if (hadTarget) {
                ticksSinceLostTarget++;
                if (ticksSinceLostTarget > 20) {
                    resetTracking();
                }
            }
        }

        if (current == null && lightningSpawned) {
            ticksSinceLostTarget++;
            if (ticksSinceLostTarget > 5) {
                resetTracking();
            }
        }
    }

    private static boolean isDeadOrRemoved(LivingEntity entity) {
        if (entity == null) {
            return true;
        }
        return !entity.isAlive() || entity.isRemoved() || entity.getHealth() <= 0.0F;
    }

    private void spawnLightning(double x, double y, double z) {
        ClientWorld world = mc.world;
        if (world == null) {
            return;
        }

        LightningEntity bolt = new LightningEntity(EntityType.LIGHTNING_BOLT, world);
        bolt.refreshPositionAfterTeleport(x, y, z);
        bolt.setCosmetic(true);
        world.addEntity(bolt);

        world.playSound(x, y, z, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.WEATHER, 0.8F, 0.5F, false);
        world.playSound(x, y, z, SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.WEATHER, 0.8F, 0.5F, false);
    }

    private void resetTracking() {
        trackedTarget = null;
        trackedId = Integer.MIN_VALUE;
        lightningSpawned = false;
        ticksSinceLostTarget = 0;
        hadTarget = false;
    }

    @Override
    public void onDisable() {
        resetTracking();
        super.onDisable();
    }
}
