package This.skycore.tyca1337.helpers;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import This.skycore.util.interfaces.IMinecraft;

public final class AuraUtil implements IMinecraft {

    private AuraUtil() {
    }

    public static Vec3d getClosestVec(Vec3d vec, Box box) {
        return new Vec3d(
                MathHelper.clamp(vec.x, box.minX, box.maxX),
                MathHelper.clamp(vec.y, box.minY, box.maxY),
                MathHelper.clamp(vec.z, box.minZ, box.maxZ)
        );
    }

    public static Vec3d getClosestVec(Vec3d vec, Entity entity) {
        return getClosestVec(vec, entity.getBoundingBox());
    }

    public static Vec3d getClosestVec(Entity entity) {
        Vec3d eye = mc.player.getEyePos();
        return getClosestVec(eye, entity).subtract(eye);
    }

    public static double getStrictDistance(Entity entity) {
        return getClosestVec(entity).length();
    }
}
