package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import This.skycore.base.events.impl.player.EventPostUpdate;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.helpers.AttackOrder;
import This.skycore.tyca1337.helpers.CrystalOptimizerState;
import This.skycore.tyca1337.helpers.EventClick;
import This.skycore.tyca1337.helpers.EventPlace;
import This.skycore.tyca1337.helpers.InventoryUtil;
import This.skycore.util.component.RotationComponent;
import This.skycore.util.game.player.rotation.Rotation;

import static java.lang.Math.hypot;

@ModuleAnnotation(
        name = "AutoExplosion",
        category = Category.COMBAT,
        description = "Автоматически взрывает кристаллы"
)
public final class AutoExplosion extends Module {
    public static final AutoExplosion INSTANCE = new AutoExplosion();

    private BlockPos targetPos;
    private int targetSlot;
    private int oldSlot;
    private boolean needSync;
    private Box crystalArea;
    private boolean blocked;
    private int explodeTicks;
    private int pendingCrystalId = -1;
    private Vec3d pendingCrystalPos;
    private int pendingCrystalTicks;
    private int ignoreClickTicks;

    private final BooleanSetting test = new BooleanSetting("Взрыв по пкм", true);
    private final BooleanSetting fast = new BooleanSetting("Быстрый", true);
    private final BooleanSetting noExplodeResources = new BooleanSetting("Не взрывать ресурсы", false);

    private AutoExplosion() {
    }

    private boolean proverkacrystala() {
        return CrystalOptimizerState.Rabotaet;
    }

    @EventTarget
    public void onPlace(EventPlace e) {
        if (proverkacrystala()) {
            return;
        }

        if (e.getBlock() == Blocks.OBSIDIAN) {
            if (mc.player.getItemCooldownManager().isCoolingDown(Items.END_CRYSTAL.getDefaultStack())) {
                return;
            }
            int slotInHotBar = InventoryUtil.getSlot(Items.END_CRYSTAL);
            if (slotInHotBar == -1 || slotInHotBar >= 9) {
                return;
            }
            targetPos = e.getPos();
            targetSlot = slotInHotBar;
            crystalArea = new Box(targetPos.up()).expand(fast.isEnabled() ? 0.5D : 0.1D);
            explodeTicks = fast.isEnabled() ? 5 : 3;
            attackCrystalInArea();
            blocked = true;
            ignoreClickTicks = 8;
        }
    }

    @EventTarget
    private void onUpdate(EventUpdate e) {
        if (ignoreClickTicks > 0) {
            ignoreClickTicks--;
        }

        if (!proverkacrystala()) {
            if (needSync) {
                needSync = false;
                InventoryUtil.switchToHotbarSlot(oldSlot);
            } else if (targetPos != null) {
                if (mc.world.getBlockState(targetPos).isAir()) {
                    targetPos = null;
                } else if (blocked) {
                    blocked = false;
                } else {
                    Vec3d eyeVec = mc.player.getEyePos();
                    Vec3d hitVec = closestVec(eyeVec, new Box(targetPos));
                    Vec3d offset = hitVec.subtract(eyeVec);
                    float targetYaw = MathHelper.wrapDegrees((float)(Math.toDegrees(Math.atan2(offset.z, offset.x)) - 90.0D));
                    float targetPitch = (float)(-Math.toDegrees(Math.atan2(offset.y, hypot(offset.x, offset.z))));
                    RotationComponent.update(new Rotation(targetYaw, targetPitch), 180.0F, 1.0F, 1, 6);

                    oldSlot = mc.player.getInventory().selectedSlot;
                    InventoryUtil.switchToHotbarSlot(targetSlot);

                    offset = offset.negate();
                    mc.interactionManager.interactBlock(
                            mc.player,
                            Hand.MAIN_HAND,
                            new BlockHitResult(hitVec, Direction.getFacing(offset.x, offset.y, offset.z), targetPos, false)
                    );
                    mc.player.swingHand(Hand.MAIN_HAND);

                    crystalArea = new Box(targetPos.up()).expand(fast.isEnabled() ? 0.5D : 0.1D);
                    explodeTicks = fast.isEnabled() ? 5 : 3;
                    attackCrystalInArea();

                    needSync = true;
                    targetPos = null;
                }
            }
        }

        if (explodeTicks > 0) {
            explodeTicks--;
        }
        tryAttackPendingCrystal();
        if (crystalArea != null) {
            attackCrystalInArea();
        }
    }

    private void attackCrystalInArea() {
        if (crystalArea == null || mc.player == null || mc.world == null) {
            return;
        }

        for (EndCrystalEntity entity : mc.world.getEntitiesByClass(
                EndCrystalEntity.class,
                crystalArea.expand(0.25D),
                Entity::isAlive
        )) {
            if (shouldNotExplodeBecauseOfResources(entity)) {
                crystalArea = null;
                return;
            }

            if (!fast.isEnabled() && !entity.getBoundingBox().contains(mc.player.getEyePos())) {
                Vec3d direction = getVector(entity);
                float targetYaw = MathHelper.wrapDegrees((float)(Math.toDegrees(Math.atan2(direction.z, direction.x)) - 90.0D));
                float targetPitch = (float)(-Math.toDegrees(Math.atan2(direction.y, hypot(direction.x, direction.z))));
                RotationComponent.update(new Rotation(targetYaw, targetPitch), 180.0F, 1.0F, 1, 6);
            }
            attackCrystal(entity);
            crystalArea = null;
            return;
        }
    }

    private void attackCrystal(Entity entity) {
        if (entity == null || mc.player == null) {
            return;
        }
        AttackOrder.sendFixedAttack(mc.player, entity);
    }

    private void tryAttackPendingCrystal() {
        if (pendingCrystalTicks <= 0 || mc.world == null) {
            return;
        }
        pendingCrystalTicks--;

        Entity byId = pendingCrystalId == -1 ? null : mc.world.getEntityById(pendingCrystalId);
        if (byId instanceof EndCrystalEntity crystalById && !shouldNotExplodeBecauseOfResources(crystalById)) {
            attackCrystal(crystalById);
            clearPending();
            return;
        }

        if (pendingCrystalPos != null) {
            Box spawnBox = new Box(
                    pendingCrystalPos.x - 0.8D, pendingCrystalPos.y - 0.8D, pendingCrystalPos.z - 0.8D,
                    pendingCrystalPos.x + 0.8D, pendingCrystalPos.y + 1.8D, pendingCrystalPos.z + 0.8D
            );
            for (EndCrystalEntity crystal : mc.world.getEntitiesByClass(EndCrystalEntity.class, spawnBox, Entity::isAlive)) {
                if (shouldNotExplodeBecauseOfResources(crystal)) {
                    continue;
                }
                attackCrystal(crystal);
                clearPending();
                return;
            }
        }
    }

    @EventTarget
    private void onPacket(EventPacket event) {
        if (!event.isReceive()) {
            return;
        }
        if (!(event.getPacket() instanceof EntitySpawnS2CPacket packet)) {
            return;
        }
        if (packet.getEntityType() != EntityType.END_CRYSTAL || crystalArea == null) {
            return;
        }

        double px = packet.getX();
        double py = packet.getY();
        double pz = packet.getZ();
        if (!crystalArea.expand(0.5D).contains(px, py, pz)) {
            return;
        }

        if (fast.isEnabled() && mc.world != null) {
            pendingCrystalId = packet.getEntityId();
            pendingCrystalPos = new Vec3d(px, py, pz);
            pendingCrystalTicks = 8;
            tryAttackPendingCrystal();

            Entity spawned = mc.world.getEntityById(packet.getEntityId());
            if (spawned instanceof EndCrystalEntity crystal && !shouldNotExplodeBecauseOfResources(crystal)) {
                attackCrystal(crystal);
                clearPending();
                return;
            }
        }

        explodeTicks = fast.isEnabled() ? 7 : 3;
        attackCrystalInArea();
    }

    @EventTarget
    private void onClick(EventClick e) {
        if (proverkacrystala() || !test.isEnabled()) {
            return;
        }
        if (ignoreClickTicks > 0 || targetPos != null || needSync || blocked) {
            return;
        }

        int slotCrystal = InventoryUtil.getItemSlot(Items.END_CRYSTAL);
        if (slotCrystal == -1) {
            return;
        }

        Item mainItem = mc.player.getMainHandStack().getItem();
        Item offItem = mc.player.getOffHandStack().getItem();
        if ((mainItem instanceof BlockItem && mainItem != Items.PLAYER_HEAD)
                || (offItem instanceof BlockItem && offItem != Items.PLAYER_HEAD)) {
            return;
        }

        if (!(e.getHitResult() instanceof BlockHitResult blockRayTraceResult)) {
            return;
        }

        BlockPos clickPos = blockRayTraceResult.getBlockPos();
        if (mc.world.getBlockState(clickPos).isOf(Blocks.OBSIDIAN)
                && mc.world.getBlockState(clickPos.up()).isAir()) {
            int containerSlot = slotCrystal < 9 ? slotCrystal + 36 : slotCrystal;
            mc.interactionManager.clickSlot(0, containerSlot, 40, SlotActionType.SWAP, mc.player);
            mc.interactionManager.interactBlock(mc.player, Hand.OFF_HAND, blockRayTraceResult);
            mc.interactionManager.clickSlot(0, containerSlot, 40, SlotActionType.SWAP, mc.player);
            crystalArea = new Box(clickPos.up()).expand(fast.isEnabled() ? 0.5D : 0.1D);
            explodeTicks = fast.isEnabled() ? 5 : 3;
            attackCrystalInArea();
            e.setCancelled(true);
        }
    }

    @EventTarget
    private void onPostUpdate(EventPostUpdate e) {
        // как в sky.core 1.16.5 — взрыв перенесён в EventUpdate
    }

    private boolean shouldNotExplodeBecauseOfResources(Entity crystalEntity) {
        if (!noExplodeResources.isEnabled() || mc.world == null) {
            return false;
        }

        return mc.world.getEntitiesByClass(ItemEntity.class, crystalEntity.getBoundingBox().expand(6.0D), Entity::isAlive)
                .stream()
                .map(item -> item.getStack().getItem())
                .anyMatch(item -> item == Items.TOTEM_OF_UNDYING
                        || item == Items.END_CRYSTAL
                        || item == Items.ENCHANTED_GOLDEN_APPLE
                        || item == Items.NETHERITE_HELMET
                        || item == Items.NETHERITE_CHESTPLATE
                        || item == Items.NETHERITE_LEGGINGS
                        || item == Items.NETHERITE_BOOTS
                        || item == Items.NETHERITE_SWORD
                        || item == Items.DIAMOND_SWORD
                        || item == Items.ELYTRA
                        || item == Items.TRIDENT);
    }

    private static Vec3d closestVec(Vec3d vec, Box box) {
        return new Vec3d(
                MathHelper.clamp(vec.x, box.minX, box.maxX),
                MathHelper.clamp(vec.y, box.minY, box.maxY),
                MathHelper.clamp(vec.z, box.minZ, box.maxZ)
        );
    }

    private static Vec3d getVector(Entity entity) {
        Vec3d eye = mc.player.getEyePos();
        double y = MathHelper.lerp(
                MathHelper.clamp(eye.distanceTo(entity.getPos().add(0.0D, entity.getEyeHeight(entity.getPose()), 0.0D)) / 3.0D, 0.0D, 1.0D),
                entity.getBoundingBox().minY,
                MathHelper.clamp(eye.y, entity.getBoundingBox().minY, entity.getBoundingBox().maxY)
        );
        Vec3d raw = new Vec3d(entity.getX(), y, entity.getZ()).subtract(eye);
        return raw.normalize().multiply(eye.distanceTo(entity.getEyePos()));
    }

    private void clearPending() {
        pendingCrystalId = -1;
        pendingCrystalPos = null;
        pendingCrystalTicks = 0;
        crystalArea = null;
    }

    private void resetAll() {
        targetPos = null;
        crystalArea = null;
        blocked = false;
        needSync = false;
        explodeTicks = 0;
        pendingCrystalId = -1;
        pendingCrystalPos = null;
        pendingCrystalTicks = 0;
        ignoreClickTicks = 0;
    }

    @Override
    public void onDisable() {
        resetAll();
        super.onDisable();
    }
}
