package This.skycore.tyca1337.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import This.skycore.base.events.impl.other.EventTick;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.impl.combat.Aura;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.util.game.player.MovingUtil;

@ModuleAnnotation(
   name = "Sprint",
   category = Category.MOVEMENT,
   description = "Автоматически активирует режим бега, когда игрок начинает двигаться"
)
public final class AutoSprint extends Module {
   public static final AutoSprint INSTANCE = new AutoSprint();
   private final ModeSetting mode = new ModeSetting("Мод", "Обычный", "Пакетный");
   private final BooleanSetting water = new BooleanSetting("Спринт в воде", false);

   private AutoSprint() {
   }

   @EventTarget
   public void onUpdate(EventTick event) {
      if (mc.player == null || mc.world == null) return;
      if (!mode.is("Обычный")) return;

      // Prevent anti-cheat SprintE-style flags when pressing into blocks/using items.
      boolean inWater = mc.player.isTouchingWater() || mc.player.isSubmergedInWater();
      boolean safeToSprint = MovingUtil.hasPlayerMovement()
              && !mc.player.isGliding()
              && !mc.player.horizontalCollision
              && !mc.player.isSneaking()
              && !mc.player.isUsingItem()
              // Most servers expect liquid movement to be slower; forcing sprint in water often flags.
              && (water.isEnabled() || !inWater);

      boolean resetForCrits = Aura.INSTANCE.isEnabled()
              && Aura.INSTANCE.getTarget() != null
              && Aura.INSTANCE.onlyCriticals.isEnabled();

      if (resetForCrits) {
         if (canStopSprintForCrits() && safeToSprint) {
            mc.options.sprintKey.setPressed(true);
         } else {
            mc.options.sprintKey.setPressed(false);
            mc.player.setSprinting(false);
         }
      } else if (safeToSprint) {
         mc.options.sprintKey.setPressed(true);
      } else {
         mc.options.sprintKey.setPressed(false);
         mc.player.setSprinting(false);
      }
   }

   private boolean canStopSprintForCrits() {
      boolean liquidBlock = (mc.player.isTouchingWater() || mc.player.isSubmergedInWater());
      boolean inCobweb = mc.player.getBlockStateAtPos().isOf(Blocks.COBWEB);
      return inCobweb
              || mc.player.getAbilities().flying
              || liquidBlock
              || mc.player.hasVehicle()
              || (mc.player.fallDistance <= 0.0F && mc.player.isOnGround());
   }

   @Override
   public void onDisable() {
      if (mc.player != null) {
         mc.options.sprintKey.setPressed(false);
      }
      super.onDisable();
   }
}
