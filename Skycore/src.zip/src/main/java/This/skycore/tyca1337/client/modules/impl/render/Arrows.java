package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.HitResult;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.render.EventRender2D;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ColorSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.tyca1337.client.modules.impl.combat.AntiBot;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;

import java.util.HashMap;
import java.util.Map;

@ModuleAnnotation(
        name = "Arrows",
        description = "Рисует указатели на позиции разных существ",
        category = Category.RENDER
)
public final class Arrows extends Module {
    public static final Arrows INSTANCE = new Arrows();

    private static final Identifier TRIANGLE_TEX = SkyCore.id("icons/world_render/triangle.png");
    private static final float ARROW_SIZE = 46.0f;
    private static final long VISIBILITY_CACHE_MS = 125L;

    private final MultiBooleanSetting rendering = MultiBooleanSetting.create("Отображать",
            java.util.List.of("Игроков", "Друзей", "Голых", "Предметы"));

    private final ColorSetting playerColor = new ColorSetting("Цвет игроков", new ColorRGBA(-1),
            () -> this.rendering.isEnable("Игроков") || this.rendering.isEnable("Голых"));
    private final ColorSetting friendColor = new ColorSetting("Цвет друзей", new ColorRGBA(0xFF00FF00),
            () -> this.rendering.isEnable("Друзей"));
    private final ColorSetting itemColor = new ColorSetting("Цвет предметов", new ColorRGBA(0xFFFF0000),
            () -> this.rendering.isEnable("Предметы"));

    private final BooleanSetting onlyIfNotVisible = new BooleanSetting("Показывать только если не видишь", false);
    private final NumberSetting radius = new NumberSetting("Радиус", 40.0F, 30.0F, 80.0F, 5.0F);

    private final Map<Integer, VisibilityCacheEntry> visibilityCache = new HashMap<>();

    private Arrows() {
        // 1:1 defaults from SkyCore src new
        // "Голых" and "Предметы" are disabled by default there
        // MultiBooleanSetting defaults to true -> turn off here
        // (if setting name mismatch, harmless)
        // NOTE: MultiBooleanSetting in this codebase doesn't expose direct setter; user can toggle in GUI.
    }

    @EventTarget
    private void onRender2D(EventRender2D e) {
        if (mc.player == null || mc.world == null || mc.gameRenderer == null) return;
        if (mc.getDebugHud() != null && mc.getDebugHud().shouldShowDebugHud()) return;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            return;
        }

        CustomDrawContext ctx = e.getContext();
        float tickDelta = e.getTickDelta();

        double cos = Math.cos(Math.toRadians(mc.gameRenderer.getCamera().getYaw()));
        double sin = Math.sin(Math.toRadians(mc.gameRenderer.getCamera().getYaw()));

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        double baseRadius = this.radius.getCurrent();

        for (Entity entity : mc.world.getEntities()) {
            if (!isValidEntity(entity, tickDelta)) continue;

            double adjustedRadius = (entity instanceof ItemEntity) ? Math.max(baseRadius - 20.0, 0.0) : baseRadius;
            double xOffset = (sw / 2.0) - adjustedRadius;
            double yOffset = (sh / 2.0) - adjustedRadius;

            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            double ex = MathHelper.lerp(tickDelta, entity.lastRenderX, entity.getX());
            double ez = MathHelper.lerp(tickDelta, entity.lastRenderZ, entity.getZ());

            double xWay = (ex - cam.x) * 0.01D;
            double zWay = (ez - cam.z) * 0.01D;

            double rotationY = -(zWay * cos - xWay * sin);
            double rotationX = -(xWay * cos + zWay * sin);
            double angle = Math.toDegrees(Math.atan2(rotationY, rotationX));

            double x = (adjustedRadius * Math.cos(Math.toRadians(angle))) + xOffset + adjustedRadius;
            double y = (adjustedRadius * Math.sin(Math.toRadians(angle))) + yOffset + adjustedRadius;

            if (!isValidRotation(rotationX, rotationY, adjustedRadius)) continue;

            ColorRGBA tint = new ColorRGBA(determineEntityColor(entity));

            ctx.getMatrices().push();
            ctx.getMatrices().translate((float) x, (float) y, 0.0F);
            ctx.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) angle));
            DrawUtil.drawTexture(ctx.getMatrices(), TRIANGLE_TEX,
                    -ARROW_SIZE / 2.0f, -ARROW_SIZE / 2.0f, ARROW_SIZE, ARROW_SIZE, tint);
            ctx.getMatrices().pop();
        }
    }

    private boolean isValidEntity(Entity entity, float tickDelta) {
        if (!entity.isAlive() || entity == mc.player) return false;

        boolean isPlayerOrItem = isPlayerTarget(entity, true) || isItemTarget(entity);
        if (!isPlayerOrItem) return false;

        return !this.onlyIfNotVisible.isEnabled() || !isEntityVisible(entity, tickDelta);
    }

    private boolean isPlayerTarget(Entity entity, boolean considerNaked) {
        if (!(entity instanceof PlayerEntity player) || entity == mc.player) return false;

        if (AntiBot.INSTANCE.isEnabled() && AntiBot.bots.contains(player)) return false;

        boolean isFriend = SkyCore.getInstance().getFriendManager().isFriend(player.getName().getString());
        boolean isNaked = isAllArmorEmpty(player);

        if (isFriend) return this.rendering.isEnable("Друзей");
        if (considerNaked && isNaked) return this.rendering.isEnable("Голых");
        return this.rendering.isEnable("Игроков");
    }

    private boolean isAllArmorEmpty(PlayerEntity player) {
        for (var stack : player.getArmorItems()) {
            if (!stack.isEmpty()) return false;
        }
        return true;
    }

    private boolean isItemTarget(Entity entity) {
        return entity instanceof ItemEntity && this.rendering.isEnable("Предметы");
    }

    private boolean isEntityVisible(Entity entity, float tickDelta) {
        int entityId = entity.getId();
        long now = System.currentTimeMillis();

        VisibilityCacheEntry cached = visibilityCache.get(entityId);
        if (cached != null && (now - cached.timestampMs) <= VISIBILITY_CACHE_MS) {
            return cached.visible;
        }

        Vec3d start = mc.player.getEyePos();
        Vec3d end = entity.getPos().add(0.0, entity.getHeight() / 2.0, 0.0);

        RaycastContext context = new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player);
        HitResult result = mc.world.raycast(context);

        boolean visible = result.getType() == HitResult.Type.MISS;
        visibilityCache.put(entityId, new VisibilityCacheEntry(now, visible));
        return visible;
    }

    private int determineEntityColor(Entity entity) {
        if (entity instanceof PlayerEntity player) {
            boolean isFriend = SkyCore.getInstance().getFriendManager().isFriend(player.getName().getString());
            return isFriend ? this.friendColor.getIntColor() : this.playerColor.getIntColor();
        }
        if (entity instanceof ItemEntity) {
            return this.itemColor.getIntColor();
        }
        return this.playerColor.getIntColor();
    }

    private boolean isValidRotation(double rotationX, double rotationY, double r) {
        double mrotY = -rotationY;
        double mrotX = -rotationX;
        return MathHelper.sqrt((float) (mrotX * mrotX + mrotY * mrotY)) < r;
    }

    private record VisibilityCacheEntry(long timestampMs, boolean visible) {
    }
}

