package This.skycore.tyca1337.client.modules.impl.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4f;
import This.skycore.base.events.impl.render.EventRender3D;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;

import java.util.ArrayList;
import java.util.List;

public final class GhostTrailParticle implements IMinecraft {
    private static final float TAIL_LENGTH = 15.0f;

    private Vec3d position;
    private Vec3d motion;
    private final List<Vector4f> tail = new ArrayList<>();

    public GhostTrailParticle(Vec3d position, Vec3d motion) {
        this.position = position;
        this.motion = motion;
    }

    public void setMotion(Vec3d motion) {
        this.motion = motion;
    }

    public Vec3d getPosition() {
        return this.position;
    }

    public void update() {
        this.motion = this.motion.multiply(0.97);
    }

    public void render(EventRender3D e, Identifier texture, ColorRGBA color, float size, float renderAlpha) {
        this.position = this.position.add(this.motion);
        this.tail.add(new Vector4f((float) this.position.x, (float) this.position.y + 0.4f, (float) this.position.z, TAIL_LENGTH));

        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        MatrixStack ms = e.getMatrix();
        List<Vector4f> expired = new ArrayList<>();

        for (Vector4f point : this.tail) {
            if (point.w <= 0.0f) {
                expired.add(point);
                continue;
            }

            float miniSize = size * point.w / TAIL_LENGTH;
            int pointAlpha = (int) ((point.w / TAIL_LENGTH) * renderAlpha * 255.0f);
            if (pointAlpha <= 0) {
                expired.add(point);
                continue;
            }

            ms.push();
            ms.translate(point.x - cam.x, point.y - cam.y, point.z - cam.z);
            ms.multiply(mc.gameRenderer.getCamera().getRotation());
            DrawUtil.drawTexture(ms, texture, -miniSize / 2.0f, -miniSize / 2.0f, miniSize, miniSize, color.withAlpha(pointAlpha));
            ms.pop();

            point.y += 0.022f;
            point.w -= 0.40f;
        }

        this.tail.removeAll(expired);
    }
}

