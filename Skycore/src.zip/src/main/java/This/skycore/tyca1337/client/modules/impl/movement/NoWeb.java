package This.skycore.tyca1337.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.Vec3d;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.util.game.player.MovingUtil;
import This.skycore.util.game.player.PlayerIntersectionUtil;

@ModuleAnnotation(
   name = "NoWeb",
   category = Category.MOVEMENT,
   description = "Убирает вам замедление в паутине"
)

public class NoWeb extends Module {
    public static final NoWeb INSTANCE = new NoWeb();

    private final ModeSetting mode = new ModeSetting("Режим", new String[0]);
    private final ModeSetting.Value custom;
    private final ModeSetting.Value reallyWorld;

    private final NumberSetting speedXZ = new NumberSetting("Скорость по X и Z", 0.1F, 0.1F, 1.0F, 0.1F);
    private final NumberSetting speedY = new NumberSetting("Скорость по Y", 0.1F, 0.1F, 4.0F, 0.1F);

    private NoWeb() {
        this.custom = new ModeSetting.Value(this.mode, "Custom").select();
        this.reallyWorld = new ModeSetting.Value(this.mode, "ReallyWorld");
    }

    @EventTarget
    private void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (this.custom.isSelected()) {
            this.customMode();
        } else if (this.reallyWorld.isSelected()) {
            this.reallyWorldMode();
        }
    }

    private void customMode() {
        if (PlayerIntersectionUtil.isPlayerInBlock(Blocks.COBWEB)) {
            Vec3d velocity = mc.player.getVelocity();
            mc.player.setVelocity(velocity.x, 0.0D, velocity.z);

            if (mc.options.jumpKey.isPressed()) {
                mc.player.setVelocity(velocity.x, (double)this.speedY.getCurrent(), velocity.z);
            }

            if (mc.options.sneakKey.isPressed()) {
                mc.player.setVelocity(velocity.x, (double)(-this.speedY.getCurrent()), velocity.z);
            }

            MovingUtil.setVelocity((double)this.speedXZ.getCurrent());
        }
    }

    private void reallyWorldMode() {
        if (PlayerIntersectionUtil.isPlayerInBlock(Blocks.COBWEB)) {
            Vec3d velocity = mc.player.getVelocity();
            mc.player.setVelocity(velocity.x, 0.0D, velocity.z);

            if (mc.options.jumpKey.isPressed()) {
                mc.player.setVelocity(velocity.x, 0.9D, velocity.z);
            }

            if (mc.options.sneakKey.isPressed()) {
                mc.player.setVelocity(velocity.x, -0.9D, velocity.z);
            }

            MovingUtil.setVelocity(0.21D);
        }
    }
}
