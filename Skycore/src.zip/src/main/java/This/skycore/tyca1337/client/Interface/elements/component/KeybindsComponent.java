package This.skycore.tyca1337.client.Interface.elements.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.setting.Setting;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;

public class KeybindsComponent extends DraggableHudElement {

    private final Animation alphaAnimation = new Animation(100L, 0.0F, Easing.LINEAR);
    private final Animation widthAnimation = new Animation(100L, 90.0F, Easing.LINEAR);
    private final Map<String, Animation> entryAnimations = new HashMap<>();

    public KeybindsComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Native
    public void render(CustomDrawContext ctx) {
        float posX = this.getX();
        float posY = this.getY();

        List<ModuleKeybindEntry> entries = collectModuleKeybinds();
        boolean hasActive = entries.stream().anyMatch(ModuleKeybindEntry::active);
        boolean show = mc.currentScreen instanceof ChatScreen || hasActive;

        this.alphaAnimation.update(show ? 1.0F : 0.0F);
        float globalAlpha = this.alphaAnimation.getValue();
        if (globalAlpha <= 0.01F) {
            this.width = 90.0F;
            this.height = 25.0F;
            return;
        }

        float totalWidth = 180.0F / 2f;
        float paddingX = 12.0F / 2f;
        float paddingY = 15.0F / 2f;
        float gap = 15.0F / 2f;
        float itemGap = 12.0F / 2f;
        float borderRadius = 5.5F;
        float iconSize = 12.0F / 2f;
        float headerGap = 6.0F / 2f;
        float itemHeight = 14.0F / 2f;

        float headerTextSize = 6.5F;
        float headerIconSize = 7.0F;
        float rowIconSize = 6.5F;
        float rowTextSize = 6.5F;

        List<String> currentIds = new ArrayList<>();
        float maxItemWidth = 0.0F;
        float headerHeight = 12.0F + gap;
        float contentHeight = 0.0F;

        for (ModuleKeybindEntry entry : entries) {
            currentIds.add(entry.id);
            Animation anim = this.entryAnimations.computeIfAbsent(entry.id, k -> new Animation(100L, 0.0F, Easing.LINEAR));
            anim.update(entry.active ? 1.0F : 0.0F);
            float animVal = anim.getValue();
            if (animVal > 0.01F || entry.active) {
                float nameWidth = Fonts.REGULAR.getWidth(entry.name, rowTextSize);
                float bindWidth = Fonts.REGULAR.getWidth(toShortBind(entry.bind), rowTextSize);
                float itemWidth = iconSize + headerGap + nameWidth + itemGap + bindWidth;
                maxItemWidth = Math.max(maxItemWidth, itemWidth);
                contentHeight += (itemHeight + itemGap) * animVal;
            }
        }

        this.entryAnimations.entrySet().removeIf(e ->
                !currentIds.contains(e.getKey())
                        && e.getValue().isDone()
                        && e.getValue().getValue() <= 0.01F
        );

        float targetWidth = Math.max(totalWidth, maxItemWidth + paddingX * 2f);
        float animatedHeight = paddingY + headerHeight + contentHeight + paddingY - 10.0F;

        this.widthAnimation.update(targetWidth);
        float animatedWidth = this.widthAnimation.getValue();

        posY = this.adjustRenderYAboveChat(posY, animatedHeight);

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA logoColor = theme.getColor();
        ColorRGBA bgColor = ColorUtil.darkenBrightness(logoColor, 0.1f).mulAlpha(globalAlpha);
        ColorRGBA iconColor = logoColor.mulAlpha(globalAlpha);
        ColorRGBA textColor = ColorRGBA.WHITE.mulAlpha(globalAlpha);
        ColorRGBA bindColor = logoColor.mulAlpha(globalAlpha);

        ctx.drawRoundedRect(posX, posY, animatedWidth, animatedHeight, BorderRadius.all(borderRadius), bgColor);

        float currentY = posY + paddingY;
        float currentX = posX + paddingX;

        ctx.drawText(Fonts.SKYCORE.getFont(headerIconSize), "c", currentX, currentY + 2.9f, iconColor);
        currentX += iconSize + headerGap;
        ctx.drawText(Fonts.REGULAR.getFont(headerTextSize), "Keybinds", currentX + 1.0F, currentY + 2.5f, textColor);

        currentY += headerHeight;

        for (ModuleKeybindEntry entry : entries) {
            Animation itemAnim = this.entryAnimations.get(entry.id);
            if (itemAnim == null) {
                continue;
            }
            float animVal = itemAnim.getValue();
            if (animVal <= 0.01F) {
                continue;
            }

            currentX = posX + paddingX;
            float slideOffset = (1.0F - animVal) * 10.0F;

            ctx.drawText(Fonts.SKYCORE.getFont(rowIconSize), entry.categoryIcon, currentX, currentY - 1.0F - slideOffset, iconColor.mulAlpha(animVal));
            currentX += iconSize + itemGap;

            ctx.drawText(Fonts.REGULAR.getFont(rowTextSize), entry.name, currentX, currentY - 2.0F - slideOffset, textColor.mulAlpha(animVal));
            float nameWidth = Fonts.REGULAR.getWidth(entry.name, rowTextSize);
            currentX += nameWidth;

            String shortBind = toShortBind(entry.bind);
            float bindWidth = Fonts.REGULAR.getWidth(shortBind, rowTextSize);
            float bindX = posX + animatedWidth - paddingX - bindWidth;
            ctx.drawText(Fonts.REGULAR.getFont(rowTextSize), shortBind, bindX + slideOffset, currentY - 2.0F - slideOffset, bindColor.mulAlpha(animVal));

            currentY += (itemHeight + itemGap) * animVal;
        }

        this.width = animatedWidth;
        this.height = animatedHeight;
    }

    private static List<ModuleKeybindEntry> collectModuleKeybinds() {
        List<ModuleKeybindEntry> list = new ArrayList<>();
        for (Module module : SkyCore.getInstance().getModuleManager().getModules()) {
            String categoryIcon = getCategoryIcon(module);
            if (module.getKeyCode() != -1) {
                list.add(new ModuleKeybindEntry(
                        "m:" + module.getName() + ":" + module.getKeyCode(),
                        module.getName(),
                        module.getKeyCode(),
                        categoryIcon,
                        module.isEnabled()
                ));
            }
            for (Setting setting : module.getSettings()) {
                if (setting instanceof BooleanSetting booleanSetting && booleanSetting.getKeyCode() != -1) {
                    list.add(new ModuleKeybindEntry(
                            "s:" + module.getName() + ":" + booleanSetting.getName() + ":" + booleanSetting.getKeyCode(),
                            booleanSetting.getName(),
                            booleanSetting.getKeyCode(),
                            categoryIcon,
                            module.isEnabled() && booleanSetting.isEnabled()
                    ));
                }
            }
        }
        return list;
    }

    private static String getCategoryIcon(Module module) {
        Category c = module.getCategory();
        if (c == null) {
            return "d";
        }
        return switch (c) {
            case COMBAT -> "l";
            case MOVEMENT -> "m";
            case RENDER -> "b";
            case PLAYER -> "i";
            case MISC -> "j";
            case THEMES -> "d";
        };
    }

    private static String toShortBind(int bind) {
        if (bind == -1) {
            return "";
        }
        try {
            String bindStr = InputUtil.fromKeyCode(bind, GLFW.GLFW_KEY_UNKNOWN)
                    .getTranslationKey()
                    .replace("key.keyboard.", "")
                    .replace("key.mouse.", "M")
                    .replace("MOUSE", "M")
                    .replace("CONTROL", "C")
                    .replace("LEFT", "L")
                    .replace("RIGHT", "R")
                    .replace("_", "");
            if (bindStr.equals("semicolon")) {
                bindStr = ";";
            }
            if (bindStr.equals("apostrophe")) {
                bindStr = "ap";
            }
            if (bindStr.equals("4")) {
                bindStr = "M4";
            }
            if (bindStr.equals("3")) {
                bindStr = "M3";
            }
            if (bindStr.length() > 4) {
                bindStr = bindStr.substring(0, 4);
            }
            return bindStr.toUpperCase();
        } catch (Exception e) {
            return "?";
        }
    }

    private record ModuleKeybindEntry(String id, String name, int bind, String categoryIcon, boolean active) {
    }
}
