package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.option.Perspective;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.render.EventFov;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.util.animation.client.ClientAnimationUtil;
import This.skycore.util.animation.client.ClientEasings;
import This.skycore.util.interfaces.IMinecraft;

@ModuleAnnotation(
        name = "Animations",
        category = Category.RENDER,
        description = "Анимирует выбранные действия"
)
public final class Animations extends Module implements IMinecraft {

    public static final Animations INSTANCE = new Animations();

    public final MultiBooleanSetting mode = MultiBooleanSetting.create(
            "Что анимировать",
            java.util.List.of("Список игроков", "Инвентарь", "Приближение камеры", "Изменение перспективы")
    );

    private final ClientAnimationUtil tabSlideAnimation = new ClientAnimationUtil(0.0F, 12.0F, ClientEasings.CUBIC_OUT);
    private final ClientAnimationUtil openScaleAnim = new ClientAnimationUtil(0.0F, 12.0F, ClientEasings.CUBIC_OUT);
    private final ClientAnimationUtil zoomAnimation = new ClientAnimationUtil(1.0F, 12.0F, ClientEasings.CUBIC_OUT);
    private final ClientAnimationUtil perspectiveAnimation = new ClientAnimationUtil(1.0F, 12.0F, ClientEasings.CUBIC_OUT);

    private float displayedFov = -1.0F;
    private Perspective lastPerspective;

    private Animations() {
    }

    public boolean isModeEnabled(String name) {
        return this.isEnabled() && this.mode.isEnable(name);
    }

    @Override
    public void onEnable() {
        this.displayedFov = -1.0F;
        if (mc.options != null) {
            this.lastPerspective = mc.options.getPerspective();
        }
        super.onEnable();
    }

    public void triggerPerspectiveAnimation() {
        if (!this.isModeEnabled("Изменение перспективы")) {
            return;
        }
        this.perspectiveAnimation.setValue(0.7F);
        this.perspectiveAnimation.update(1.0F);
    }

    @EventTarget
    private void onTick(EventUpdate e) {
        if (!this.isEnabled() || mc.options == null) {
            return;
        }

        if (this.isModeEnabled("Список игроков")) {
            this.tabSlideAnimation.update(mc.options.playerListKey.isPressed() ? 1.0F : 0.0F);
        }

        if (this.isModeEnabled("Инвентарь")) {
            this.openScaleAnim.update(mc.currentScreen instanceof InventoryScreen ? 1.0F : 0.0F);
        }

        Perspective current = mc.options.getPerspective();
        if (this.lastPerspective != null && current != this.lastPerspective) {
            this.triggerPerspectiveAnimation();
        }
        this.lastPerspective = current;

        if (this.isModeEnabled("Приближение камеры")) {
            float target = mc.options.sneakKey.isPressed() ? 0.25F : 1.0F;
            this.zoomAnimation.update(target);
        }

        if (this.isModeEnabled("Изменение перспективы") && this.perspectiveAnimation.isAlive()) {
            this.perspectiveAnimation.update(1.0F);
        }
    }

    @EventTarget
    private void onFov(EventFov e) {
        if (!this.isEnabled()) {
            return;
        }

        int target = e.getVanillaFov();

        if (this.isModeEnabled("Приближение камеры")) {
            target = Math.round(target * this.zoomAnimation.getValue());
        }

        if (this.isModeEnabled("Изменение перспективы") && this.perspectiveAnimation.isAlive()) {
            target = Math.round(target * Math.max(0.5F, this.perspectiveAnimation.getValue()));
        }

        if (this.isModeEnabled("Приближение камеры") || this.isModeEnabled("Изменение перспективы")) {
            if (this.displayedFov < 0.0F) {
                this.displayedFov = target;
            }
            this.displayedFov += (target - this.displayedFov) * 0.22F;
            e.setFov(Math.round(this.displayedFov));
            e.cancel();
        }
    }

    public ClientAnimationUtil getTabSlideAnimation() {
        return this.tabSlideAnimation;
    }

    public ClientAnimationUtil getOpenScaleAnim() {
        return this.openScaleAnim;
    }
}
