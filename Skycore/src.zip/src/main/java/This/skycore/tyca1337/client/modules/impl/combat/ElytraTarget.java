package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.render.EventRender2D;
import This.skycore.base.events.impl.render.EventRender3D;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.util.component.ElytraComponent;
import This.skycore.util.math.Timer;
import This.skycore.util.render.level.Render3DUtil;

@ModuleAnnotation(
        name = "ElytraTarget",
        category = Category.COMBAT,
        description = "Преследует таргета на элитре"
)
public final class ElytraTarget extends Module {

    public static final ElytraTarget INSTANCE = new ElytraTarget();

    private final BooleanSetting overtake = new BooleanSetting("Перегонять", true);
    private final ModeSetting predictMode = new ModeSetting("Режим предикта", overtake::isEnabled, "ReallyWorld", "ReallyWorld - 2", "Default");
    private final NumberSetting predictDistance = new NumberSetting("Сила предикта", 2.7F, 1.0F, 5.0F, 0.1F, overtake::isEnabled);
    private final NumberSetting pursuitDistance = new NumberSetting("Растояние преследования", 30.0F, 10.0F, 100.0F, 5.0F);
    private final BooleanSetting predictCube = new BooleanSetting("Рисовать предикт", true, () -> overtake.isEnabled() && supportsPredictCube());
    private final NumberSetting predictFillAlpha = new NumberSetting("Прозрачность", 40.0F, 0.0F, 255.0F, 1.0F, () -> overtake.isEnabled() && predictCube.isEnabled() && supportsPredictCube());
    private final BooleanSetting predictFromTheme = new BooleanSetting("От темы", true, () -> overtake.isEnabled() && predictCube.isEnabled() && supportsPredictCube());
    private final ModeSetting predictBoxMode = new ModeSetting("Вид квадрата", () -> overtake.isEnabled() && predictCube.isEnabled() && supportsPredictCube(), "Обычный", "Пунктир", "Диагонали");
    private final BooleanSetting visualReverse = new BooleanSetting("Разворот на 180", false, overtake::isEnabled);
    private final BooleanSetting showInfo = new BooleanSetting("Показывать инфо", true);

    public boolean status = true;
    public boolean disableForward = false;

    private final Timer hurtTimer = new Timer();
    private boolean visualReverseWasActive = false;

    private ElytraTarget() {
    }

    public boolean isOvertakeEnabled() {
        return overtake.isEnabled();
    }

    public float getPredictDistance() {
        return predictDistance.getCurrent();
    }

    public float getPursuitDistance() {
        return pursuitDistance.getCurrent();
    }

    public boolean isTestPredict() {
        return predictMode.is("ReallyWorld");
    }

    public boolean isPedikPredict() {
        return predictMode.is("ReallyWorld - 2");
    }

    public boolean usesVisualReverseLogic() {
        return isTestPredict() || isPedikPredict();
    }

    public boolean supportsPredictCube() {
        return isTestPredict() || isPedikPredict();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) {
            return;
        }

        Aura aura = Aura.INSTANCE;
        this.status = this.overtake.isEnabled();

        if (aura == null || aura.getTarget() == null) {
            this.disableForward = false;
            return;
        }

        LivingEntity auraTarget = aura.getTarget();
        if (mc.player.hurtTime > 0) {
            this.disableForward = true;
            this.hurtTimer.reset();
        }

        if (this.hurtTimer.finished(500L)) {
            this.disableForward = false;
        }
    }

    public boolean shouldTarget(LivingEntity livingEntity) {
        if (!this.isEnabled() || livingEntity == null || this.disableForward) {
            return false;
        }
        return this.status && mc.player != null && mc.player.isGliding() && livingEntity.isGliding();
    }

    public boolean isReverseActive() {
        if (!this.usesVisualReverseLogic()
                || !this.isEnabled()
                || !this.overtake.isEnabled()
                || !this.visualReverse.isEnabled()
                || this.disableForward
                || mc.player == null) {
            this.visualReverseWasActive = false;
            return false;
        }

        Aura aura = Aura.INSTANCE;
        LivingEntity auraTarget = aura != null ? aura.getTarget() : null;
        if (auraTarget == null || !this.shouldTarget(auraTarget)) {
            this.visualReverseWasActive = false;
            return false;
        }

        float distanceToTarget = mc.player.distanceTo(auraTarget);
        float enableDistance = 2.5F;
        float predictDist = Math.max(enableDistance, this.getPredictDistance());
        float disableDistance = predictDist + 3.0F;

        if (!this.visualReverseWasActive && distanceToTarget <= enableDistance) {
            this.visualReverseWasActive = true;
        }
        if (this.visualReverseWasActive && distanceToTarget >= disableDistance) {
            this.visualReverseWasActive = false;
        }

        return this.visualReverseWasActive;
    }

    @Override
    public void onDisable() {
        ElytraComponent.resetState();
        this.disableForward = false;
        this.visualReverseWasActive = false;
        super.onDisable();
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mc.player == null || mc.world == null || !isEnabled()) {
            return;
        }
        if (!overtake.isEnabled() || !predictCube.isEnabled() || !supportsPredictCube() || !mc.player.isGliding()) {
            return;
        }

        LivingEntity auraTarget = Aura.INSTANCE != null ? Aura.INSTANCE.getTarget() : null;
        if (auraTarget == null || !auraTarget.isGliding()) {
            return;
        }
        if (ElytraComponent.pos == null || ElytraComponent.pos.equals(Vec3d.ZERO)) {
            return;
        }

        double r = 0.35D;
        Vec3d renderPos = ElytraComponent.pos;
        Box cube = new Box(
                renderPos.x - r, renderPos.y - r, renderPos.z - r,
                renderPos.x + r, renderPos.y + r, renderPos.z + r
        );

        int baseColor = predictFromTheme.isEnabled() ? 0xFFFFFFFF : 0xFFFFFFFF;
        int fillColor = (baseColor & 0x00FFFFFF) | (MathHelper.clamp((int) predictFillAlpha.getCurrent(), 0, 255) << 24);
        Render3DUtil.drawBox(cube, fillColor, 1.0F, true, false, false);
    }

    @EventTarget
    public void onRender2D(EventRender2D event) {
        if (!showInfo.isEnabled() || mc.player == null) {
            return;
        }

        LivingEntity auraTarget = Aura.INSTANCE != null ? Aura.INSTANCE.getTarget() : null;
        if (auraTarget == null) {
            return;
        }

        DrawContext context = event.getContext();
        boolean active = ElytraComponent.isReallyWorldChaseActive();
        String modeLabel = isPedikPredict() ? "ReallyWorld - 2" : (isTestPredict() ? "ReallyWorld" : "Default");
        String statusText = active ? "§aПерегон активен (" + modeLabel + ")" : "§cПерегон неактивен";
        context.drawTextWithShadow(mc.textRenderer, statusText, 10, 80, 0xFFFFFF);

        if (ElytraComponent.pos != null && !ElytraComponent.pos.equals(Vec3d.ZERO)) {
            double distance = auraTarget.getPos().distanceTo(ElytraComponent.pos);
            String predictText = String.format("Предикт: %.2f | Сила: %.1f", distance, getPredictDistance());
            context.drawTextWithShadow(mc.textRenderer, predictText, 10, 95, 0xAAAAAA);
        }
    }
}
