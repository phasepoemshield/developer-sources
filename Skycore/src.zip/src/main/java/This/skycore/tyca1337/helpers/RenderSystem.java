package This.skycore.tyca1337.helpers;

import java.util.function.Supplier;

public class RenderSystem {
    private static Thread renderThread;
    public static void assertThread(Supplier<Boolean> p_assertThread_0_)
    {
        if (!p_assertThread_0_.get())
        {
            throw new IllegalStateException("Rendersystem called from wrong thread");
        }
    }
    public static boolean isOnRenderThread()
    {
        return Thread.currentThread() == renderThread;
    }
}
