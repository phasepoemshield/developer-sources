package This.skycore.tyca1337.helpers;

import com.darkmagician6.eventapi.events.Event;
import lombok.Getter;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import This.skycore.base.events.callables.EventCancellable;

@Getter
public class EventClick extends EventCancellable implements Event {
    private final Hand hand;
    private final BlockHitResult hitResult;

    public EventClick(Hand hand, BlockHitResult hitResult) {
        this.hand = hand;
        this.hitResult = hitResult;
    }
}
