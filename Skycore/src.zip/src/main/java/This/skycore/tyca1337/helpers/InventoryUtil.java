package This.skycore.tyca1337.helpers;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.block.BlockState;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ArmorItem;
//import net.minecraft.item.ElytraItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.item.consume.UseAction;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.collection.DefaultedList;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.request.ScriptManager;
import This.skycore.util.game.other.MessageUtil;
import This.skycore.util.game.other.NetworkUtils;
import This.skycore.util.game.player.PlayerIntersectionUtil;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.mixin.accessors.ClientPlayerInteractionManagerAccessor;

import java.util.Timer;
import java.util.TimerTask;

/**
 * sky.core.utils.player.InventoryUtil — порт 1:1 на 1.21.4.
 */
public final class InventoryUtil implements IMinecraft {

    private InventoryUtil() {
    }

    /** Аналог {@code mc.playerController.syncCurrentPlayItem()} (sky.core 1.16.5). */
    public static void syncCurrentPlayItem() {
        if (mc.interactionManager == null) {
            return;
        }
        ((ClientPlayerInteractionManagerAccessor) mc.interactionManager).skycore$syncSelectedSlot();
    }

    public static void switchToHotbarSlot(int slot) {
        if (mc.player == null || slot < 0 || slot > 8) {
            return;
        }
        if (mc.player.getInventory().selectedSlot == slot) {
            return;
        }
        mc.player.getInventory().selectedSlot = slot;
        syncCurrentPlayItem();
    }

    public static int getSlot(Item item) {
        if (mc == null || mc.player == null) {
            return -1;
        }
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() == item) {
                return i;
            }
        }
        return -1;
    }

    public static Slot getSlottest(Item item) {
        if (mc.player == null) {
            return null;
        }
        return mc.player.currentScreenHandler.slots.stream()
                .filter(s -> s.getStack().getItem() == item)
                .findFirst()
                .orElse(null);
    }

    public static void findItemAndThrow(Item item) {
        if (mc.player.getItemCooldownManager().isCoolingDown(item.getDefaultStack())) {
            MessageUtil.displayWarning(item.getName().getString() + " - находиться в кулдауне");
            return;
        }

        Slot slot = getSlottest(item);
        if (slot == null) {
            MessageUtil.displayWarning(item.getName().getString() + " - не обнаружен в инвентаре");
            return;
        }

        findItemAndThrow(slot);
    }

    public static void findItemAndThrow(Slot slot) {
        swapHand(slot, Hand.MAIN_HAND, true);
        useItem(Hand.MAIN_HAND);
        swapHand(slot, Hand.MAIN_HAND, true);
    }

    public static void swapHand(Slot slot, Hand hand, boolean packet) {
        if (slot != null) {
            swapHand(slot.id, hand, packet);
        }
    }

    public static void swapHand(int slotId, Hand hand, boolean packet) {
        if (slotId == -1) {
            return;
        }
        int button = hand.equals(Hand.MAIN_HAND) ? mc.player.getInventory().selectedSlot : 40;
        clickSlotId(slotId, button, SlotActionType.SWAP, packet);
    }

    public static void useItem(Hand hand) {
        PlayerIntersectionUtil.sendPacketWithOutEvent(new PlayerInteractItemC2SPacket(hand, 0, mc.player.getYaw(), mc.player.getPitch()));
    }

    public static void clickSlotId(int slotId, int buttonId, SlotActionType clickType, boolean packet) {
        clickSlotId(mc.player.currentScreenHandler.syncId, slotId, buttonId, clickType, packet);
    }

    public static void clickSlotId(int windowId, int slotId, int buttonId, SlotActionType clickType, boolean packet) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        if (packet) {
            sendClickPacket(windowId, slotId, buttonId, clickType);
        } else {
            mc.interactionManager.clickSlot(windowId, slotId, buttonId, clickType, mc.player);
        }
    }

    public static void clickSlotId(int slotId, int buttonId, SlotActionType clickType) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        mc.interactionManager.clickSlot(0, slotId, buttonId, clickType, mc.player);
    }

    public static void moveItem(int from, int to) {
        if (from == to || from == -1 || mc.player == null || mc.interactionManager == null) {
            return;
        }
        from = from < 9 ? from + 36 : from;
        if (to == 45) {
            clickSlotId(from, 40, SlotActionType.SWAP);
        } else {
            clickSlotId(from, 0, SlotActionType.SWAP);
            clickSlotId(to, 0, SlotActionType.SWAP);
            clickSlotId(from, 0, SlotActionType.SWAP);
        }
    }

    public static void moveItemtest(int from, int to) {
        if (from != to && from != -1) {
            from = from < 9 ? from + 36 : from;
            clickSlotId(from, 0, SlotActionType.SWAP, false);
            clickSlotId(to, 0, SlotActionType.SWAP, false);
            clickSlotId(from, 0, SlotActionType.SWAP, false);
        }
    }

    public static int antipoletToOffhand(Item item) {
        if (getSlot(item) == -1 || mc.player == null) {
            return -1;
        }
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) {
                int originalSlot = i < 9 ? 36 + i : i;
                moveItem(originalSlot, 45);

                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        if (mc != null && mc.options != null && !mc.options.sneakKey.isPressed()) {
                            mc.options.sneakKey.setPressed(true);
                        }
                    }
                }, 150);

                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        if (mc != null && mc.options != null && mc.options.sneakKey.isPressed()) {
                            mc.options.sneakKey.setPressed(false);
                        }
                    }
                }, 200);

                return originalSlot;
            }
        }
        return -1;
    }

    public static boolean isOnHotBar(int index) {
        return index >= 36 && index <= 44;
    }

    public static void swapItem(int from, int to) {
        if (from == to) {
            return;
        }

        from = from < 9 ? from + 36 : from;

        int syncId = mc.player.currentScreenHandler.syncId;
        mc.interactionManager.clickSlot(syncId, from, 0, SlotActionType.SWAP, mc.player);
        mc.interactionManager.clickSlot(syncId, to, 0, SlotActionType.SWAP, mc.player);
        mc.interactionManager.clickSlot(syncId, from, 0, SlotActionType.SWAP, mc.player);
    }

    //public static int findBestSlotInHotBar() {
    //    int emptySlot = findEmptySlot();
    //    return emptySlot != -1 ? emptySlot : findNonSwordSlot();
    //}

    public static boolean haveHotBar(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) {
                return true;
            }
        }
        return false;
    }

    public static int find(Item item) {
        int slot = -1;

        for (ItemStack stack : mc.player.getInventory().armor) {
            if (stack.getItem() == item) {
                return -2;
            }
        }

        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() == item) {
                slot = i;
                break;
            }
        }

        if (slot < 9 && slot != -1) {
            slot += 36;
        }

        return slot;
    }

    //private static int findNonSwordSlot() {
    //    for (int i = 0; i < 9; i++) {
    //        Item item = mc.player.getInventory().getStack(i).getItem();
    //        if (!(item instanceof SwordItem)
    //                && !(item instanceof ElytraItem)
    //                && mc.player.getInventory().selectedSlot != i) {
    //            return i;
    //        }
    //    }
    //    return -1;
    //}

    public static void switchItem(Item item, int to, boolean back, int timeDelayBack) {
        if (getSlot(item) == -1) {
            return;
        }

        int formativeSlot = getItemSlot(item);
        mc.interactionManager.clickSlot(0, formativeSlot, to, SlotActionType.SWAP, mc.player);

        if (back) {
            ScriptManager.ScriptTask task = new ScriptManager.ScriptTask();
            for (int i = 0; i < timeDelayBack; i++) {
                task.schedule(EventUpdate.class, e -> false);
            }
            task.schedule(EventUpdate.class, e -> {
                mc.interactionManager.clickSlot(0, formativeSlot, to, SlotActionType.SWAP, mc.player);
                return true;
            });
            SkyCore.getInstance().getScriptManager().addTask(task);
        }
    }

    public static int getItemSlot(Item input) {
        int slot = -1;

        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() == input) {
                slot = i;
                break;
            }
        }

        if (slot < 9 && slot != -1) {
            slot += 36;
        }

        return slot;
    }

    public static void pickItem(int from, int to) {
        if (from == to) {
            return;
        }

        from = from < 9 ? from + 36 : from;

        pickupItem(from, 0);
        pickupItem(to, 0);
        pickupItem(from, 0);
    }

    public static int getAxe(boolean hotBar) {
        int startSlot = hotBar ? 0 : 9;
        int endSlot = hotBar ? 9 : 36;

        for (int i = startSlot; i < endSlot; i++) {
            ItemStack itemStack = mc.player.getInventory().getStack(i);
            if (itemStack.getItem() instanceof AxeItem) {
                return i;
            }
        }

        return -1;
    }

    public static int findAxeSlot() {
        for (int i = 0; i < 45; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof AxeItem) {
                return i;
            }
        }
        return -1;
    }

    public static void pickupItem(int slot, int button) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        mc.interactionManager.clickSlot(0, slot, button, SlotActionType.PICKUP, mc.player);
    }

    public static int getChestPlateSlot() {
        if (mc.player == null) {
            return -1;
        }
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty() || stack.getItem() == Items.ELYTRA) {
                continue;
            }
            if (stack.getItem() instanceof ArmorItem armor) {
                String name = armor.toString().toLowerCase();
                if (name.contains("chestplate") || name.contains("tunic")) {
                    return i;
                }
            }
        }
        return -1;
    }

    public static void moveToArmor(int fromSlot, int armorSlot) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        int invFrom = fromSlot < 9 ? fromSlot + 36 : fromSlot;

        mc.interactionManager.clickSlot(0, invFrom, 40, SlotActionType.SWAP, mc.player);
        mc.interactionManager.clickSlot(0, armorSlot, 40, SlotActionType.SWAP, mc.player);
        mc.interactionManager.clickSlot(0, invFrom, 40, SlotActionType.SWAP, mc.player);
    }

    public static int getItemCount(Item item) {
        if (mc.player == null) {
            return 0;
        }
        int count = 0;
        for (ItemStack stack : mc.player.getInventory().main) {
            if (!stack.isEmpty() && stack.getItem() == item) {
                count += stack.getCount();
            }
        }
        return count;
    }

    public static int findBestToolForBlock(BlockState blockState) {
        if (mc.player == null) {
            return -1;
        }

        int bestSlot = -1;
        float bestSpeed = 1.0f;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty()) {
                float speed = mc.player.getBlockBreakingSpeed(blockState);
                if (speed > bestSpeed) {
                    bestSpeed = speed;
                    bestSlot = i;
                }
            }
        }

        return bestSlot;
    }

    private static int findEmptySlot() {
        if (mc == null || mc.player == null) {
            return -1;
        }
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) {
                return i < 9 ? i + 36 : i;
            }
        }
        return -1;
    }

    public static void inventorySwapClick(Item item) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        int slot = getSlot(item);
        if (slot == -1) {
            return;
        }

        int currentSlot = mc.player.getInventory().selectedSlot;
        boolean isInHotbar = slot < 9;

        if (isInHotbar && slot == currentSlot) {
            useItemInHand();
        } else if (isInHotbar) {
            swapAndUseItem(slot, currentSlot);
        } else {
            int hotbarSlot = currentSlot % 8 + 1;
            mc.interactionManager.clickSlot(0, slot, hotbarSlot, SlotActionType.SWAP, mc.player);
            swapAndUseItem(hotbarSlot, currentSlot);
            mc.interactionManager.clickSlot(0, slot, hotbarSlot, SlotActionType.SWAP, mc.player);
        }
    }

    private static void useItemInHand() {
        if (mc.player == null) {
            return;
        }
        if (mc.player.isUsingItem() && !mc.player.isBlocking()) {
            NetworkUtils.sendPacket(new PlayerInteractItemC2SPacket(Hand.OFF_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
        } else {
            NetworkUtils.sendPacket(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
        }
    }

    private static void swapAndUseItem(int targetSlot, int currentSlot) {
        if (mc.player == null) {
            return;
        }
        if (mc.player.isUsingItem() && !mc.player.isBlocking()) {
            swapItem(targetSlot, 45);
            NetworkUtils.sendPacket(new PlayerInteractItemC2SPacket(Hand.OFF_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
            swapItem(targetSlot, 45);
        } else {
            NetworkUtils.sendPacket(new UpdateSelectedSlotC2SPacket(targetSlot));
            NetworkUtils.sendPacket(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
            NetworkUtils.sendPacket(new UpdateSelectedSlotC2SPacket(currentSlot));
        }
    }

    public static int getBestFoodSlot() {
        if (mc == null || mc.player == null) {
            return -1;
        }
        int best = -1;
        int max = 0;
        for (int i = 0; i < 45; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && s.get(DataComponentTypes.FOOD) != null && s.getCount() > max) {
                best = i;
                max = s.getCount();
            }
        }
        return best;
    }

    public static int findEnchantedTotemSlot() {
        if (mc == null || mc.player == null) {
            return -1;
        }
        for (int i = 0; i < 45; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty()
                    && stack.getItem() == Items.TOTEM_OF_UNDYING
                    && stack.hasEnchantments()) {
                return i;
            }
        }
        return -1;
    }

    public static boolean stackHasAnyEffect(ItemStack stack, boolean includeRegular, boolean includeSplash, boolean includeLingering, StatusEffect... effects) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        Item item = stack.getItem();
        boolean typeOk = (includeRegular && item == Items.POTION)
                || (includeSplash && item == Items.SPLASH_POTION)
                || (includeLingering && item == Items.LINGERING_POTION);
        if (!typeOk) {
            return false;
        }

        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) {
            return false;
        }

        for (StatusEffectInstance instance : contents.getEffects()) {
            for (StatusEffect effect : effects) {
                if (instance.getEffectType().value() == effect) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int findPotionSlotWithEffects(boolean preferHotbar, boolean includeRegular, boolean includeSplash, boolean includeLingering, StatusEffect... effects) {
        if (mc.player == null) {
            return -1;
        }

        if (preferHotbar) {
            for (int i = 0; i < 9; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (stackHasAnyEffect(s, includeRegular, includeSplash, includeLingering, effects)) {
                    return i;
                }
            }
        } else {
            for (int i = 0; i < 9; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (stackHasAnyEffect(s, includeRegular, includeSplash, includeLingering, effects)) {
                    return i;
                }
            }
            for (int i = 9; i < 36; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (stackHasAnyEffect(s, includeRegular, includeSplash, includeLingering, effects)) {
                    return i;
                }
            }
        }
        return -1;
    }

    public static int findEmptyInventorySlot() {
        if (mc.player == null) {
            return -1;
        }
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) {
                return i < 9 ? i + 36 : i;
            }
        }
        return -1;
    }

    //public static void useItemLegit(Object object, Item item) {
    //    int slot = getSlot(item);
    //    if (slot == -1) {
    //        return;
    //    }
    //    if (slot < 9) {
    //        mc.player.getInventory().selectedSlot = slot;
    //        NetworkUtils.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    //    } else {
    //        int hotbar = findBestSlotInHotBar();
    //        if (hotbar >= 36) {
    //            hotbar -= 36;
    //        }
    //        mc.interactionManager.clickSlot(0, slot < 9 ? slot + 36 : slot, hotbar, SlotActionType.SWAP, mc.player);
    //        mc.player.getInventory().selectedSlot = hotbar;
    //        NetworkUtils.sendPacket(new UpdateSelectedSlotC2SPacket(hotbar));
    //    }
    //}

    private static void sendClickPacket(int windowId, int slotId, int buttonId, SlotActionType clickType) {
        ScreenHandler screenHandler = mc.player.currentScreenHandler;
        DefaultedList<Slot> slots = screenHandler.slots;
        int size = slots.size();
        java.util.List<ItemStack> before = new java.util.ArrayList<>(size);
        for (Slot slot : slots) {
            before.add(slot.getStack().copy());
        }

        screenHandler.onSlotClick(slotId, buttonId, clickType, mc.player);

        Int2ObjectMap<ItemStack> modified = new Int2ObjectOpenHashMap<>();
        for (int i = 0; i < size; i++) {
            ItemStack prev = before.get(i);
            ItemStack now = slots.get(i).getStack();
            if (!ItemStack.areEqual(prev, now)) {
                modified.put(i, now.copy());
            }
        }

        NetworkUtils.sendPacket(new ClickSlotC2SPacket(
                windowId,
                screenHandler.getRevision(),
                slotId,
                buttonId,
                clickType,
                screenHandler.getCursorStack().copy(),
                modified
        ));
    }
}
