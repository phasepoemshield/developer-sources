package This.skycore.tyca1337.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.util.component.RotationComponent;
import This.skycore.util.game.player.rotation.Rotation;
import This.skycore.util.game.player.rotation.RotationUtil;

@ModuleAnnotation(
        name = "ItemAim",
        category = Category.PLAYER,
        description = "Автоматически наводиться на предмет"
)
public final class ItemAim extends Module {

    public static final ItemAim INSTANCE = new ItemAim();

    private final MultiBooleanSetting loot = MultiBooleanSetting.create("Лутать", List.of("Шары", "Элитры"));

    private ItemAim() {
    }

    @EventTarget
    @Native
    public void onUpdate(EventUpdate event) {
        if (mc.currentScreen != null) {
            return;
        }
        if (mc.player == null || mc.world == null) {
            return;
        }

        ItemEntity targetItem = this.findTargetItem();
        if (targetItem == null) {
            return;
        }

        Vec3d center = targetItem.getBoundingBox().getCenter();
        Rotation rotation = RotationUtil.calculateAngle(center);
        // clientRotation: камера = игрок (без FreeLook); приоритет выше Aura/ClickPearl
        RotationComponent.update(rotation, 360.0F, 360.0F, 360.0F, 360.0F, 40, 5, true);
    }

    private ItemEntity findTargetItem() {
        ItemEntity bestItem = null;
        double bestDistance = Double.MAX_VALUE;

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof ItemEntity itemEntity)) {
                continue;
            }
            if (!this.isWantedItem(itemEntity)) {
                continue;
            }

            double distance = mc.player.squaredDistanceTo(itemEntity);
            if (distance < bestDistance) {
                bestDistance = distance;
                bestItem = itemEntity;
            }
        }

        return bestItem;
    }

    private boolean isWantedItem(ItemEntity itemEntity) {
        return this.loot.isEnable("Шары") && itemEntity.getStack().isOf(Items.PLAYER_HEAD)
                || this.loot.isEnable("Элитры") && itemEntity.getStack().isOf(Items.ELYTRA);
    }
}
