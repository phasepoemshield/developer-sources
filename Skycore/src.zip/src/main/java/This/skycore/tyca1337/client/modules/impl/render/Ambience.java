package This.skycore.tyca1337.client.modules.impl.render;

import This.skycore.SkyCore;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.render.EventFog;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;

import java.time.LocalTime;

@ModuleAnnotation(
        name = "Ambience",
        category = Category.RENDER,
        description = "Меняет атмосферу мира"
)
public final class Ambience extends Module {
    public static final Ambience INSTANCE = new Ambience();

    private final ModeSetting timeMode = new ModeSetting("Время", new String[]{
            "Не менять", "Рассвет", "Утро", "День", "Вечер", "Заход солнца", "Ночь", "Время из реальной жизни"
    });
    private final ModeSetting fogMode = new ModeSetting("Туман", new String[]{
            "Ничего не делать", "Очистить", "Переопределить"
    });
    private final NumberSetting fogDistance = new NumberSetting("Дистанция тумана", 80.0F, 10.0F, 255.0F, 5.0F);

    private Ambience() {
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (event.isReceive()
                && event.getPacket() instanceof WorldTimeUpdateS2CPacket
                && !this.timeMode.is("Не менять")) {
            event.cancel();
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.world == null || this.timeMode.is("Не менять")) {
            return;
        }
        long time = switch (this.timeMode.getValue().getName()) {
            case "Рассвет" -> 23000L;
            case "Утро" -> 1000L;
            case "День" -> 6000L;
            case "Вечер" -> 12000L;
            case "Заход солнца" -> 13000L;
            case "Ночь" -> 18000L;
            case "Время из реальной жизни" -> getRealWorldTime();
            default -> mc.world.getTimeOfDay();
        };
        mc.world.getLevelProperties().setTimeOfDay(time);
    }

    @EventTarget
    public void onFog(EventFog e) {
        if (this.fogMode.is("Ничего не делать")) {
            return;
        }
        if (this.fogMode.is("Очистить")) {
            e.setDistance(255.0F);
            e.setCancelled(true);
            return;
        }
        e.setDistance(this.fogDistance.getCurrent());
        e.setColor(this.getFogColor());
        e.setCancelled(true);
    }

    private int getFogColor() {
        return SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB();
    }

    private long getRealWorldTime() {
        LocalTime now = LocalTime.now();
        int totalSeconds = now.getHour() * 3600 + now.getMinute() * 60 + now.getSecond();
        int offsetSeconds = (totalSeconds - 6 * 3600) % (24 * 3600);
        if (offsetSeconds < 0) {
            offsetSeconds += 24 * 3600;
        }
        return (long) ((offsetSeconds / 86400.0) * 24000.0);
    }
}
