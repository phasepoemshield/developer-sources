package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4d;
import org.joml.Vector4f;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.render.EventRender2D;
import This.skycore.base.font.Fonts;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.impl.misc.NameProtect;
import This.skycore.tyca1337.client.modules.impl.misc.ScoreboardHealth;
import This.skycore.util.game.player.PlayerIntersectionUtil;
import This.skycore.util.game.other.ReplaceUtil;
import This.skycore.util.math.ProjectionUtil;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;

@ModuleAnnotation(
        name = "NameTags",
        category = Category.RENDER,
        description = "Показывает информацию о игроке"
)
public final class EntityESP extends Module {
    public static final EntityESP INSTANCE = new EntityESP();

    private static final float NAME_TAG_TEXT_PT = 6.5F;
    /** Горизонтальный паддинг фона: слева меньше — ближе к префиксу, справа чуть больше (закрытие HP и т.д.). */
    private static final float NAME_TAG_PAD_LEFT = 0.75F;
    private static final float NAME_TAG_PAD_RIGHT = 1.75F;

    private final BooleanSetting armor = new BooleanSetting("Броня", false);
    private final BooleanSetting hands = new BooleanSetting("Предметы в руках", false);
    private final BooleanSetting health = new BooleanSetting("Здоровье", false);
    private final BooleanSetting enchantments = new BooleanSetting("Зачарования", false);
    private final BooleanSetting droppedItems = new BooleanSetting("Предметы на земле", true);

    private final HashMap<Entity, Vector4f> positions = new HashMap();

    public EntityESP() {
    }

    @EventTarget
    private void onRender(EventRender2D e) {
        if (mc.world != null && mc.player != null) {
            float tickDelta = e.getTickDelta();
            this.renderPlayerTags(tickDelta, e);
            if (this.droppedItems.isEnabled()) {
                this.renderItemTags(tickDelta, e);
            }
        }
    }

    private void renderPlayerTags(float tickDelta, EventRender2D e) {
        for (PlayerEntity entity : mc.world.getPlayers()) {
            if (entity == mc.player && !mc.getEntityRenderDispatcher().camera.isThirdPerson()) continue;
            if (!ProjectionUtil.canSee(entity.getBoundingBox().getCenter())) continue;

            double x = MathHelper.lerp((double)tickDelta, entity.lastRenderX, entity.getX());
            double y = MathHelper.lerp((double)tickDelta, entity.lastRenderY, entity.getY()) + (double)entity.getHeight() + 0.2D;
            double z = MathHelper.lerp((double)tickDelta, entity.lastRenderZ, entity.getZ());

            Vec3d pos = ProjectionUtil.worldSpaceToScreenSpace(new Vec3d(x, y, z));
            if (pos.z <= 0.0D || pos.z >= 1.0D) continue;

            Vector4d position = ProjectionUtil.getVector4D(entity);
            float posY = (float)(position.y - 11.0D);

            Text name = entity == mc.player && NameProtect.INSTANCE.isEnabled() ? Text.literal(NameProtect.getCustomName()) : entity.getDisplayName();

            Text finalText = name;

            if (this.health.isEnabled()) {
                float hp = ScoreboardHealth.INSTANCE.isEnabled() && entity != mc.player ? PlayerIntersectionUtil.getHealth(entity) : entity.getHealth();
                finalText = ((Text)name).copy()
                        .append(Text.literal(" [").setStyle(Style.EMPTY.withColor(Formatting.GRAY)))
                        .append(Text.literal(String.valueOf((int)hp)).setStyle(Style.EMPTY.withColor(Formatting.RED)))
                        .append(Text.literal("]").setStyle(Style.EMPTY.withColor(Formatting.GRAY)));
            }

            Text forRender = ReplaceUtil.replaceSymbols(finalText);
            String tagString = forRender.getString();
            float textWidth = Fonts.INTER.getFont(NAME_TAG_TEXT_PT).width(forRender);
            double centerX = position.x + (position.z - position.x) / 2.0D;

            boolean prefixLayout = nameTagUsesPrefixLayout(name, entity);
            float textX;
            float rectX;
            float rectW;
            if (prefixLayout) {
                int leadChars = countLeadingWhitespace(tagString);
                float leadSkipW = Fonts.INTER.getWidth(tagString.substring(0, leadChars), NAME_TAG_TEXT_PT);
                textX = (float) (centerX - (double) (textWidth / 2.0F));
                rectX = textX + leadSkipW - NAME_TAG_PAD_LEFT;
                rectW = textWidth - leadSkipW + NAME_TAG_PAD_LEFT + NAME_TAG_PAD_RIGHT;
            } else {
                rectX = (float) (centerX - (double) (textWidth / 2.0F) - 3.0D);
                rectW = textWidth + 5.0F - 2.5f;
                textX = (float) (centerX - (double) (textWidth / 2.0F)) - 1f;
            }

            DrawUtil.drawRoundedRect(e.getContext().getMatrices(), rectX, posY - 2.5F, rectW, 9.0F, BorderRadius.PIDOR, SkyCore.getInstance().getFriendManager().isFriend(entity.getNameForScoreboard()) ? new ColorRGBA(0, 166, 0, 123) : new ColorRGBA(0, 0, 0, 123));

            e.getContext().drawText(Fonts.INTER.getFont(NAME_TAG_TEXT_PT), forRender, textX, posY - 0.5f, 255.0F);
            ItemStack[] itemArray = new ItemStack[6];
            int itemCount = 0;
            if (this.armor.isEnabled()) {
                EquipmentSlot[] armorSlots = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
                for (EquipmentSlot slot : armorSlots) {
                    ItemStack stack = entity.getEquippedStack(slot);
                    if (!stack.isEmpty()) {
                        itemArray[itemCount++] = stack;
                    }
                }
            }

            if (this.hands.isEnabled()) {
                ItemStack mainHand = entity.getMainHandStack();
                if (!mainHand.isEmpty()) {
                    itemArray[itemCount++] = mainHand;
                }

                ItemStack offHand = entity.getOffHandStack();
                if (!offHand.isEmpty()) {
                    itemArray[itemCount++] = offHand;
                }
            }

            if (itemCount == 0) continue;

            float iconSize = 16.0F;
            float spacing = 0.0F;
            float totalWidth = (float)itemCount * iconSize + (float)(itemCount - 1) * spacing;
            float startX = (float)(position.x + (position.z - position.x) / 2.0D - (double)(totalWidth / 2.0F) + 7.5D);
            float iconY = posY - 12.0F;
            MatrixStack matrices = e.getContext().getMatrices();

            for(int i = 0; i < itemCount; ++i) {
                ItemStack stack = itemArray[i];
                if (stack != null && !stack.isEmpty()) {
                    float x2 = startX + (float)i * (iconSize + spacing);

                    if (this.enchantments.isEnabled()) {
                        ItemEnchantmentsComponent enchComp = EnchantmentHelper.getEnchantments(stack);
                        if (!enchComp.isEmpty()) {
                            Map<RegistryEntry<Enchantment>, Integer> enchMap = (Map)enchComp.getEnchantmentEntries().stream().collect(Collectors.toMap(Entry::getKey, it.unimi.dsi.fastutil.objects.Object2IntMap.Entry::getIntValue));
                            float enchantmentY = iconY - 16.0F;
                            Iterator var33 = enchMap.entrySet().iterator();

                            while(var33.hasNext()) {
                                Entry enchEntry = (Entry)var33.next();
                                int lvl = (Integer)enchEntry.getValue();
                                if (lvl > 0) {
                                    String fullName = Enchantment.getName((RegistryEntry)enchEntry.getKey(), lvl).getString();
                                    String shortName = fullName.length() > 2 ? fullName.substring(0, 2) : fullName;
                                    String enchantmentText = shortName + lvl;
                                    float enchantmentTextWidth = Fonts.INTER.getWidth(enchantmentText, 6.0F);
                                    int color = -1;
                                    if (shortName.equalsIgnoreCase("Sh") && lvl > 5 || shortName.equalsIgnoreCase("Pr") && lvl > 4) {
                                        color = (new ColorRGBA(212, 45, 43, 255)).getRGB();
                                    }

                                    e.getContext().drawText(Fonts.INTER.getFont(6.0F), enchantmentText, x2 - enchantmentTextWidth / 2.0F, enchantmentY, new ColorRGBA(color));
                                    enchantmentY -= 8.0F;
                                }
                            }
                        }
                    }


                    float scale = 0.7F;
                    float overlayY = -18.0F;
                    matrices.push();
                    matrices.translate(x2 + overlayY, iconY + overlayY, 0.0F);
                    matrices.scale(scale, scale, 1.0F);
                    int drawX = (int)(-overlayY);
                    int drawY = (int)(-overlayY);
                    e.getContext().drawItem(stack, drawX, drawY);
                    e.getContext().drawStackOverlay(mc.textRenderer, stack, drawX, drawY);
                    matrices.pop();
                }
            }
        }
    }

    private static int countLeadingWhitespace(String s) {
        int i = 0;
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }

    /**
     * Сжатый левый фон только если до ника есть непустой префикс (или несколько частей display name).
     * Один ник без префикса — прежняя вёрстка.
     */
    private static boolean nameTagUsesPrefixLayout(Text namePart, PlayerEntity entity) {
        String nick = entity.getGameProfile().getName();
        if (nick == null || nick.isEmpty()) {
            return false;
        }
        String display = namePart.getString();
        int idx = indexOfIgnoreCase(display, nick);
        if (idx > 0) {
            return !display.substring(0, idx).isBlank();
        }
        return namePart.getSiblings().size() >= 2;
    }

    private static int indexOfIgnoreCase(String haystack, String needle) {
        if (needle.isEmpty()) {
            return 0;
        }
        return haystack.toLowerCase(Locale.ROOT).indexOf(needle.toLowerCase(Locale.ROOT));
    }

    private void renderItemTags(float tickDelta, EventRender2D e) {
        Iterator var3 = mc.world.getEntities().iterator();

        while(var3.hasNext()) {
            Entity entity = (Entity)var3.next();
            if (entity instanceof ItemEntity) {
                ItemEntity itemEntity = (ItemEntity)entity;
                if (ProjectionUtil.canSee(itemEntity.getBoundingBox().getCenter())) {
                    double x = MathHelper.lerp((double)tickDelta, entity.lastRenderX, entity.getX());
                    double y = MathHelper.lerp((double)tickDelta, entity.lastRenderY, entity.getY()) + (double)entity.getHeight() + 0.1D;
                    double z = MathHelper.lerp((double)tickDelta, entity.lastRenderZ, entity.getZ());
                    Vec3d pos = ProjectionUtil.worldSpaceToScreenSpace(new Vec3d(x, y, z));
                    if (!(pos.z <= 0.0D) && !(pos.z >= 1.0D)) {
                        Vector4d position = ProjectionUtil.getVector4D(entity);
                        ItemStack stack = itemEntity.getStack();
                        if (!stack.isEmpty()) {
                            int rarityOrdinal = stack.getRarity().ordinal();
                            Formatting var10000;
                            switch(rarityOrdinal) {
                                case 1:
                                    var10000 = Formatting.YELLOW;
                                    break;
                                case 2:
                                    var10000 = Formatting.AQUA;
                                    break;
                                case 3:
                                    var10000 = Formatting.LIGHT_PURPLE;
                                    break;
                                default:
                                    var10000 = Formatting.WHITE;
                            }

                            Formatting rarityColor = var10000;
                            String itemName = stack.getName().getString();
                            Text nameText = Text.literal(itemName).setStyle(Style.EMPTY.withColor(rarityColor));
                            if (!stack.getName().getSiblings().isEmpty()) {
                                nameText = stack.getName();
                            }

                            Text countComponent = stack.getCount() > 1 ? Text.literal(" х" + stack.getCount()).setStyle(Style.EMPTY.withColor(Formatting.GRAY)) : Text.empty();
                            Text textComponent = ((Text)nameText).copy().append(countComponent);
                            float textWidth = Fonts.REGULAR.getFont(6.5F).width((Text)textComponent);
                            DrawUtil.drawRoundedRect(e.getContext().getMatrices(), (float)(position.x + (position.z - position.x) / 2.0D - (double)(textWidth / 2.0F) - 3.0D), (float)(position.y - 13.5D), textWidth + 4.0F, 10.0F, BorderRadius.PIDOR, new ColorRGBA(0, 0, 0, 123));
                            e.getContext().drawText(Fonts.REGULAR.getFont(6.5F), textComponent, (float)(position.x + (position.z - position.x) / 2.0D - (double)(textWidth / 2.0F)), (float)position.y - 11.0F, 255.0F);
                        }
                    }
                }
            }
        }

    }

    public static void drawBox(double x, double y, double width, double height, double size, int color, BufferBuilder bufferbuilder) {
        drawRectBuilding(x + size, y, width - size, y + size, color, bufferbuilder);
        drawRectBuilding(x, y, x + size, height, color, bufferbuilder);
        drawRectBuilding(width - size, y, width, height, color, bufferbuilder);
        drawRectBuilding(x + size, height - size, width - size, height, color, bufferbuilder);
    }

    public static void drawBoxTest(double x, double y, double width, double height, double size, Vector4f colors, BufferBuilder bufferbuilder) {
        drawMCHorizontalBuilding(x + size, y, width - size, y + size, (int)colors.x(), (int)colors.y(), bufferbuilder);
        drawMCVerticalBuilding(width - size, y + size, width, height - size, (int)colors.y(), (int)colors.z(), bufferbuilder);
        drawMCHorizontalBuilding(x + size, height - size, width - size, height, (int)colors.w(), (int)colors.z(), bufferbuilder);
        drawMCVerticalBuilding(x, y + size, x + size, height - size, (int)colors.x(), (int)colors.w(), bufferbuilder);
    }

    public static void drawRectBuilding(double left, double top, double right, double bottom, int color, BufferBuilder bufferbuilder) {
        double j;
        if (left < right) {
            j = left;
            left = right;
            right = j;
        }

        if (top < bottom) {
            j = top;
            top = bottom;
            bottom = j;
        }

        float f3 = (float)(color >> 24 & 255) / 255.0F;
        float f = (float)(color >> 16 & 255) / 255.0F;
        float f1 = (float)(color >> 8 & 255) / 255.0F;
        float f2 = (float)(color & 255) / 255.0F;
        bufferbuilder.vertex((float)left, (float)bottom, 0.0F).color(f, f1, f2, f3);
        bufferbuilder.vertex((float)right, (float)bottom, 0.0F).color(f, f1, f2, f3);
        bufferbuilder.vertex((float)right, (float)top, 0.0F).color(f, f1, f2, f3);
        bufferbuilder.vertex((float)left, (float)top, 0.0F).color(f, f1, f2, f3);
    }

    public static void drawMCHorizontalBuilding(double x1, double y1, double x2, double y2, int start, int end, BufferBuilder bufferbuilder) {
        float a1 = (float)(start >> 24 & 255) / 255.0F;
        float r1 = (float)(start >> 16 & 255) / 255.0F;
        float g1 = (float)(start >> 8 & 255) / 255.0F;
        float b1 = (float)(start & 255) / 255.0F;
        float a2 = (float)(end >> 24 & 255) / 255.0F;
        float r2 = (float)(end >> 16 & 255) / 255.0F;
        float g2 = (float)(end >> 8 & 255) / 255.0F;
        float b2 = (float)(end & 255) / 255.0F;
        bufferbuilder.vertex((float)x1, (float)y2, 0.0F).color(r1, g1, b1, a1);
        bufferbuilder.vertex((float)x2, (float)y2, 0.0F).color(r2, g2, b2, a2);
        bufferbuilder.vertex((float)x2, (float)y1, 0.0F).color(r2, g2, b2, a2);
        bufferbuilder.vertex((float)x1, (float)y1, 0.0F).color(r1, g1, b1, a1);
    }

    public static void drawMCVerticalBuilding(double x1, double y1, double x2, double y2, int start, int end, BufferBuilder bufferbuilder) {
        float a1 = (float)(start >> 24 & 255) / 255.0F;
        float r1 = (float)(start >> 16 & 255) / 255.0F;
        float g1 = (float)(start >> 8 & 255) / 255.0F;
        float b1 = (float)(start & 255) / 255.0F;
        float a2 = (float)(end >> 24 & 255) / 255.0F;
        float r2 = (float)(end >> 16 & 255) / 255.0F;
        float g2 = (float)(end >> 8 & 255) / 255.0F;
        float b2 = (float)(end & 255) / 255.0F;
        bufferbuilder.vertex((float)x1, (float)y2, 0.0F).color(r2, g2, b2, a2);
        bufferbuilder.vertex((float)x2, (float)y2, 0.0F).color(r2, g2, b2, a2);
        bufferbuilder.vertex((float)x2, (float)y1, 0.0F).color(r1, g1, b1, a1);
        bufferbuilder.vertex((float)x1, (float)y1, 0.0F).color(r1, g1, b1, a1);
    }
}
