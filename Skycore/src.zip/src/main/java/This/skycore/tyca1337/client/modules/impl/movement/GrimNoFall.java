package This.skycore.tyca1337.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.util.concurrent.ThreadLocalRandom;

import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;

@ModuleAnnotation(
        name = "No Fall",
        category = Category.MOVEMENT,
        description = "Убирает урон от падения"
)
public class GrimNoFall extends Module {

    public static GrimNoFall INSTANCE = new GrimNoFall();


    @EventTarget
    public void onUpdate(final EventUpdate ignored) {
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (!mc.player.isOnGround() && mc.player.fallDistance > 1f) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(mc.player.getX(), mc.player.getY() + 0.000000001, mc.player.getZ(), mc.player.getYaw(), mc.player.getPitch(), true, false));
            mc.player.onLanding();
        }
    }

}