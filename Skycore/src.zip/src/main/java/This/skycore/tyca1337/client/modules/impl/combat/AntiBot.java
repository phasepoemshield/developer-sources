package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import net.minecraft.item.Items;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.util.math.Timer;

@SuppressWarnings("all")
@ModuleAnnotation(
        name = "AntiBot",
        category = Category.COMBAT,
        description = "Убирает ботов"
)
public final class AntiBot extends Module {
    public static final AntiBot INSTANCE = new AntiBot();

    // Настройки режима (Matrix или ReallyWorld)
    private final ModeSetting mode = new ModeSetting("Обход", "ReallyWorld", "Matrix");

    public static final List<PlayerEntity> bots = new ArrayList<>();
    private final Timer timer = new Timer();

    private AntiBot() {
    }

    @EventTarget
    @Native
    public void onTick(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        // Если ботов нет долгое время, можно очищать список (опционально, как в старом коде)
        if (this.timer.finished(10000L) && !bots.isEmpty()) {
            bots.clear();
            this.timer.reset();
        }

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == null || player == mc.player) continue;

            boolean isBot = false;

            if (mode.is("ReallyWorld")) {
                isBot = reallyWorldCheck(player);
            } else if (mode.is("Matrix")) {
                // ПРОВЕРКА MATRIX (исправленная)
                String playerName = player.getName().getString();
                // Генерируем Offline UUID вручную, так как метода нет в классе
                UUID offlineUUID = UUID.nameUUIDFromBytes(("OfflinePlayer:" + playerName).getBytes(StandardCharsets.UTF_8));

                // Логика: если UUID игрока НЕ совпадает с Offline UUID, считаем его подозрительным/ботом
                if (!player.getUuid().equals(offlineUUID) && !bots.contains(player)) {
                    bots.add(player);
                }
            }

            // Добавляем или удаляем из списка
            if (isBot) {
                if (!bots.contains(player)) {
                    bots.add(player);
                }
            } else if (mode.is("ReallyWorld")) {
                // В режиме ReallyWorld если проверки перестали выполняться — удаляем из ботов
                bots.remove(player);
            }
        }
    }

    // Проверка для ReallyWorld
    private boolean reallyWorldCheck(PlayerEntity player) {
        boolean hasLeatherOrIronArmor = false;

        for (int slot = 0; slot < 4; slot++) {
            ItemStack armorStack = getArmor(player, slot);
            if (armorStack.isEmpty()) continue;

            boolean isLeather = armorStack.getItem() == Items.LEATHER_HELMET
                    || armorStack.getItem() == Items.LEATHER_CHESTPLATE
                    || armorStack.getItem() == Items.LEATHER_LEGGINGS
                    || armorStack.getItem() == Items.LEATHER_BOOTS;

            boolean isIron = armorStack.getItem() == Items.IRON_HELMET
                    || armorStack.getItem() == Items.IRON_CHESTPLATE
                    || armorStack.getItem() == Items.IRON_LEGGINGS
                    || armorStack.getItem() == Items.IRON_BOOTS;

            if (isLeather || isIron) {
                hasLeatherOrIronArmor = true;
            }
        }

        boolean hasNoEnchantedArmor = true;
        for (int slot = 0; slot < 4; slot++) {
            ItemStack armorStack = getArmor(player, slot);
            if (!armorStack.isEmpty() && armorStack.hasEnchantments()) {
                hasNoEnchantedArmor = false;
                break;
            }
        }

        boolean hasNoDamagedArmor = true;
        for (int slot = 0; slot < 4; slot++) {
            ItemStack armorStack = getArmor(player, slot);
            if (!armorStack.isEmpty() && armorStack.isDamaged()) {
                hasNoDamagedArmor = false;
                break;
            }
        }

        boolean hasNotColoredLeather = true;
        for (int slot = 0; slot < 4; slot++) {
            ItemStack armorStack = getArmor(player, slot);
            if (!armorStack.isEmpty() && isLeatherArmor(armorStack) && armorStack.contains(DataComponentTypes.DYED_COLOR)) {
                hasNotColoredLeather = false;
                break;
            }
        }

        boolean offhandEmpty = player.getOffHandStack().isEmpty();
        boolean hasFullFood = player.getHungerManager().getFoodLevel() == 20;

        return hasLeatherOrIronArmor && hasNoEnchantedArmor && hasNoDamagedArmor && hasNotColoredLeather && offhandEmpty && hasFullFood;
    }

    private boolean isLeatherArmor(ItemStack stack) {
        return stack.getItem() == Items.LEATHER_HELMET
                || stack.getItem() == Items.LEATHER_CHESTPLATE
                || stack.getItem() == Items.LEATHER_LEGGINGS
                || stack.getItem() == Items.LEATHER_BOOTS;
    }

    private ItemStack getArmor(PlayerEntity entity, int slot) {
        return entity.getInventory().getArmorStack(slot);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        bots.clear();
    }

    @Override
    public void onDisable() {
        bots.clear();
        super.onDisable();
    }

    // Статический метод для проверки из других модулей (например, KillAura)
    public static boolean isBot(PlayerEntity player) {
        return INSTANCE.isEnabled() && bots.contains(player);
    }
}