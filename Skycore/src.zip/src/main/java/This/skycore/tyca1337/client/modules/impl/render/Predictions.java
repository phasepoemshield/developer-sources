package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.Blocks;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.entity.projectile.thrown.*;
import net.minecraft.item.*;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.render.EventRender2D;
import This.skycore.base.events.impl.render.EventRender3D;
import This.skycore.base.font.Font;
import This.skycore.base.font.Fonts;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.util.game.player.PlayerIntersectionUtil;
import This.skycore.util.game.player.RaytracingUtil;
import This.skycore.util.game.player.rotation.Rotation;
import This.skycore.util.math.MathUtil;
import This.skycore.util.math.ProjectionUtil;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;
import This.skycore.util.render.level.Render3DUtil;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@ModuleAnnotation(
        name = "Predictions",
        category = Category.RENDER,
        description = "Показывает траекторию полета снарядов"
)
public class Predictions extends Module {

    public static final Predictions INSTANCE = new Predictions();

    private final List<Point> points = new ArrayList<>();
    private final Map<Integer, Integer> initialTicks = new HashMap<>();

    private final MultiBooleanSetting projectiles = MultiBooleanSetting.create(
            "Снаряды",
            List.of("Эндер Пёрл", "Стрела", "Трезубец")
    );

    private Predictions() {
    }

    @EventTarget
    public void onDraw(EventRender2D e) {
        CustomDrawContext context = e.getContext();
        ColorRGBA themeColor = SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor();

        for (Point point : points) {
            Vec3d vec3d = ProjectionUtil.worldSpaceToScreenSpace(point.pos);
            if (!ProjectionUtil.canSee(point.pos)) {
                continue;
            }

            float x = (float) vec3d.getX();
            float y = (float) vec3d.getY();
            int ticks = point.ticks;
            float radius = 10.0f;

            context.drawRoundedRect(x - radius, y - radius, radius * 2.0f, radius * 2.0f, BorderRadius.all(radius), new ColorRGBA(20, 20, 20, 160));

            context.getMatrices().push();
            context.getMatrices().translate(x - 8.0f, y - 8.0f, 0.0f);
            context.drawItem(point.stack, 0, 0);
            context.getMatrices().pop();

            int startTicks = initialTicks.getOrDefault(point.entityId, ticks);
            if (ticks > startTicks) {
                initialTicks.put(point.entityId, ticks);
                startTicks = ticks;
            }

            float progress = startTicks > 0 ? (float) ticks / startTicks : 0.0f;
            drawArc(context.getMatrices(), x, y, radius, -90.0f, -90.0f + 360.0f * progress, themeColor.getRGB());

            Font font = Fonts.REGULAR.getFont(6.0F);
            double time = ticks * 50.0 / 1000.0;
            String text = String.format("%.1f", time).replace(",", ".") + "s";
            float textWidth = font.width(text);
            float rectWidth = textWidth + 6.0f;
            float rectHeight = 8.0f;
            float rectX = x - rectWidth / 2.0f;
            float rectY = y + radius + 2.0f;

            context.drawRoundedRect(rectX, rectY, rectWidth, rectHeight, BorderRadius.all(2.0f), new ColorRGBA(20, 20, 20, 160));
            context.drawText(font, text, rectX + (rectWidth - textWidth) / 2.0f, rectY + 1.5f, ColorRGBA.WHITE);
        }
    }

    private void drawArc(MatrixStack matrices, float x, float y, float radius, float startAngle, float endAngle, int color) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        RenderSystem.enableBlend();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);

        int segments = 40;
        for (int i = 0; i <= segments; i++) {
            float angle = startAngle + (endAngle - startAngle) * (i / (float) segments);
            float rad = (float) Math.toRadians(angle);
            float px = x + (float) Math.cos(rad) * radius;
            float py = y + (float) Math.sin(rad) * radius;
            buffer.vertex(matrix, px, py, 0.0f).color(color);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segments; i++) {
            float angle = startAngle + (endAngle - startAngle) * (i / (float) segments);
            float rad = (float) Math.toRadians(angle);
            float px = x + (float) Math.cos(rad) * (radius + 0.5f);
            float py = y + (float) Math.sin(rad) * (radius + 0.5f);
            buffer.vertex(matrix, px, py, 0.0f).color(color);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.disableBlend();
    }

    @EventTarget
    public void onWorldRender(EventRender3D e) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        points.clear();
        drawPredictionInHand(e.getMatrix(), mc.player.getHandItems(), new Rotation(mc.player.getYaw(), mc.player.getPitch()));

        List<Entity> projectiles = getProjectiles();
        initialTicks.keySet().removeIf(id -> projectiles.stream().noneMatch(ent -> ent.getId() == id));

        for (Entity entity : projectiles) {
            Vec3d motion = entity.getVelocity();
            Vec3d pos = entity.getPos();
            Vec3d prevPos;

            for (int i = 0; i < 300; i++) {
                prevPos = pos;
                pos = pos.add(motion);
                motion = calculateMotion(entity, prevPos, motion);
                HitResult result = RaytracingUtil.raycast(prevPos, pos, net.minecraft.world.RaycastContext.ShapeType.COLLIDER, entity);

                if (!result.getType().equals(HitResult.Type.MISS)) {
                    pos = result.getPos();
                }

                Render3DUtil.drawLine(prevPos, pos, ColorUtil.multAlpha(ColorUtil.fade(i), MathHelper.clamp(i / 25.0f, 0.0f, 1.0f)), 2.0f, false);

                if (!result.getType().equals(HitResult.Type.MISS) || pos.y < -128.0) {
                    breakingBad(entity, pos, i);
                    break;
                }
            }
        }
    }

    public void drawPredictionInHand(MatrixStack matrix, Iterable<ItemStack> stacks, Rotation rotation) {
        ItemStack activeItemStack = mc.player.getActiveItem();
        Item activeItem = activeItemStack.getItem();

        for (ItemStack stack : stacks) {
            List<HitResult> results = switch (stack.getItem()) {
                case ExperienceBottleItem item -> checkTrajectory(new ExperienceBottleEntity(mc.world, mc.player, stack), 0.8, rotation);
                case SplashPotionItem item -> checkTrajectory(new PotionEntity(mc.world, mc.player, stack), 0.55, rotation);
                case TridentItem item when item.equals(activeItem) && mc.player.getItemUseTime() >= 10 ->
                        checkTrajectory(new TridentEntity(mc.world, mc.player, stack), 2.5, rotation);
                case SnowballItem item -> checkTrajectory(new SnowballEntity(mc.world, mc.player, stack), 1.5, rotation);
                case EggItem item -> checkTrajectory(new EggEntity(mc.world, mc.player, stack), 1.5, rotation);
                case EnderPearlItem item -> checkTrajectory(new EnderPearlEntity(mc.world, mc.player, stack), 1.5, rotation);
                case BowItem item when item.equals(activeItem) && mc.player.isUsingItem() ->
                        checkTrajectory(new ArrowEntity(mc.world, mc.player, stack, stack),
                                3.0f * MathHelper.clamp((mc.player.getItemUseTime() + mc.getRenderTickCounter().getTickDelta(false)) / 20.0f, 0.0f, 1.0f),
                                rotation);
                case CrossbowItem item when CrossbowItem.isCharged(stack) -> {
                    ChargedProjectilesComponent component = stack.get(DataComponentTypes.CHARGED_PROJECTILES);
                    List<HitResult> list = new ArrayList<>();
                    if (component != null) {
                        float velocity = component.getProjectiles().getFirst().isOf(Items.FIREWORK_ROCKET) ? 1.6F : 3.15F;
                        list.add(checkTrajectory(rotation.toVector(), new ArrowEntity(mc.world, mc.player, stack, stack), velocity));
                        if (component.getProjectiles().size() > 2) {
                            float pitchAbs = rotation.getPitch() / 90.0f;
                            float delta = pitchAbs * pitchAbs * pitchAbs * pitchAbs * pitchAbs;
                            float yaw = MathHelper.lerp(Math.abs(delta), 10.0f, 90.0f);
                            float pitch = MathHelper.lerp(delta, 0.0f, 10.0f);
                            list.add(checkTrajectory(new Rotation(rotation.getYaw() - yaw, rotation.getPitch() - pitch).toVector(),
                                    new ArrowEntity(mc.world, mc.player, stack, stack), velocity));
                            list.add(checkTrajectory(new Rotation(rotation.getYaw() + yaw, rotation.getPitch()).toVector(),
                                    new ArrowEntity(mc.world, mc.player, stack, stack), velocity));
                        }
                    }
                    yield list;
                }
                default -> null;
            };

            if (results != null) {
                results = results.stream().filter(Objects::nonNull).toList();
                if (!results.isEmpty()) {
                    renderProjectileResults(matrix, results);
                }
                for (HitResult res : results) {
                    breakingBadHand(stack, res.getPos(), calculateTicks(stack, res.getPos()));
                }
            }
            return;
        }
    }

    private int calculateTicks(ItemStack stack, Vec3d target) {
        double dist = mc.player.getEyePos().distanceTo(target);
        double speed = switch (stack.getItem()) {
            case EnderPearlItem item -> 1.5;
            case SnowballItem item -> 1.5;
            case EggItem item -> 1.5;
            case ExperienceBottleItem item -> 0.8;
            default -> 1.5;
        };
        return (int) (dist / speed);
    }

    private void breakingBadHand(ItemStack stack, Vec3d pos, int ticks) {
        points.add(new Point(stack, pos, ticks, -1));
    }

    public void renderProjectileResults(MatrixStack matrix, List<HitResult> results) {
        for (HitResult result : results) {
            Direction direction = getDirection(result);
            int color = result.getType().equals(HitResult.Type.ENTITY)
                    ? Color.RED.getRGB()
                    : SkyCore.getInstance().getThemeManager().getClientColor(0).getRGB();
            double width = 0.3;

            Quaternionf quaternionf = switch (direction) {
                case WEST, EAST -> RotationAxis.POSITIVE_Z.rotationDegrees(90.0f);
                case SOUTH, NORTH -> RotationAxis.POSITIVE_X.rotationDegrees(90.0f);
                default -> new Quaternionf();
            };

            matrix.push();
            matrix.translate(result.getPos().x, result.getPos().y, result.getPos().z);
            matrix.multiply(quaternionf);
            for (int i = 0, size = 90; i <= size; i++) {
                Render3DUtil.drawLine(MathUtil.cosSin(i, size, width), MathUtil.cosSin(i + 1, size, width), color, color, 1.0f, false);
            }
            Render3DUtil.drawLine(new Vec3d(0.0, 0.0, -width), new Vec3d(0.0, 0.0, width), color, color, 1.0f, false);
            Render3DUtil.drawLine(new Vec3d(-width, 0.0, 0.0), new Vec3d(width, 0.0, 0.0), color, color, 1.0f, false);
            matrix.pop();
        }
    }

    public List<Entity> getProjectiles() {
        return PlayerIntersectionUtil.streamEntities()
                .filter(ent -> ent instanceof PersistentProjectileEntity
                        || ent instanceof ThrownItemEntity
                        || ent instanceof ItemEntity)
                .filter(this::matchesProjectileSetting)
                .filter(ent -> !visible(ent))
                .toList();
    }

    private boolean matchesProjectileSetting(Entity entity) {
        if (entity instanceof EnderPearlEntity) {
            return projectiles.isEnable("Эндер Пёрл");
        }
        if (entity instanceof ArrowEntity) {
            return projectiles.isEnable("Стрела");
        }
        if (entity instanceof TridentEntity) {
            return projectiles.isEnable("Трезубец");
        }
        return entity instanceof ThrownItemEntity || entity instanceof ItemEntity;
    }

    public List<HitResult> checkTrajectory(ProjectileEntity entity, double velocity, Rotation rotation) {
        return new ArrayList<>(Collections.singleton(checkTrajectory(rotation.toVector(), entity, velocity)));
    }

    public HitResult checkTrajectory(Vec3d lookVec, ProjectileEntity entity, double velocity) {
        float sqrt = MathHelper.sqrt((float) lookVec.lengthSquared());
        Vec3d motion = switch (entity) {
            case ArrowEntity arrow when arrow.getItemStack().getItem().equals(Items.CROSSBOW) -> Vec3d.ZERO;
            default -> mc.player.getPos().subtract(mc.player.prevX, mc.player.prevY, mc.player.prevZ);
        };
        return traceTrajectory(mc.player.getEyePos().add(MathUtil.interpolate(mc.player).subtract(mc.player.getPos())), lookVec.multiply(velocity / sqrt).add(motion), entity);
    }

    public HitResult traceTrajectory(Vec3d pos, Vec3d motion, ProjectileEntity entity) {
        Vec3d prevPos;
        for (int i = 0; i < 300; i++) {
            prevPos = pos;
            pos = pos.add(motion);
            motion = calculateMotion(entity, prevPos, motion);

            HitResult result = RaytracingUtil.raycast(prevPos, pos, net.minecraft.world.RaycastContext.ShapeType.COLLIDER, entity);
            if (!result.getType().equals(HitResult.Type.MISS)) {
                return result;
            }

            Vec3d finalPos = pos;
            Vec3d finalPrevPos = prevPos;
            if (PlayerIntersectionUtil.streamEntities()
                    .filter(ent -> ent instanceof LivingEntity living && living != entity.getOwner() && living.isAlive())
                    .anyMatch(ent -> ent.getBoundingBox().expand(0.3).intersects(finalPrevPos, finalPos))) {
                return new HitResult(pos) {
                    @Override
                    public Type getType() {
                        return Type.ENTITY;
                    }
                };
            }

            if (pos.y < -128.0) {
                break;
            }
        }
        return null;
    }

    public Vec3d calculateMotion(Entity entity, Vec3d prevPos, Vec3d motion) {
        boolean isInWater = mc.world.getFluidState(BlockPos.ofFloored(prevPos)).isIn(FluidTags.WATER);
        double multiply = switch (entity) {
            case TridentEntity trident -> 0.99;
            case PersistentProjectileEntity persistent when isInWater -> 0.6;
            default -> isInWater ? 0.8 : 0.99;
        };
        return motion.multiply(multiply).add(0.0, -entity.getFinalGravity(), 0.0);
    }

    private void breakingBad(Entity entity, Vec3d pos, int ticks) {
        ItemStack stack = switch (entity) {
            case ItemEntity item -> item.getStack();
            case ThrownItemEntity thrown -> thrown.getStack();
            case PersistentProjectileEntity persistent -> persistent.getItemStack();
            default -> ItemStack.EMPTY;
        };

        if (!stack.isEmpty()) {
            points.add(new Point(stack, pos, ticks, entity.getId()));
            initialTicks.putIfAbsent(entity.getId(), ticks);
        }
    }

    private Direction getDirection(HitResult result) {
        if (result instanceof BlockHitResult blockHitResult) {
            return blockHitResult.getSide();
        }
        return Direction.getFacing(result.getPos().subtract(mc.player.getEyePos()).normalize());
    }

    private boolean visible(Entity entity) {
        boolean posChange = entity.getX() == entity.prevX && entity.getY() == entity.prevY && entity.getZ() == entity.prevZ;
        boolean itemEntityCheck = entity instanceof ItemEntity
                && (entity.isOnGround() || PlayerIntersectionUtil.isBoxInBlock(entity.getBoundingBox().expand(2.0), Blocks.WATER));
        return posChange || itemEntityCheck;
    }

    private record Point(ItemStack stack, Vec3d pos, int ticks, int entityId) {
    }
}
