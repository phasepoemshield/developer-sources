package This.skycore.tyca1337.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.player.EventSlowWalking;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(
   name = "NoSlow",
   category = Category.MOVEMENT,
   description = "Убирает замедление во время еды"
)
public final class NoSlow extends Module {
   public static final NoSlow INSTANCE = new NoSlow();
   private final ModeSetting mode = new ModeSetting("Режим", new String[]{"ReallyWorld", "Spooky", "BravoHvH"});
   private final NumberSetting vanillaSpeed = new NumberSetting("Скорость", 0.6F, 0.1F, 1.0F, 0.05F, () -> this.mode.is("BravoHvH"));
   private final BooleanSetting onlyGround = new BooleanSetting("Только на земле", false);
   public static int ticks = 0;
   private static int cycleCounter = 0;

   private NoSlow() {
   }

   @EventTarget
   @Native
   public void onNoSlow(EventSlowWalking e) {
      if (mc.player == null || mc.world == null) {
         return;
      }
      if (mc.player.isGliding()) {
         return;
      }
      if (onlyGround.isEnabled() && !mc.player.isOnGround()) {
         return;
      }
      if (!mc.player.isUsingItem()) {
         return;
      }

      switch (this.mode.getValue().getName()) {
         case "BravoHvH" -> this.handleBravo(e);
         case "ReallyWorld" -> this.handleReallyWorld(e);
         case "Spooky" -> this.handleSpooky(e);
      }
   }

   private void handleReallyWorld(EventSlowWalking e) {
      int[] thresholds = new int[]{2, 3, 3};
      int threshold = thresholds[cycleCounter % 3];
      if (ticks >= threshold) {
         e.setCancelled(true);
         ticks = 0;
         ++cycleCounter;
      }
   }

   private void handleSpooky(EventSlowWalking e) {
      int[] thresholds = new int[]{2, 2};
      int threshold = thresholds[cycleCounter % 2];
      if (ticks >= threshold) {
         e.setCancelled(true);
         ticks = 0;
         ++cycleCounter;
      }
   }

   private void handleBravo(EventSlowWalking e) {
      e.setCancelled(true);
      double vx = mc.player.getVelocity().x * (double)this.vanillaSpeed.getCurrent();
      double vz = mc.player.getVelocity().z * (double)this.vanillaSpeed.getCurrent();
      mc.player.setVelocity(vx, mc.player.getVelocity().y, vz);
   }

   @EventTarget
   public void onUpdate(EventUpdate e) {
      if ((this.mode.is("ReallyWorld") || this.mode.is("Spooky")) && mc.player != null && !mc.player.isGliding()) {
         if (mc.player.isUsingItem()) {
            ++ticks;
         } else {
            ticks = 0;
            cycleCounter = 0;
         }
      }
   }
}
