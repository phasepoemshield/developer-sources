package This.skycore.tyca1337.client.handlers.richidog;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
/**
 * Собака-такса (текстуры: assets/skycore/textures/entity/richidog/taksa.png и djekrussel.png).
 */
public final class RichiDogModel {

    private final ModelPart head;
    private final ModelPart neck;
    private final ModelPart body;
    private final ModelPart frontLeftLeg;
    private final ModelPart frontRightLeg;
    private final ModelPart leftBackLeg;
    private final ModelPart rightBackLeg;
    private final ModelPart tail;

    public RichiDogModel(ModelPart root) {
        this.head = root.getChild("head");
        this.neck = root.getChild("neck");
        this.body = root.getChild("body");
        this.frontLeftLeg = root.getChild("front_left_leg");
        this.frontRightLeg = root.getChild("front_right_leg");
        this.leftBackLeg = root.getChild("left_back_leg");
        this.rightBackLeg = root.getChild("right_back_leg");
        this.tail = root.getChild("tail");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData rootData = data.getRoot();

        ModelPartBuilder headBuilder = ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.0F, -3.0F, -4.0F, 6.0F, 6.0F, 4.0F, Dilation.NONE)
                .uv(21, 0).cuboid(-1.5F, 0.0F, -7.0F, 3.0F, 3.0F, 3.0F, Dilation.NONE);
        ModelPartData headPart = rootData.addChild("head", headBuilder, ModelTransform.pivot(0.0F, 10.5F, -6.8F));

        ModelPartBuilder leftEar = ModelPartBuilder.create()
                .uv(32, 4).cuboid(0.0F, -5.0F, -1.5F, 1.0F, 3.0F, 3.0F, Dilation.NONE)
                .uv(34, 1).cuboid(0.0F, -5.5F, -0.75F, 1.0F, 1.0F, 1.5F, Dilation.NONE);
        headPart.addChild("left_ear", leftEar, ModelTransform.pivot(3.0F, 3.0F, -2.0F));

        ModelPartBuilder rightEar = ModelPartBuilder.create()
                .uv(32, 4).cuboid(-1.0F, -5.0F, -1.5F, 1.0F, 3.0F, 3.0F, Dilation.NONE)
                .uv(34, 1).cuboid(-1.0F, -5.5F, -0.75F, 1.0F, 1.0F, 1.5F, Dilation.NONE);
        headPart.addChild("right_ear", rightEar, ModelTransform.pivot(-3.0F, 3.0F, -2.0F));

        ModelPartBuilder neckBuilder = ModelPartBuilder.create()
                .uv(15, 7).cuboid(-2.95F, -1.0F, -4.0F, 5.9F, 5.0F, 6.0F, Dilation.NONE);
        rootData.addChild("neck", neckBuilder, ModelTransform.pivot(0.0F, 10.5F, -5.0F));

        ModelPartBuilder chest = ModelPartBuilder.create()
                .uv(32, 13).cuboid(-4.0F, -3.5F, -3.0F, 8.0F, 7.0F, 6.0F, Dilation.NONE);
        ModelPartBuilder back = ModelPartBuilder.create()
                .uv(3, 19).cuboid(-3.0F, -3.0F, -0.5F, 6.0F, 6.0F, 11.0F, Dilation.NONE);
        ModelPartData bodyPivot = rootData.addChild("body", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 13.5F, -5.0F));
        bodyPivot.addChild("chest", chest, ModelTransform.pivot(0.0F, 0.0F, 3.0F));
        bodyPivot.addChild("back", back, ModelTransform.pivot(0.0F, -0.5F, 5.5F));

        ModelPartBuilder fl = ModelPartBuilder.create().uv(42, 0).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, Dilation.NONE);
        ModelPartBuilder fr = ModelPartBuilder.create().uv(42, 0).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, Dilation.NONE);
        ModelPartBuilder lb = ModelPartBuilder.create().uv(52, 0).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, Dilation.NONE);
        ModelPartBuilder rb = ModelPartBuilder.create().uv(52, 0).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, Dilation.NONE);
        rootData.addChild("front_left_leg", fl, ModelTransform.pivot(1.5F, 16.0F, -3.0F));
        rootData.addChild("front_right_leg", fr, ModelTransform.pivot(-1.5F, 16.0F, -3.0F));
        rootData.addChild("left_back_leg", lb, ModelTransform.pivot(1.5F, 16.0F, 9.0F));
        rootData.addChild("right_back_leg", rb, ModelTransform.pivot(-1.5F, 16.0F, 9.0F));

        ModelPartBuilder tailBuilder = ModelPartBuilder.create()
                .uv(2, 12).cuboid(-1.0F, 2.0F, -1.0F, 2.0F, 8.0F, 2.0F, Dilation.NONE);
        rootData.addChild("tail", tailBuilder, ModelTransform.pivot(0.0F, 9.0F, 10.0F));

        return TexturedModelData.of(data, 60, 36);
    }

    public void setRotationAngles(float ageInTicks, RichiBrain brain) {
        neck.pitch = -25.0F * ((float) Math.PI / 180.0F);
        head.yaw = brain.getYaw() * ((float) Math.PI / 180F);
        head.pitch = brain.getPitch() * ((float) Math.PI / 180F);

        frontLeftLeg.pitch = (float) Math.cos(brain.limbSwing * 0.6662F) * 1.4F * brain.limbSwingAmount;
        frontRightLeg.pitch = (float) Math.cos(brain.limbSwing * 0.6662F + (float) Math.PI) * 1.4F * brain.limbSwingAmount;
        leftBackLeg.pitch = (float) Math.cos(brain.limbSwing * 0.6662F + (float) Math.PI) * 1.4F * brain.limbSwingAmount;
        rightBackLeg.pitch = (float) Math.cos(brain.limbSwing * 0.6662F) * 1.4F * brain.limbSwingAmount;

        if (brain.isLay()) {
            frontLeftLeg.pitch = (float) Math.toRadians(-90);
            frontRightLeg.pitch = (float) Math.toRadians(-90);
            leftBackLeg.pitch = (float) Math.toRadians(90);
            rightBackLeg.pitch = (float) Math.toRadians(90);

            frontLeftLeg.yaw = (float) Math.toRadians(-22);
            frontRightLeg.yaw = (float) Math.toRadians(22);
            leftBackLeg.yaw = (float) Math.toRadians(22);
            rightBackLeg.yaw = (float) Math.toRadians(-22);
        } else {
            frontLeftLeg.yaw = 0;
            frontRightLeg.yaw = 0;
            leftBackLeg.yaw = 0;
            rightBackLeg.yaw = 0;
        }

        tail.pitch = (float) Math.toRadians(brain.isLay() ? 45 : 22);
        tail.roll = (float) (Math.toRadians(-22.5F) + Math.toRadians(22.5F) + Math.cos(ageInTicks * 0.15F) * 0.3F);
    }

    public void render(MatrixStack matrices, VertexConsumerProvider consumers, int light, int overlay, Identifier texture, RichiBrain brain, float ageInTicks) {
        VertexConsumer buffer = consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(texture));
        matrices.push();
        matrices.translate(0.0, 1.2f - (brain.isLay() ? 0.3f : 0), 0.0);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(180.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(brain.getBody()));

        head.render(matrices, buffer, light, overlay, -1);
        neck.render(matrices, buffer, light, overlay, -1);
        body.render(matrices, buffer, light, overlay, -1);
        frontLeftLeg.render(matrices, buffer, light, overlay, -1);
        frontRightLeg.render(matrices, buffer, light, overlay, -1);
        leftBackLeg.render(matrices, buffer, light, overlay, -1);
        rightBackLeg.render(matrices, buffer, light, overlay, -1);
        tail.render(matrices, buffer, light, overlay, -1);
        matrices.pop();
    }
}
