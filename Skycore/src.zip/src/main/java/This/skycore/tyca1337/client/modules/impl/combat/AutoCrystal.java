package This.skycore.tyca1337.client.modules.impl.combat;

import This.skycore.base.events.impl.input.EventKey;
import This.skycore.tyca1337.client.modules.api.setting.impl.KeySetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import com.darkmagician6.eventapi.EventTarget;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.*;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;

import java.util.*;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@ModuleAnnotation(
        name = "Auto Explosion",
        category = Category.COMBAT,
        description = "Автоматически ставит и взрывает кристаллы"
)
public class AutoCrystal extends Module {
    public static final BooleanSetting autoAddCrystal = new BooleanSetting("Автоматически ставить крисстал", true);
    public static final BooleanSetting instantCrystal = new BooleanSetting("Моментальный кристалл", true);
    public static final NumberSetting addCooldown = new NumberSetting("Задержка на ставку крисстала", 0,0,5,1);
    public static final NumberSetting attackCooldown = new NumberSetting("Задержка на атаку крисстала", 0,0,5,1);

    int attackCrystalCooldown;
    int addCrystalCooldown;

    private EndCrystalEntity findCrystalAbove(BlockPos obsidianPos) {
        EndCrystalEntity closest = null;
        double closestDistance = Double.MAX_VALUE;

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof EndCrystalEntity crystal)) {
                continue;
            }

            if (!crystal.getBlockPos().down().equals(obsidianPos)) {
                continue;
            }

            double distance = mc.player.squaredDistanceTo(crystal);
            if (distance < closestDistance) {
                closestDistance = distance;
                closest = crystal;
            }
        }

        return closest;
    }

    private void attackCrystal(EndCrystalEntity crystal, boolean ignoreCooldown) {
        if (ignoreCooldown || attackCrystalCooldown >= attackCooldown.getCurrent()) {
            mc.interactionManager.attackEntity(mc.player, crystal);
            mc.player.swingHand(Hand.MAIN_HAND);
            attackCrystalCooldown = 0;
            return;
        }

        attackCrystalCooldown++;
    }

    private void addCrystal() {
        if (!(mc.crosshairTarget instanceof BlockHitResult obsidianTarget)) {
            return;
        }

        BlockPos obsidianPos = obsidianTarget.getBlockPos();
        if (mc.world.getBlockState(obsidianPos).getBlock() != Blocks.OBSIDIAN) {
            return;
        }

        if (mc.player.getMainHandStack().getItem() != Items.END_CRYSTAL) {
            return;
        }

        EndCrystalEntity existingCrystal = findCrystalAbove(obsidianPos);
        if (existingCrystal != null) {
            if (instantCrystal.isEnabled()) {
                attackCrystal(existingCrystal, true);
            }
            return;
        }

        Direction side = obsidianTarget.getSide();
        BlockHitResult crystalHit = new BlockHitResult(obsidianTarget.getPos(), side, obsidianPos, true);

        if (instantCrystal.isEnabled()) {
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, crystalHit);
            EndCrystalEntity placedCrystal = findCrystalAbove(obsidianPos);
            if (placedCrystal != null) {
                attackCrystal(placedCrystal, true);
            }
            addCrystalCooldown = 0;
            return;
        }

        if (addCrystalCooldown <= addCooldown.getCurrent()) {
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, crystalHit);
            addCrystalCooldown = 0;
        } else {
            addCrystalCooldown++;
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (autoAddCrystal.isEnabled()) addCrystal();

        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof EndCrystalEntity crystal) {

                if (mc.crosshairTarget instanceof EntityHitResult hitResult) {

                    if (hitResult.getEntity() instanceof EndCrystalEntity hitCrystal) {
                        attackCrystal(hitCrystal, instantCrystal.isEnabled());
                    }
                }
            }
        }
    }
}