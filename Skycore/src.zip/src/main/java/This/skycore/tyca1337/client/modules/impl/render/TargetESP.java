package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.ResourceTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.events.impl.render.EventRender3D;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.impl.combat.Aura;
import This.skycore.util.math.MathUtil;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;
import java.util.ArrayList;
import java.util.List;

@ModuleAnnotation(
        name = "TargetESP",
        category = Category.RENDER,
        description = "Выделяет цель"
)
public class TargetESP extends Module {
    public static final TargetESP INSTANCE = new TargetESP();
    private static final int FOLLOW_GHOST_COUNT = 3;
    private final ModeSetting mode = new ModeSetting("Мод", new String[]{"Маркер", "Призраки", "Преследующие призраки", "Jello", "Botinok", "Души 2", "Rider"});
    private final BooleanSetting throughWalls = new BooleanSetting("Через стены", false, () -> this.mode.is("Jello"));
    private final BooleanSetting damageRed = new BooleanSetting("Краснение", true, () -> this.mode.is("Jello"));
    private final Animation animation;
    private final Animation animation2;
    private final Animation spirits2Animation;
    private final Animation souls2FadeAnimation;
    private LivingEntity souls2Target;
    private Entity lastTarget;
    private boolean textureLoaded;
    private float rotationAngle;
    private float rotationSpeed;
    private boolean isReversing;
    private float ghostAnimSpeed;
    private long ghostAnimLastMs = System.currentTimeMillis();
    /** Как TargetESPHandler.handleGhost (1.16.5): липкий таргет, fade и hurt-mix. */
    private LivingEntity ghostStickyTarget;
    private Vec3d ghostRenderPos;
    private final Animation ghostTimeAnim = new Animation(600L, 1f, Easing.CUBIC_OUT);
    private LivingEntity followGhostStickyTarget;
    private Vec3d followGhostRenderPos;
    private final Animation followGhostFadeAnim = new Animation(600L, Easing.CUBIC_OUT);
    private final Animation ghostHurtAnim = new Animation(200L, 0f, Easing.LINEAR);
    private long currentTime;
    private long startTime;
    private float animationProgress;
    private LivingEntity target;
    private float jelloMoving;
    private long lastDamageTime;
    private int lastTargetHurtTime;
    private float damageFlashIntensity;
    private static final long DAMAGE_FLASH_DURATION = 350L;
    private static final Identifier BLOOM_TEXTURE = SkyCore.id("icons/glow.png");
    /** Как legacy TargetESPHandler (firepart2); положи текстуру в {@code assets/skycore/textures/icons/world_render/firepart2.png}. */
    private static final Identifier GHOST_FIRE_TEXTURE = SkyCore.id("icons/world_render/firepart2.png");
    private final List<GhostTrailParticle> followGhosts = new ArrayList<>();

    public TargetESP() {
        this.animation = new Animation(400L, Easing.CUBIC_OUT);
        this.animation2 = new Animation(250L, Easing.CUBIC_OUT);
        this.spirits2Animation = new Animation(400L, Easing.CUBIC_OUT);
        this.souls2FadeAnimation = new Animation(400L, Easing.CUBIC_OUT);
        this.lastTarget = null;
        this.textureLoaded = false;
        this.rotationAngle = 0.0F;
        this.rotationSpeed = 0.0F;
        this.isReversing = false;
        this.ghostAnimSpeed = 0.0F;
        this.startTime = System.currentTimeMillis();
    }

    public void onEnable() {
        super.onEnable();
    }

    @EventTarget
    private void onRenderWorldLast(EventRender3D e) {
        Entity combatTarget = this.getCombatTarget();
        this.target = combatTarget instanceof LivingEntity living ? living : null;
        this.animationProgress = MathHelper.clamp(this.animation2.getValue(), 0.0F, 1.0F);
        if (this.target != null) {
            if (this.target.hurtTime > this.lastTargetHurtTime) {
                this.lastDamageTime = System.currentTimeMillis();
            }
            this.lastTargetHurtTime = this.target.hurtTime;
        } else {
            this.lastTargetHurtTime = 0;
        }

        if (this.mode.is("Призраки")) {
            this.drawSpiritsTrack(e);
        } else if (this.mode.is("Преследующие призраки")) {
            this.drawFollowingGhosts(e);
        } else if (this.mode.is("Jello")) {
            this.drawJello(e);
        } else if (this.mode.is("Botinok")) {
            this.drawSpirits2(e);
        } else if (this.mode.is("Души 2")) {
            this.drawSouls2(e);
        }

        if (!this.mode.is("Призраки") && !this.mode.is("Преследующие призраки") && !this.mode.is("Jello") && !this.mode.is("Botinok") && !this.mode.is("Души 2")) {
            if (!this.textureLoaded) {
                MinecraftClient.getInstance().getTextureManager().registerTexture(Identifier.of("skycore", "hud/marker.png"), new ResourceTexture(Identifier.of("skycore", "hud/marker.png")));
                this.textureLoaded = true;
            }

            Vec3d camPos = mc.gameRenderer.getCamera().getPos();
            Entity target = Aura.INSTANCE.getTarget();
            if (target != null) {
                this.lastTarget = target;
                this.animation.update(true);
            } else {
                this.animation.update(false);
                if (this.animation.getValue() == 0.0F) {
                    this.lastTarget = null;
                }
            }

            if (this.lastTarget != null) {
                double tickDelta = (double) e.getPartialTicks();
                MatrixStack matrices = e.getMatrix();
                double x = MathHelper.lerp(tickDelta, this.lastTarget.lastRenderX, this.lastTarget.getX());
                double y = MathHelper.lerp(tickDelta, this.lastTarget.lastRenderY, this.lastTarget.getY()) + (double) this.lastTarget.getHeight() / 2.0D;
                double z = MathHelper.lerp(tickDelta, this.lastTarget.lastRenderZ, this.lastTarget.getZ());
                matrices.push();
                matrices.translate(x - camPos.x, y - camPos.y, z - camPos.z);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-mc.gameRenderer.getCamera().getYaw()));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(mc.gameRenderer.getCamera().getPitch()));
                float scale = 0.15F * this.animation.getValue();
                matrices.scale(-scale, -scale, scale);
                this.updateRotation();
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.rotationAngle));
                RenderSystem.disableDepthTest();
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                Identifier textureId = Identifier.of("skycore", "icons/marker.png");
                AbstractTexture abstractTexture = MinecraftClient.getInstance().getTextureManager().getTexture(textureId);
                int texId = abstractTexture.getGlId();
                float alpha = this.animation.getValue();
                float size = 12.0F;
                Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
                ColorRGBA color = theme.getColor().withAlpha((int) (alpha * 255.0F));
                DrawUtil.drawTexture(matrices, textureId, 0.0F - size / 2.0F, 0.0F - size / 2.0F, size, size, color);
                RenderSystem.enableDepthTest();
                RenderSystem.disableBlend();
                matrices.pop();
            }
        }
    }

    private void drawFollowingGhosts(EventRender3D event) {
        Entity auraTarget = this.getCombatTarget();
        if (auraTarget instanceof LivingEntity living && living.isAlive()) {
            this.followGhostStickyTarget = living;
            this.lastTarget = living;
            this.followGhostFadeAnim.update(true);
            this.animation2.update(true);
        } else {
            this.followGhostFadeAnim.update(false);
            this.animation2.update(false);
        }

        LivingEntity renderEntity = this.followGhostStickyTarget;
        float fade = MathHelper.clamp(this.followGhostFadeAnim.getValue(), 0.0f, 1.0f);
        if (renderEntity == null || fade <= 0.01f) {
            if (auraTarget == null) {
                this.followGhosts.clear();
                this.followGhostStickyTarget = null;
                this.followGhostRenderPos = null;
                this.lastTarget = null;
            }
            return;
        }

        Vec3d feet = this.resolveGhostFeet(event, renderEntity, this.followGhostRenderPos);
        if (feet == null) {
            return;
        }
        Vec3d center = new Vec3d(feet.x, feet.y + renderEntity.getHeight() * 0.28, feet.z);
        this.followGhostRenderPos = feet;

        if (this.followGhosts.size() < FOLLOW_GHOST_COUNT) {
            for (int i = this.followGhosts.size(); i < FOLLOW_GHOST_COUNT; i++) {
                this.followGhosts.add(new GhostTrailParticle(center, Vec3d.ZERO));
            }
        }

        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        // Match Souls 2 glow style (additive)
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.depthMask(false);

        ColorRGBA baseColor = SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor();
        float modeAlpha = fade;
        float entityHeight = renderEntity.getHeight();

        this.rotationAngle += 12.5f;
        for (int i = 0; i < this.followGhosts.size(); i++) {
            GhostTrailParticle ghost = this.followGhosts.get(i);
            float angle = this.rotationAngle + (360.0f / FOLLOW_GHOST_COUNT) * i;
            double radians = Math.toRadians(angle);

            double radius = 0.28D;
            double ox = Math.sin(radians) * radius;
            double oz = Math.cos(radians) * radius;
            double oy = -0.05D + Math.sin(Math.toRadians(this.rotationAngle / (i + 1.0f))) * (entityHeight * 0.35);

            Vec3d targetPos = center.add(ox, oy, oz);
            Vec3d motion = targetPos.subtract(ghost.getPosition()).multiply(0.20);
            ghost.setMotion(motion);
            ghost.render(event, BLOOM_TEXTURE, baseColor, 0.3f, modeAlpha);
            ghost.update();
        }

        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    @Native
    private void updateRotation() {
        if (!this.isReversing) {
            this.rotationSpeed += 0.01F;
            if ((double) this.rotationSpeed > 2.3D) {
                this.rotationSpeed = 2.3F;
                this.isReversing = true;
            }
        } else {
            this.rotationSpeed -= 0.01F;
            if ((double) this.rotationSpeed < -2.3D) {
                this.rotationSpeed = -2.3F;
                this.isReversing = false;
            }
        }

        this.rotationAngle += this.rotationSpeed;
        this.rotationAngle %= 360.0F;
    }

    public static double interpolate(double current, double old, double scale) {
        return old + (current - old) * scale;
    }


    private Entity getCombatTarget() {
        return Aura.INSTANCE.getTarget();
    }

    private void drawSouls2(EventRender3D event) {
        Entity current = getCombatTarget();
        if (current instanceof LivingEntity living) {
            this.souls2Target = living;
        }

        this.souls2FadeAnimation.update(current != null);

        if (this.souls2Target == null || this.souls2FadeAnimation.getValue() < 0.01f) {
            if (current == null && this.souls2FadeAnimation.getValue() <= 0.01f) {
                this.souls2Target = null;
            }
            return;
        }

        float partialTicks = event.getPartialTicks();
        LivingEntity entity = this.souls2Target;
        double targetX = MathHelper.lerp(partialTicks, entity.prevX, entity.getX());
        double targetY = MathHelper.lerp(partialTicks, entity.prevY, entity.getY());
        double targetZ = MathHelper.lerp(partialTicks, entity.prevZ, entity.getZ());

        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        double baseX = targetX - cameraPos.x;
        double baseY = targetY - cameraPos.y + entity.getHeight() / 2.0;
        double baseZ = targetZ - cameraPos.z;

        float alphaPC = this.souls2FadeAnimation.getValue();
        ColorRGBA themeColor = SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor();
        int baseColor = themeColor.getRGB();
        long time = System.currentTimeMillis();

        MatrixStack ms = event.getMatrix();
        ms.push();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);

        BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        for (int i = 0; i < 20; i++) {
            float trailFactor = 1.0f - (float) i / 20.0f * 0.7f;
            double angle = 0.15 * ((double) time - (double) i * 10.0) / 25.0;
            float size = 9.5f * 0.02f * trailFactor;

            this.drawOrbitalParticle(ms, buffer, baseX, baseY, baseZ, angle, 1, 1, -1, size, alphaPC, baseColor);
            this.drawOrbitalParticle(ms, buffer, baseX, baseY, baseZ, angle, -1, 1, -1, size, alphaPC, baseColor);
            this.drawOrbitalParticle(ms, buffer, baseX, baseY, baseZ, angle, -1, -1, 1, size, alphaPC, baseColor);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();

        ms.pop();

        if (current == null && this.souls2FadeAnimation.getValue() <= 0.01f) {
            this.souls2Target = null;
        }
    }

    private void drawOrbitalParticle(MatrixStack ms, BufferBuilder buffer, double bx, double by, double bz,
                                     double angle, double sMult, double cMult, double cZMult,
                                     float size, float alphaPC, int baseColor) {
        double s = Math.sin(angle) * 0.7;
        double c = Math.cos(angle) * 0.7;

        double finalX;
        double finalY;
        double finalZ;
        if (sMult == 1 && cMult == 1 && cZMult == -1) {
            finalX = s;
            finalY = c;
            finalZ = -c;
        } else if (sMult == -1 && cMult == 1 && cZMult == -1) {
            finalX = -s;
            finalY = s;
            finalZ = -c;
        } else {
            finalX = -s;
            finalY = -s;
            finalZ = c;
        }

        ms.push();
        ms.translate(bx + finalX, by + finalY, bz + finalZ);
        ms.multiply(mc.gameRenderer.getCamera().getRotation());

        Matrix4f mat = ms.peek().getPositionMatrix();

        int r = (baseColor >> 16) & 0xFF;
        int g = (baseColor >> 8) & 0xFF;
        int b = baseColor & 0xFF;

        float glowSize = size * 2.4f;
        int glowAlpha = (int) (255 * alphaPC * 0.25f);

        buffer.vertex(mat, -glowSize / 2, glowSize / 2, 0.0f).texture(0.0f, 1.0f).color(r, g, b, glowAlpha);
        buffer.vertex(mat, glowSize / 2, glowSize / 2, 0.0f).texture(1.0f, 1.0f).color(r, g, b, glowAlpha);
        buffer.vertex(mat, glowSize / 2, -glowSize / 2, 0.0f).texture(1.0f, 0.0f).color(r, g, b, glowAlpha);
        buffer.vertex(mat, -glowSize / 2, -glowSize / 2, 0.0f).texture(0.0f, 0.0f).color(r, g, b, glowAlpha);

        int coreAlpha = (int) (255 * alphaPC);

        buffer.vertex(mat, -size / 2, size / 2, 0.0f).texture(0.0f, 1.0f).color(r, g, b, coreAlpha);
        buffer.vertex(mat, size / 2, size / 2, 0.0f).texture(1.0f, 1.0f).color(r, g, b, coreAlpha);
        buffer.vertex(mat, size / 2, -size / 2, 0.0f).texture(1.0f, 0.0f).color(r, g, b, coreAlpha);
        buffer.vertex(mat, -size / 2, -size / 2, 0.0f).texture(0.0f, 0.0f).color(r, g, b, coreAlpha);

        ms.pop();
    }

    private void drawSpirits2(EventRender3D event) {
        Entity target = getCombatTarget();
        if (target != null) {
            this.lastTarget = target;
            this.spirits2Animation.update(true);
        } else {
            this.spirits2Animation.update(false);
            if (this.spirits2Animation.getValue() == 0.0F) {
                return;
            }
        }

        float fadeAnim = this.spirits2Animation.getValue();
        if (fadeAnim <= 0.0F) return;
        if (!(this.lastTarget instanceof LivingEntity entityToRender)) return;

        MatrixStack ms = event.getMatrix();
        float partialTicks = event.getPartialTicks();
        Vec3d targetPos = MathUtil.interpolate(entityToRender);
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d cameraPos = camera.getPos();
        float time = (float) (System.currentTimeMillis() - this.startTime) / 1100.0f;
        float fullRotation = 360.0f;
        float rotation = time * fullRotation;
        float orbitRadius = 0.5f;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);

        BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        ColorRGBA themeColor = SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor();
        Quaternionf cameraRotation = camera.getRotation();

        for (int spiral = 0; spiral < 4; spiral++) {
            float spiralOffset = (float) (spiral - 1) * 0.4f;
            float lastSize = -1.0f;

            for (float i = 0.0f; i < 130.0f; i += 1.0f) {
                float angle = rotation + i + spiralOffset * 360.0f;
                double radians = Math.toRadians(-angle);
                double verticalOffset = Math.sin(radians + 2.0) * (double) spiralOffset;

                float size = orbitRadius * (i / 140.0f);
                float avgSize = lastSize >= 0.0f ? (lastSize + size) / 2.0f : size;
                lastSize = size;

                float clampedSize = Math.max(0.0f, Math.min(avgSize * fadeAnim, 1.0f));
                int alpha = (int) (255.0f * fadeAnim * clampedSize);
                int color = themeColor.withAlpha(alpha).getRGB();

                ms.push();
                ms.translate(
                        targetPos.x - cameraPos.x + Math.cos(radians) * (double) orbitRadius,
                        targetPos.y - cameraPos.y + (double) (entityToRender.getHeight() / 2.0f) + verticalOffset,
                        targetPos.z - cameraPos.z + Math.sin(radians) * (double) orbitRadius
                );
                ms.multiply(cameraRotation);

                float halfSize = avgSize / 2.0f;
                Matrix4f matrix = ms.peek().getPositionMatrix();

                int r = (color >> 16) & 0xFF;
                int g = (color >> 8) & 0xFF;
                int b = color & 0xFF;
                int a = (color >> 24) & 0xFF;

                buffer.vertex(matrix, -halfSize, -halfSize, 0.0f).texture(0.0f, 0.0f).color(r, g, b, a);
                buffer.vertex(matrix, halfSize, -halfSize, 0.0f).texture(1.0f, 0.0f).color(r, g, b, a);
                buffer.vertex(matrix, halfSize, halfSize, 0.0f).texture(1.0f, 1.0f).color(r, g, b, a);
                buffer.vertex(matrix, -halfSize, halfSize, 0.0f).texture(0.0f, 1.0f).color(r, g, b, a);

                ms.pop();
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
    }

    /** Позиция ног (как MathUtil.interpolate) — без смещения по Y. */
    private Vec3d resolveGhostFeet(EventRender3D event, LivingEntity entity, Vec3d fallback) {
        if (entity.isAlive() && entity.getWorld() != null && mc.world != null && mc.world.getEntityById(entity.getId()) != null) {
            float tick = event.getPartialTicks();
            double tx = MathHelper.lerp(tick, entity.lastRenderX, entity.getX());
            double ty = MathHelper.lerp(tick, entity.lastRenderY, entity.getY());
            double tz = MathHelper.lerp(tick, entity.lastRenderZ, entity.getZ());
            return new Vec3d(tx, ty, tz);
        }
        return fallback;
    }

    private void drawSpiritsTrack(EventRender3D event3D) {
        Entity auraTarget = Aura.INSTANCE.getTarget();
        if (auraTarget instanceof LivingEntity living && living.isAlive()) {
            ghostStickyTarget = living;
            ghostTimeAnim.update(1f);
        } else {
            ghostTimeAnim.update(0f);
        }

        if (ghostStickyTarget == null) {
            ghostRenderPos = null;
            this.ghostAnimLastMs = System.currentTimeMillis();
            return;
        }

        float timeVal = ghostTimeAnim.getValue();
        if (timeVal <= 0.01f) {
            ghostStickyTarget = null;
            ghostRenderPos = null;
            return;
        }

        Vec3d feet = this.resolveGhostFeet(event3D, ghostStickyTarget, this.ghostRenderPos);
        if (feet == null) {
            return;
        }
        this.ghostRenderPos = feet;

        float hf = ghostStickyTarget.maxHurtTime > 0
                ? MathHelper.clamp((float) ghostStickyTarget.hurtTime / (float) ghostStickyTarget.maxHurtTime, 0f, 1f)
                : 0f;
        ghostHurtAnim.update(hf);
        long tickNow = System.currentTimeMillis();
        this.ghostAnimSpeed += 9.0F * (float) (tickNow - this.ghostAnimLastMs) / 1000.0F;
        this.ghostAnimLastMs = tickNow;

        MatrixStack ms = event3D.getMatrix();
        Vec3d camPos = mc.gameRenderer.getCamera().getPos();
        double x = feet.x - camPos.x;
        double y = feet.y - camPos.y;
        double z = feet.z - camPos.z;

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA moduleVis = theme.getColor();
        int mr = moduleVis.getRed();
        int mg = moduleVis.getGreen();
        int mb = moduleVis.getBlue();
        int ma = moduleVis.getAlpha();
        float mx = ghostHurtAnim.getValue();

        Identifier particleTex = GHOST_FIRE_TEXTURE;
        if (mc.getResourceManager().getResource(SkyCore.id("textures/icons/world_render/firepart2.png")).isEmpty()) {
            particleTex = BLOOM_TEXTURE;
        }

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, particleTex);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        int rings = 3;
        int n3 = 12;
        int n4 = 3 * rings;
        float halfBase = 25.0F;

        for (int i = 0; i < n4; i += rings) {
            for (int j = 0; j < n3; ++j) {
                int tr = MathHelper.clamp((int) (mr * (1f - mx) + 255 * mx), 0, 255);
                int tg = MathHelper.clamp((int) (mg * (1f - mx)), 0, 255);
                int tb = MathHelper.clamp((int) (mb * (1f - mx)), 0, 255);
                int ta = MathHelper.clamp((int) (ma * timeVal), 0, 255);

                float f2 = this.ghostAnimSpeed + j * 0.1F;
                float f3 = 0.8F;
                float f4 = 0.5F;
                int n5 = (int) Math.pow(i, 2.0);
                float sc = timeVal * (0.005f + j / 1800.0f);

                ms.push();
                ms.translate(
                        x + (double) (f3 * MathHelper.sin(f2 + (float) n5)),
                        y + (double) f4 + (double) (0.3F * MathHelper.sin(this.ghostAnimSpeed + j * 0.2F)) + (double) (0.2F * i),
                        z + (double) (f3 * MathHelper.cos(f2 - (float) n5))
                );
                ms.scale(sc, sc, sc);
                ms.multiply(mc.gameRenderer.getCamera().getRotation());

                Matrix4f mat = ms.peek().getPositionMatrix();
                float half = halfBase;
                buffer.vertex(mat, -half, half, 0.0F).texture(0.0F, 1.0F).color(tr, tg, tb, ta);
                buffer.vertex(mat, half, half, 0.0F).texture(1.0F, 1.0F).color(tr, tg, tb, ta);
                buffer.vertex(mat, half, -half, 0.0F).texture(1.0F, 0.0F).color(tr, tg, tb, ta);
                buffer.vertex(mat, -half, -half, 0.0F).texture(0.0F, 0.0F).color(tr, tg, tb, ta);
                ms.pop();
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
    }

    private int applyDamageFlash(int color) {
        if (!this.damageRed.isEnabled()) return color;

        float targetIntensity = 0.0F;
        long timeSinceDamage = System.currentTimeMillis() - this.lastDamageTime;
        if (timeSinceDamage < DAMAGE_FLASH_DURATION) {
            float progress = (float) timeSinceDamage / (float) DAMAGE_FLASH_DURATION;
            targetIntensity = 1.0F - this.easeOutCubic(progress);
        }

        this.damageFlashIntensity = MathHelper.lerp(0.1F, this.damageFlashIntensity, targetIntensity);
        if (this.damageFlashIntensity < 0.05F) return color;

        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int a = (color >> 24) & 0xFF;
        int finalR = (int) MathHelper.lerp(this.damageFlashIntensity, r, 255);
        int finalG = (int) MathHelper.lerp(this.damageFlashIntensity, g, 50);
        int finalB = (int) MathHelper.lerp(this.damageFlashIntensity, b, 50);
        return (a << 24) | (finalR << 16) | (finalG << 8) | finalB;
    }

    private float easeOutCubic(float x) {
        float clamped = MathHelper.clamp(x, 0.0F, 1.0F);
        return 1.0F - (float) Math.pow(1.0F - clamped, 3.0F);
    }

    private float easeOutQuad(float x) {
        float clamped = MathHelper.clamp(x, 0.0F, 1.0F);
        return 1.0F - (1.0F - clamped) * (1.0F - clamped);
    }

    private int getThemeColor() {
        int base = SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB();
        return this.applyDamageFlash(base);
    }

    private void drawJello(EventRender3D event) {
        this.jelloMoving += 4.0F;
        this.animation2.update(this.target != null && Aura.INSTANCE.isEnabled());
        this.animationProgress = MathHelper.clamp(this.animation2.getValue(), 0.0F, 1.0F);

        float alpha = this.animationProgress;
        if (alpha <= 0.0F) return;

        LivingEntity entityToRender = this.target != null ? this.target : (this.lastTarget instanceof LivingEntity living ? living : null);
        if (entityToRender == null) return;

        Camera camera = mc.gameRenderer.getCamera();
        Vec3d cameraPos = camera.getPos();
        Vec3d targetPos = MathUtil.interpolate(entityToRender);
        Vec3d renderPos = targetPos.subtract(cameraPos);

        float entityWidth = entityToRender.getWidth() * 1.65F;
        float entityHeight = entityToRender.getHeight() - 0.15F;
        float alphaAnim = (this.target != null) ? easeOutCubic(alpha) : easeOutQuad(alpha);
        int color = getThemeColor();

        MatrixStack matrices = event.getMatrix();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();

        if (this.throughWalls.isEnabled()) {
            RenderSystem.disableDepthTest();
        } else {
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
        }

        matrices.push();
        matrices.translate(renderPos.x, renderPos.y, renderPos.z);
        RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

        BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        for (int i = 0; i < 360; i += 2) {
            float scale = Math.max(0.5F, 0.7F - 0.2F * alphaAnim);
            double rad = Math.toRadians(i + this.jelloMoving);
            float xOffset = (float) (Math.cos(rad) * entityWidth * scale);
            float zOffset = (float) (Math.sin(rad) * entityWidth * scale);
            float sizeBase = 0.2F;

            for (int j = 0; j < 15; ++j) {
                float yOffsetLayer = entityHeight / 1.7F + (entityHeight / 2.0F) * (float) Math.cos(Math.toRadians(this.jelloMoving / 1.5F + j * 2.0F));
                matrices.push();
                matrices.translate(xOffset, yOffsetLayer, zOffset);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                MatrixStack.Entry entry = matrices.peek();
                int finalAlpha = (int) (255 * alphaAnim * ((float) j / 15.0F) * 0.05F);
                int r = (color >> 16) & 0xFF;
                int g = (color >> 8) & 0xFF;
                int b = color & 0xFF;
                buffer.vertex(entry.getPositionMatrix(), -sizeBase / 2.0F, -sizeBase / 2.0F, 0).texture(0, 0).color(r, g, b, finalAlpha);
                buffer.vertex(entry.getPositionMatrix(), sizeBase / 2.0F, -sizeBase / 2.0F, 0).texture(1, 0).color(r, g, b, finalAlpha);
                buffer.vertex(entry.getPositionMatrix(), sizeBase / 2.0F, sizeBase / 2.0F, 0).texture(1, 1).color(r, g, b, finalAlpha);
                buffer.vertex(entry.getPositionMatrix(), -sizeBase / 2.0F, sizeBase / 2.0F, 0).texture(0, 1).color(r, g, b, finalAlpha);
                matrices.pop();
            }
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        matrices.pop();

        matrices.push();
        matrices.translate(renderPos.x, renderPos.y, renderPos.z);
        RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        for (int i = 0; i < 360; i += 2) {
            float scale = Math.max(0.5F, 0.7F - 0.2F * alphaAnim);
            double rad = Math.toRadians(i + this.jelloMoving);
            float xOffset = (float) (Math.cos(rad) * entityWidth * scale);
            float zOffset = (float) (Math.sin(rad) * entityWidth * scale);
            float yOffset = entityHeight / 1.75F + (entityHeight / 2.0F) * (float) Math.cos(Math.toRadians(this.jelloMoving / 1.5F + 30.0F));
            float sizeLarge = 0.2F;

            matrices.push();
            matrices.translate(xOffset, yOffset, zOffset);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
            MatrixStack.Entry entry = matrices.peek();
            int finalAlpha = (int) (255 * alphaAnim * 0.2F);
            int r = (color >> 16) & 0xFF;
            int g = (color >> 8) & 0xFF;
            int b = color & 0xFF;
            buffer.vertex(entry.getPositionMatrix(), -sizeLarge / 2.0F, -sizeLarge / 2.0F, 0).texture(0, 0).color(r, g, b, finalAlpha);
            buffer.vertex(entry.getPositionMatrix(), sizeLarge / 2.0F, -sizeLarge / 2.0F, 0).texture(1, 0).color(r, g, b, finalAlpha);
            buffer.vertex(entry.getPositionMatrix(), sizeLarge / 2.0F, sizeLarge / 2.0F, 0).texture(1, 1).color(r, g, b, finalAlpha);
            buffer.vertex(entry.getPositionMatrix(), -sizeLarge / 2.0F, sizeLarge / 2.0F, 0).texture(0, 1).color(r, g, b, finalAlpha);
            matrices.pop();
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        matrices.pop();

        if (!this.throughWalls.isEnabled()) {
            RenderSystem.depthMask(true);
        }
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }
}
