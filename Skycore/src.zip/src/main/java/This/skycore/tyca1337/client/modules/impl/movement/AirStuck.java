package This.skycore.tyca1337.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import This.skycore.base.events.impl.player.EventMotion;
import This.skycore.base.events.impl.player.EventTravel;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.tyca1337.helpers.EventWorldChanged;

@ModuleAnnotation(
        name = "Air Stuck",
        category = Category.MOVEMENT,
        description = "Можно зависнуть в воздухе"
)
public final class AirStuck extends Module {

    public static final AirStuck INSTANCE = new AirStuck();

    private final BooleanSetting changeAuraDistance = new BooleanSetting("Изменять дистанцию киллауры", false);
    private final NumberSetting auraDistance = new NumberSetting("Дистанция киллауры", 3.5F, 2.0F, 6.0F, 0.1F, changeAuraDistance::isEnabled);
    private final BooleanSetting catchMoment = new BooleanSetting("Ловить момент", true);

    private double peakY = Double.NaN;
    private boolean frozen;

    private AirStuck() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (catchMoment.isEnabled()) {
            peakY = mc.player != null && !mc.player.isOnGround() ? mc.player.getY() : Double.NaN;
            frozen = false;
        } else {
            frozen = true;
        }
    }

    @Override
    public void onDisable() {
        frozen = false;
        super.onDisable();
    }

    public float getKillAuraDistance() {
        if (isEnabled() && changeAuraDistance.isEnabled()) {
            return auraDistance.getCurrent();
        }
        return -1.0F;
    }

    public boolean isFrozen() {
        return isEnabled() && frozen;
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || !catchMoment.isEnabled()) {
            return;
        }

        double currentY = mc.player.getY();
        if (mc.player.isOnGround()) {
            peakY = Double.NaN;
            frozen = false;
        } else if (!frozen) {
            if (Double.isNaN(peakY)) {
                peakY = currentY;
            } else if (currentY > peakY) {
                peakY = currentY;
            } else if (currentY < peakY) {
                frozen = true;
            }
        }
    }

    @EventTarget
    public void onSwapWorld(EventWorldChanged event) {
        toggle();
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (mc.player == null || !frozen) {
            return;
        }
        if (event.isSent() && event.getPacket() instanceof PlayerMoveC2SPacket) {
            event.cancel();
        }
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!frozen) {
            return;
        }
        event.cancel();
    }

    @EventTarget
    public void onTravel(EventTravel event) {
        if (frozen && event.getEntity() == mc.player) {
            event.cancel();
        }
    }
}
