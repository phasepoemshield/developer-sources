package This.skycore.tyca1337.client.modules.api;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface ModuleAnnotation {
   String name();

   Category category();

   String description();

   /** Глиф NUR для уведомления / HUD; пусто — берётся первая буква имени. */
   String nurIcon() default "";
}
