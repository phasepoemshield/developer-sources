package This.skycore.tyca1337.client.ui.menu.components;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Fonts;
import This.skycore.base.font.MsdfRenderer;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.setting.Setting;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ColorSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.KeySetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.tyca1337.client.ui.menu.MenuScreen;
import This.skycore.util.math.MathUtil;
import This.skycore.util.render.display.Keyboard;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;

public class CategoryPanel {

    private static final Map<Integer, DecimalFormat> NUMBER_FORMATS = new HashMap<>();
    private static final Map<Integer, Integer> INCREMENT_SCALES = new HashMap<>();
    private static final int MAX_DECIMALS = 2;

    private final Category category;
    private float x, y;
    private float width;
    private final float panelHeight = 295;
    private float needToScroll = 0;
    private final Animation scroll = new Animation(200, Easing.CUBIC_OUT);
    private float maxScroll = 0;

    private final List<ModuleEntry> modules = new ArrayList<>();

    private String lastSearchLower = "";
    private final List<ModuleEntry> filteredModules = new ArrayList<>();

    private boolean dragging = false;
    private float dragOffsetX, dragOffsetY;

    private Module bindingModule = null;
    private NumberSetting draggingSlider = null;
    private float draggingSliderLeft = 0;
    private float draggingSliderWidth = 0;
    private KeySetting bindingKeySetting = null;

    private final Map<ModeSetting.Value, Animation> modeAnimations = new HashMap<>();
    private final Map<MultiBooleanSetting.Value, Animation> multiBoolAnimations = new HashMap<>();

    public CategoryPanel(Category category, float x, float y, float width) {
        this.category = category;
        this.x = x;
        this.y = y;
        this.width = width;

        for (Module module : SkyCore.getInstance().getModuleManager().getModules()) {
            if (module.getCategory() == category) {
                modules.add(new ModuleEntry(module));
            }
        }

        modules.sort(Comparator.comparing(e -> e.module.getName(), String.CASE_INSENSITIVE_ORDER));
        filteredModules.addAll(modules);
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getPanelHeight() {
        return panelHeight;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    private void updateSearchCache() {
        String s = MenuScreen.searchText;
        String lower = s == null ? "" : s.toLowerCase(Locale.ROOT);
        if (lower.equals(lastSearchLower)) {
            return;
        }

        lastSearchLower = lower;
        filteredModules.clear();
        if (lower.isEmpty()) {
            filteredModules.addAll(modules);
            return;
        }

        for (ModuleEntry entry : modules) {
            if (entry.nameLower.contains(lower)) {
                filteredModules.add(entry);
            }
        }
    }

    public void render(CustomDrawContext ctx, int mouseX, int mouseY, float alpha, Theme theme) {
        scroll.update(needToScroll);

        updateSearchCache();

        if (dragging) {
            x = mouseX - dragOffsetX;
            y = mouseY - dragOffsetY;
        }

        // Фон панели в стиле KeybindsComponent
        ColorRGBA logoColor = theme.getColor();
        ColorRGBA panelBg = ColorUtil.darkenBrightness(logoColor, 0.1f).mulAlpha(alpha);

        ctx.drawRoundedRect(x, y, width, panelHeight, BorderRadius.all(6), panelBg);

        float innerX = x;
        float innerY = y + 28;
        float innerWidth = width;
        float innerHeight = panelHeight - 35;

        ctx.drawRoundedRect(x, y, width, 26, new BorderRadius(6, 6, 0, 0), panelBg);
        float headerHeight = 26;
        float textCenterY = y + (headerHeight - 10) / 2;

        // Текст заголовка категории (Combat, Render и т.д.)
        ctx.drawText(Fonts.SEMIBOLD.getFont(10), category.getName(), x + 10, textCenterY,
                new ColorRGBA(255, 255, 255, (int) (180 * alpha)));
        ctx.drawText(Fonts.ICONS.getFont(10), category.getIcon(), x + width - 18, textCenterY,
                new ColorRGBA(255, 255, 255, (int) (180 * alpha)));

        ctx.enableScissor((int) x, (int) (y + 26), (int) (x + width), (int) (y + panelHeight));

        float moduleY = innerY + scroll.getValue();
        float totalHeight = 0;

        float clipTop = y + 26;
        float clipBottom = y + panelHeight;

        for (ModuleEntry entry : filteredModules) {
            entry.expandAnimation.update(entry.expanded);
            entry.enableAnimation.update(entry.module.isEnabled());

            float expandAnim = entry.expandAnimation.getValue();
            float enableAnim = entry.enableAnimation.getValue();

            float moduleHeight = calculateModuleHeight(entry.module, expandAnim);
            if (moduleY + moduleHeight >= clipTop && moduleY <= clipBottom) {
                renderModule(ctx, entry, mouseX, mouseY, moduleY, alpha, theme, innerX, innerWidth, expandAnim, enableAnim);
            }

            entry.y = moduleY;
            entry.height = moduleHeight;
            entry.moduleX = innerX + 6;
            entry.moduleWidth = innerWidth - 13;

            float spacing = 4.5f;
            moduleY += moduleHeight + spacing;
            totalHeight += moduleHeight + spacing;
        }

        ctx.disableScissor();

        maxScroll = Math.max(0, totalHeight - innerHeight + 6);

        if (draggingSlider != null) {
            updateSlider(mouseX, draggingSlider);
        }
    }

    private float calculateModuleHeight(Module module, float expandAnim) {
        if (expandAnim <= 0.01f) {
            return 18;
        }
        return 18 + calculateSettingsHeight(module) * expandAnim;
    }

    private void renderModule(CustomDrawContext ctx, ModuleEntry entry, int mouseX, int mouseY,
                              float moduleY, float alpha, Theme theme, float innerX, float innerWidth,
                              float expandAnim, float enableAnim) {
        Module module = entry.module;

        float moduleX = innerX + 5;
        float moduleWidth = innerWidth - 10;

        float totalHeight = calculateModuleHeight(module, expandAnim);

        ColorRGBA disabledColor = new ColorRGBA(80, 80, 80, (int) (64 * alpha));
        ColorRGBA enabledColor = theme.getColor().withAlpha((int) (64 * alpha));
        ColorRGBA moduleBg = disabledColor.mix(enabledColor, enableAnim);
        ctx.drawRoundedRect(moduleX, moduleY, moduleWidth, totalHeight, BorderRadius.all(4), moduleBg);

        String name = module.getName();
        if (bindingModule == module) {
            name = name + "...";
        }

        float maxNameWidth = moduleWidth - 20;
        float nameY = moduleY + (18 - 8) / 2 + 1;

        MsdfRenderer.renderText(Fonts.REGULAR.getFont(8).getFont(), name, 8f,
                new ColorRGBA(255, 255, 255, (int) (255 * alpha)).getRGB(),
                ctx.getMatrices().peek().getPositionMatrix(),
                moduleX + 6, nameY, 0, true, 0.75f, 1.0f, maxNameWidth);

        float rightOffset = 6;
        if (!module.getSettings().isEmpty()) {
            entry.arrowAnimation.update(entry.expanded);

            entry.closedArrowAlpha.update(!entry.expanded);
            entry.openedArrowAlpha.update(entry.expanded);

            float closedAlpha = entry.closedArrowAlpha.getValue();
            float openedAlpha = entry.openedArrowAlpha.getValue();

            float arrowBoxSize = 12;
            float arrowBoxX = moduleX + moduleWidth - arrowBoxSize - 4;
            float arrowBoxY = moduleY + 3;

            float maxAlpha = Math.max(closedAlpha, openedAlpha);


            float centerX = arrowBoxX + arrowBoxSize / 2;
            float centerY = arrowBoxY + arrowBoxSize / 2;

            ctx.getMatrices().push();
            ctx.getMatrices().translate(centerX, centerY, 0);
            ctx.getMatrices().multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(45));


            if (openedAlpha > 0.01f) {

            }

            ctx.getMatrices().pop();

            rightOffset = 22;
        }




        if (expandAnim > 0.01f && !module.getSettings().isEmpty()) {
            float settingY = moduleY + 18 - 2;
            boolean isFirst = true;
            for (Setting setting : module.getSettings()) {
                setting.getAnimationAlpha().update(setting.isVisible());
                float visValue = setting.getAnimationAlpha().getValue();

                if (visValue < 0.01f) {
                    continue;
                }

                settingY = renderSetting(ctx, setting, mouseX, mouseY, settingY, alpha, theme, expandAnim, moduleX, moduleWidth, module.isEnabled(), visValue, isFirst);
                isFirst = false;
            }
        }
    }

    private float renderSetting(CustomDrawContext ctx, Setting setting, int mouseX, int mouseY,
                                float settingY, float alpha, Theme theme, float expandAlpha,
                                float moduleX, float moduleWidth, boolean moduleEnabled, float visibilityAnim, boolean isFirst) {
        float settingAlpha = alpha * expandAlpha * visibilityAnim;
        float leftPad = moduleX + 5;
        float rightPad = moduleX + moduleWidth - 5;
        float settingWidth = moduleWidth - 10;

        if (setting instanceof BooleanSetting bool) {
            float topPadding = isFirst ? 3 : 0;
            float height = (12 + topPadding) * visibilityAnim;
            ctx.drawText(Fonts.REGULAR.getFont(7), bool.getName(), leftPad, settingY + 2.5f + topPadding,
                    new ColorRGBA(222, 222, 222, (int) (255 * settingAlpha)));

            float anim = bool.getAnimation().getValue();

            float boxSize = 10;
            float boxX = rightPad - boxSize + 3;
            float boxY = settingY + topPadding - 1;
            ctx.drawRoundedRect(boxX, boxY, boxSize, boxSize, BorderRadius.all(2), new ColorRGBA(100, 100, 100, (int) (120 * settingAlpha)));

            if (anim > 0.01f) {
                float iconSize = 6.5f;
                float scaledSize = iconSize * anim;
                float iconX = boxX + (boxSize - scaledSize) / 2;
                float iconY = boxY + (boxSize - scaledSize) / 2;
                ColorRGBA ok = new ColorRGBA(80, 255, 80, (int) (255 * settingAlpha * anim));
                ctx.drawText(Fonts.ICONS.getFont(scaledSize), "S", iconX + 0.9f, iconY + 0.6f, ok);
            }

            if (anim < 0.99f) {
                float crossAnim = 1f - anim;
                float iconSize = 5.5f;
                float scaledSize = iconSize * crossAnim;
                float iconX = boxX + (boxSize - scaledSize) / 2;
                float iconY = boxY + (boxSize - scaledSize) / 2;
                ColorRGBA cross = new ColorRGBA(255, 80, 80, (int) (255 * settingAlpha * crossAnim));
                ctx.drawText(Fonts.ICONS.getFont(scaledSize), "M", iconX + 0.9f, iconY + 0.6f, cross);
            }

            return settingY + height;
        }

        if (setting instanceof NumberSetting number) {
            float height = 19 * visibilityAnim;

            String valueStr = formatNumber(number);

            ctx.drawText(Fonts.REGULAR.getFont(6.5f), number.getName(), leftPad, settingY + 2.0f,
                    new ColorRGBA(222, 222, 222, (int) (255 * settingAlpha)));
            ctx.drawText(Fonts.REGULAR.getFont(6.5f), valueStr, rightPad - Fonts.REGULAR.getWidth(valueStr, 7), settingY + 2.0f,
                    new ColorRGBA(222, 222, 222, (int) (255 * settingAlpha)));

            float sliderY = settingY + 11 * visibilityAnim;
            float sliderWidth = settingWidth;
            float sliderHeight = 4;
            float progress = (number.getCurrent() - number.getMin()) / (number.getMax() - number.getMin());

            ColorRGBA sliderBg = moduleEnabled
                    ? theme.getColor().withAlpha((int) (25 * settingAlpha))
                    : new ColorRGBA(0, 0, 0, (int) (25 * settingAlpha));
            ctx.drawRoundedRect(leftPad, sliderY, sliderWidth, sliderHeight,
                    BorderRadius.all(1), sliderBg);

            if (progress > 0) {
                ctx.drawRoundedRect(leftPad, sliderY, sliderWidth * progress, sliderHeight,
                        BorderRadius.all(1), theme.getColor().withAlpha((int) (255 * settingAlpha)));
            }

            float circleSize = 7;
            float circleX = leftPad + MathHelper.clamp(sliderWidth * progress, 0, sliderWidth) - circleSize / 2;
            float circleY = sliderY - (circleSize - sliderHeight) / 2;
            ctx.drawRoundedRect(circleX, circleY, circleSize, circleSize,
                    BorderRadius.all(circleSize / 2), new ColorRGBA(255, 255, 255, (int) (255 * settingAlpha)));

            return settingY + height;
        }

        if (setting instanceof ModeSetting mode) {
            float rowHeight = 10;
            float boxHeight = Math.max(22, mode.getValues().size() * rowHeight + 8);
            float totalHeight = (12 + boxHeight + 5) * visibilityAnim;

            ctx.drawText(Fonts.REGULAR.getFont(7), mode.getName(), leftPad, settingY + 3.5f,
                    new ColorRGBA(255, 255, 255, (int) (255 * settingAlpha)));

            float boxY = settingY + 12 * visibilityAnim;
            ctx.drawRoundedRect(leftPad - 2, boxY, settingWidth + 4, boxHeight * visibilityAnim,
                    BorderRadius.all(4), new ColorRGBA(30, 30, 30, (int) (180 * settingAlpha)));

            float optionY = boxY + 4 * visibilityAnim;
            for (ModeSetting.Value val : mode.getValues()) {
                boolean selected = val.isSelected();

                Animation anim = modeAnimations.computeIfAbsent(val, v -> new Animation(350, Easing.CUBIC_OUT));
                anim.update(selected);
                float animValue = anim.getValue();

                int textBrightness = (int) (150 + 105 * animValue);
                ColorRGBA textColor = new ColorRGBA(textBrightness, textBrightness, textBrightness, (int) (255 * settingAlpha));
                float textY = optionY + (rowHeight - 6) / 2 + 0.5f;
                ctx.drawText(Fonts.REGULAR.getFont(6), val.getName(), leftPad + 2, textY, textColor);

                if (animValue > 0.01f) {
                    float circleSize = 4.5f;
                    float circleX = rightPad - circleSize - 1.5f;
                    float circleY = textY + 0.3f;
                    ctx.drawRoundedRect(circleX, circleY, circleSize, circleSize,
                            BorderRadius.all(circleSize / 2), theme.getColor().withAlpha((int) (255 * settingAlpha * animValue)));
                }

                optionY += rowHeight * visibilityAnim;
            }
            return settingY + totalHeight;
        }

        if (setting instanceof MultiBooleanSetting multi) {
            float rowHeight = 10;
            float boxHeight = multi.getBooleanSettings().size() * rowHeight + 8;
            float totalHeight = (14 + boxHeight + 5) * visibilityAnim;

            int enabled = (int) multi.getBooleanSettings().stream().filter(MultiBooleanSetting.Value::isEnabled).count();
            String count = enabled + "/" + multi.getBooleanSettings().size();
            float nameWidth = Fonts.REGULAR.getWidth(multi.getName(), 7);

            ctx.drawText(Fonts.REGULAR.getFont(7), multi.getName(), leftPad, settingY + 3.5f,
                    new ColorRGBA(255, 255, 255, (int) (255 * settingAlpha)));
            ctx.drawText(Fonts.REGULAR.getFont(6), count, leftPad + nameWidth + 4, settingY + 4.5f,
                    new ColorRGBA(120, 120, 120, (int) (255 * settingAlpha)));

            float boxY = settingY + 14 * visibilityAnim;
            ctx.drawRoundedRect(leftPad - 2, boxY, settingWidth + 4, boxHeight * visibilityAnim,
                    BorderRadius.all(4), new ColorRGBA(30, 30, 30, (int) (180 * settingAlpha)));

            float optionY = boxY + 4 * visibilityAnim;
            for (MultiBooleanSetting.Value val : multi.getBooleanSettings()) {
                boolean selected = val.isEnabled();

                Animation anim = multiBoolAnimations.computeIfAbsent(val, v -> new Animation(350, Easing.CUBIC_OUT));
                anim.update(selected);
                float animValue = anim.getValue();

                int textBrightness = (int) (150 + 105 * animValue);
                ColorRGBA textColor = new ColorRGBA(textBrightness, textBrightness, textBrightness, (int) (255 * settingAlpha));
                float textY = optionY + (rowHeight - 6) / 2 + 0.5f;
                ctx.drawText(Fonts.REGULAR.getFont(6), val.getName(), leftPad + 2, textY, textColor);

                if (animValue > 0.01f) {
                    float circleSize = 4.5f;
                    float circleX = rightPad - circleSize - 1.5f;
                    float circleY = textY + 0.3f;
                    ctx.drawRoundedRect(circleX, circleY, circleSize, circleSize,
                            BorderRadius.all(circleSize / 2), theme.getColor().withAlpha((int) (255 * settingAlpha * animValue)));
                }

                optionY += rowHeight * visibilityAnim;
            }
            return settingY + totalHeight;
        }

        if (setting instanceof KeySetting key) {
            float topPadding = isFirst ? 3 : 0;
            float height = (11 + topPadding) * visibilityAnim;
            ctx.drawText(Fonts.REGULAR.getFont(6), key.getName(), leftPad, settingY + 1 + topPadding,
                    new ColorRGBA(255, 255, 255, (int) (255 * settingAlpha)));

            String keyName = bindingKeySetting == key ? "..." : key.getNameKey();
            ctx.drawText(Fonts.REGULAR.getFont(6), keyName, rightPad - Fonts.REGULAR.getWidth(keyName, 6), settingY + 1 + topPadding,
                    new ColorRGBA(255, 255, 255, (int) (255 * settingAlpha)));
            return settingY + height;
        }

        if (setting instanceof ColorSetting color) {
            float height = 11 * visibilityAnim;
            ctx.drawText(Fonts.REGULAR.getFont(6), color.getName(), leftPad, settingY + 1,
                    new ColorRGBA(255, 255, 255, (int) (255 * settingAlpha)));

            ctx.drawRoundedRect(rightPad - 14, settingY, 12, 8,
                    BorderRadius.all(2), color.getColor().withAlpha((int) (255 * settingAlpha)));
            return settingY + height;
        }

        return settingY + 11 * visibilityAnim;
    }

    private float calculateSettingsHeight(Module module) {
        float h = 0;
        for (Setting setting : module.getSettings()) {
            if (!setting.isVisible()) {
                continue;
            }
            if (setting instanceof BooleanSetting) {
                h += 12;
            } else if (setting instanceof NumberSetting) {
                h += 19;
            } else if (setting instanceof ModeSetting mode) {
                float rowHeight = 10;
                float boxHeight = Math.max(22, mode.getValues().size() * rowHeight + 8);
                h += (12 + boxHeight + 5);
            } else if (setting instanceof MultiBooleanSetting multi) {
                float rowHeight = 10;
                float boxHeight = multi.getBooleanSettings().size() * rowHeight + 8;
                h += (14 + boxHeight + 5);
            } else {
                h += 11;
            }
        }
        return h + 2;
    }

    private static String formatNumber(NumberSetting number) {
        float inc = number.getIncrement();
        int scale = 0;
        if (inc > 0) {
            int key = Float.floatToIntBits(inc);
            scale = INCREMENT_SCALES.computeIfAbsent(key, k -> {
                try {
                    return Math.max(0, BigDecimal.valueOf((double)inc).stripTrailingZeros().scale());
                } catch (Exception e) {
                    return 0;
                }
            });
        }

        int fmtScale = Math.min(scale, MAX_DECIMALS);

        DecimalFormat fmt = NUMBER_FORMATS.computeIfAbsent(fmtScale, sc -> {
            DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
            StringBuilder pattern = new StringBuilder("0");
            if (sc > 0) {
                pattern.append('.');
                pattern.append("0".repeat(sc));
            }
            DecimalFormat df = new DecimalFormat(pattern.toString(), symbols);
            df.setGroupingUsed(false);
            return df;
        });

        return fmt.format(number.getCurrent());
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!MathUtil.isHovered(mouseX, mouseY, x, y, width, panelHeight)) {
            return false;
        }

        updateSearchCache();

        if (button == 0 && MathUtil.isHovered(mouseX, mouseY, x, y, width, 26)) {
            dragging = true;
            dragOffsetX = (float) mouseX - x;
            dragOffsetY = (float) mouseY - y;
            return true;
        }

        for (ModuleEntry entry : filteredModules) {
            if (MathUtil.isHovered(mouseX, mouseY, entry.moduleX, entry.y, entry.moduleWidth, 18)) {
                if (button == 0) {
                    entry.module.toggle();
                    return true;
                }
                if (button == 1 && !entry.module.getSettings().isEmpty()) {
                    entry.expanded = !entry.expanded;
                    return true;
                }
                if (button == 2) {
                    bindingModule = entry.module;
                    return true;
                }
            }

            if (entry.expanded) {
                float settingY = entry.y + 18 - 2;
                boolean isFirst = true;
                for (Setting setting : entry.module.getSettings()) {
                    setting.getAnimationAlpha().update(setting.isVisible());
                    float visValue = setting.getAnimationAlpha().getValue();

                    if (visValue < 0.01f) {
                        continue;
                    }

                    float leftPad = entry.moduleX + 5;
                    float rightPad = entry.moduleX + entry.moduleWidth - 5;
                    float settingWidth = entry.moduleWidth - 10;

                    if (setting instanceof BooleanSetting bool) {
                        float topPadding = isFirst ? 3 : 0;
                        float height = (12 + topPadding) * visValue;
                        if (MathUtil.isHovered(mouseX, mouseY, leftPad, settingY + topPadding - 1, settingWidth, 12)) {
                            bool.setEnabled(!bool.isEnabled());
                            return true;
                        }
                        settingY += height;
                    } else if (setting instanceof NumberSetting number) {
                        float height = 19 * visValue;
                        if (MathUtil.isHovered(mouseX, mouseY, leftPad - 3, settingY - 1, settingWidth + 6, 17)) {
                            draggingSlider = number;
                            draggingSliderLeft = leftPad;
                            draggingSliderWidth = settingWidth;
                            updateSliderWithBounds(mouseX, number, leftPad, settingWidth);
                            return true;
                        }
                        settingY += height;
                    } else if (setting instanceof ModeSetting mode) {
                        float rowHeight = 10;
                        float boxHeight = Math.max(22, mode.getValues().size() * rowHeight + 8);
                        float totalHeight = (12 + boxHeight + 5) * visValue;
                        float boxY = settingY + 12 * visValue;
                        float optionY = boxY + 4 * visValue;
                        for (ModeSetting.Value val : mode.getValues()) {
                            if (MathUtil.isHovered(mouseX, mouseY, leftPad - 2, optionY, settingWidth + 4, rowHeight * visValue)) {
                                val.select();
                                return true;
                            }
                            optionY += rowHeight * visValue;
                        }
                        settingY += totalHeight;
                    } else if (setting instanceof MultiBooleanSetting multi) {
                        float rowHeight = 10;
                        float boxHeight = multi.getBooleanSettings().size() * rowHeight + 8;
                        float totalHeight = (14 + boxHeight + 5) * visValue;
                        float boxY = settingY + 14 * visValue;
                        float optionY = boxY + 4 * visValue;
                        for (MultiBooleanSetting.Value val : multi.getBooleanSettings()) {
                            if (MathUtil.isHovered(mouseX, mouseY, leftPad - 2, optionY, settingWidth + 4, rowHeight * visValue)) {
                                if (button == 0) {
                                    val.toggle();
                                }
                                return true;
                            }
                            optionY += rowHeight * visValue;
                        }
                        settingY += totalHeight;
                    } else if (setting instanceof KeySetting key) {
                        float topPadding = isFirst ? 3 : 0;
                        float height = (11 + topPadding) * visValue;
                        if (MathUtil.isHovered(mouseX, mouseY, leftPad, settingY + topPadding, settingWidth, 11)) {
                            bindingKeySetting = key;
                            return true;
                        }
                        settingY += height;
                    } else {
                        float height = 11 * visValue;
                        settingY += height;
                    }
                    isFirst = false;
                }
            }
        }

        return false;
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        draggingSlider = null;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (MathUtil.isHovered(mouseX, mouseY, x, y, width, panelHeight)) {
            needToScroll += (float) (delta * 15);
            needToScroll = MathHelper.clamp(needToScroll, Math.min(-maxScroll, 0), 0);
            return true;
        }
        return false;
    }

    public boolean keyPressed(int keyCode) {
        if (bindingModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) {
                bindingModule.setKeyCode(-1);
            } else {
                bindingModule.setKeyCode(keyCode);
            }
            bindingModule = null;
            return true;
        }

        if (bindingKeySetting != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) {
                bindingKeySetting.setKeyCode(-1);
            } else {
                bindingKeySetting.setKeyCode(keyCode);
            }
            bindingKeySetting = null;
            return true;
        }

        return false;
    }

    public boolean handleMouseBinding(int button) {
        if (bindingKeySetting != null) {
            bindingKeySetting.setKeyCode(button);
            bindingKeySetting = null;
            return true;
        }

        if (bindingModule != null) {
            bindingModule.setKeyCode(button);
            bindingModule = null;
            return true;
        }

        return false;
    }

    private void updateSlider(double mouseX, NumberSetting number) {
        if (draggingSliderWidth <= 0) {
            return;
        }
        updateSliderWithBounds(mouseX, number, draggingSliderLeft, draggingSliderWidth);
    }

    private void updateSliderWithBounds(double mouseX, NumberSetting number, float leftPad, float sliderWidth) {
        float progress = (float) ((mouseX - leftPad) / sliderWidth);
        progress = MathHelper.clamp(progress, 0, 1);
        float value = number.getMin() + progress * (number.getMax() - number.getMin());

        float inc = number.getIncrement();
        if (inc > 0) {
            value = Math.round(value / inc) * inc;
        }
        number.setCurrent(value);
    }

    private static class ModuleEntry {
        final Module module;
        final String nameLower;
        final Animation expandAnimation = new Animation(350, Easing.CUBIC_OUT);
        final Animation arrowAnimation = new Animation(350, Easing.CUBIC_OUT);
        final Animation closedArrowAlpha = new Animation(1, Easing.CUBIC_IN_OUT);
        final Animation openedArrowAlpha = new Animation(1, Easing.CUBIC_IN_OUT);
        final Animation enableAnimation = new Animation(350, Easing.CUBIC_OUT);

        boolean expanded = false;

        float y;
        float height;
        float moduleX;
        float moduleWidth;

        ModuleEntry(Module module) {
            this.module = module;
            this.nameLower = module.getName() == null ? "" : module.getName().toLowerCase(Locale.ROOT);
        }
    }
}