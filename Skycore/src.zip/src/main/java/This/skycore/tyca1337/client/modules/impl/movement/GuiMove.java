package This.skycore.tyca1337.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.lang.reflect.Field;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.screen.ingame.SignEditScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import This.skycore.base.events.impl.other.EventCloseScreen;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.util.game.player.MovingUtil;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.math.Timer;

@ModuleAnnotation(
        name = "Gui Move",
        category = Category.MOVEMENT,
        description = "Можно ходить с открытым инвентарем"
)
public final class GuiMove extends Module implements IMinecraft {

    public static final GuiMove INSTANCE = new GuiMove();

    private final Queue<ClickSlotC2SPacket> packetQueue = new ConcurrentLinkedQueue<>();
    private final BooleanSetting stopBypass = new BooleanSetting("Обход кликов/свапов", false);
    private final Timer wait = new Timer();
    private int movementPauseTicks;
    private volatile boolean flushingPackets;
    private volatile boolean flushScheduled;
    private boolean resyncKeysNextTick;
    public boolean slow;

    private GuiMove() {
    }


    public static void stopMovementTemporarily(float seconds) {
        GuiMove g = INSTANCE;
        if (!g.isEnabled()) {
            return;
        }
        int ticks = Math.max(1, (int) Math.ceil(seconds * 20.0f));
        g.movementPauseTicks = Math.max(g.movementPauseTicks, ticks);
    }

    @Override
    public void onDisable() {
        this.packetQueue.clear();
        this.resetGuiMoveKeys();
        super.onDisable();
    }

    @EventTarget
    private void onUpdate(EventUpdate e) {
        if (mc.player == null) {
            return;
        }
        boolean allowInCurrentScreen = this.isAllowedGuiScreen();
        if (this.movementPauseTicks > 0) {
            this.movementPauseTicks--;
            // Стоп должен ощущаться и после закрытия GUI (когда currentScreen == null),
            // поэтому гасим движение всегда во время паузы.
            this.resetGuiMoveKeys();
            if (this.movementPauseTicks == 0) {
                // На следующем тике заново подхватим зажатые кнопки (без ожидания отпускания W).
                this.resyncKeysNextTick = true;
            }
            return;
        }
        if (this.resyncKeysNextTick) {
            this.resyncKeysNextTick = false;
            this.syncMovementKeysFromKeyboard();
        }
        if (!this.wait.finished(51L)) {
            if (allowInCurrentScreen) {
                this.resetGuiMoveKeys();
            }
            return;
        }
        if (!allowInCurrentScreen) {
            return;
        }
        this.syncMovementKeysFromKeyboard();
    }

    private boolean isAllowedGuiScreen() {
        if (mc.currentScreen == null || mc.player == null) {
            return false;
        }
        if (mc.player.isGliding()) {
            return false;
        }
        return !(mc.currentScreen instanceof ChatScreen
                || mc.currentScreen instanceof SignEditScreen
                || mc.currentScreen instanceof AnvilScreen);
    }

    private void syncMovementKeysFromKeyboard() {
        KeyBinding[] keys = new KeyBinding[]{
                mc.options.forwardKey,
                mc.options.backKey,
                mc.options.leftKey,
                mc.options.rightKey,
                mc.options.jumpKey,
                mc.options.sprintKey
        };
        long handle = mc.getWindow().getHandle();
        for (KeyBinding key : keys) {
            int code = this.getBoundKeyCodeCompat(key);
            key.setPressed(InputUtil.isKeyPressed(handle, code));
        }
    }

    private int getBoundKeyCodeCompat(KeyBinding key) {
        // В разных маппингах 1.21.x имя метода/поля может отличаться (а getBoundKey() может отсутствовать).
        // Поэтому достаем текущую забинженную кнопку через reflection и фоллбэчимся на defaultKey.
        try {
            // Частые варианты названий полей в разных маппингах
            Field f;
            try {
                f = KeyBinding.class.getDeclaredField("boundKey");
            } catch (NoSuchFieldException ignored) {
                try {
                    f = KeyBinding.class.getDeclaredField("key");
                } catch (NoSuchFieldException ignored2) {
                    f = KeyBinding.class.getDeclaredField("field_1655");
                }
            }
            f.setAccessible(true);
            Object v = f.get(key);
            if (v instanceof InputUtil.Key k) {
                return k.getCode();
            }
        } catch (Throwable ignored) {
        }
        return key.getDefaultKey().getCode();
    }

    private void resetGuiMoveKeys() {
        if (mc == null || mc.options == null) return;
        KeyBinding[] keys = new KeyBinding[]{
                mc.options.forwardKey,
                mc.options.backKey,
                mc.options.leftKey,
                mc.options.rightKey,
                mc.options.jumpKey,
                mc.options.sprintKey
        };
        for (KeyBinding key : keys) {
            key.setPressed(false);
        }
    }

    @EventTarget
    private void onPacket(EventPacket e) {
        if (mc.player == null) {
            return;
        }
        if (!e.isSent() || !(e.getPacket() instanceof ClickSlotC2SPacket packet) || flushingPackets) {
            return;
        }
        if (!(mc.currentScreen instanceof InventoryScreen)) {
            return;
        }
        if (!MovingUtil.hasPlayerMovement()) {
            return;
        }
        this.packetQueue.offer(packet);
        e.setCancelled(true);
    }

    @EventTarget
    private void onCloseScreen(EventCloseScreen e) {
        if (mc.player == null) {
            return;
        }
        if (!(e.getScreen() instanceof InventoryScreen)) {
            return;
        }
        if (!MovingUtil.hasPlayerMovement()) {
            return;
        }
        if (this.packetQueue.isEmpty()) {
            return;
        }

        // Логика "как там": накапливаем клики/свапы пока инвентарь открыт,
        // а при закрытии делаем 1 стоп и досылаем всё пачкой.
        e.setCancelled(true);
        if (this.flushingPackets || this.flushScheduled) {
            return;
        }
        this.flushScheduled = true;
        this.slow = true;
        this.wait.reset();
        // Стоп всегда (как в 3 проекте), без зависимости от чекбокса.
        this.movementPauseTicks = Math.max(this.movementPauseTicks, 2);
        new Thread(() -> {
            try {
                Thread.sleep(51L);
            } catch (InterruptedException ignored) {
            }
            this.flushingPackets = true;
            try {
                ClickSlotC2SPacket p;
                while ((p = this.packetQueue.poll()) != null) {
                    if (mc.getNetworkHandler() != null) {
                        mc.getNetworkHandler().sendPacket(p);
                    }
                }
                if (mc.player != null) {
                    mc.player.closeHandledScreen();
                }
            } finally {
                this.flushingPackets = false;
                this.flushScheduled = false;
                this.slow = false;
            }
        }, "GuiMoveCloseFlush").start();
    }
}
