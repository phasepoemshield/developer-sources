package This.skycore.tyca1337.helpers;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import This.skycore.base.events.impl.player.EventMoveInput;
import This.skycore.util.interfaces.IMinecraft;

public final class MoveUtil implements IMinecraft {

    private MoveUtil() {
    }

    public static double direction(float rotationYaw, final double moveForward, final double moveStrafing) {
        if (moveForward < 0.0D) {
            rotationYaw += 180.0F;
        }

        float forward = 1.0F;
        if (moveForward < 0.0D) {
            forward = -0.5F;
        } else if (moveForward > 0.0D) {
            forward = 0.5F;
        }

        if (moveStrafing > 0.0D) {
            rotationYaw -= 90.0F * forward;
        }
        if (moveStrafing < 0.0D) {
            rotationYaw += 90.0F * forward;
        }

        return Math.toRadians(rotationYaw);
    }

    public static void fixMovement(EventMoveInput event, float yaw) {
        float forward = event.getForward();
        float strafe = event.getStrafe();
        double angle = MathHelper.wrapDegrees(Math.toDegrees(direction(mc.player.isGliding() ? mc.player.getYaw() : yaw, forward, strafe)));

        if (forward == 0.0F && strafe == 0.0F) {
            return;
        }

        float closestForward = 0.0F;
        float closestStrafe = 0.0F;
        float closestDifference = Float.MAX_VALUE;

        for (float predictedForward = -1.0F; predictedForward <= 1.0F; predictedForward += 1.0F) {
            for (float predictedStrafe = -1.0F; predictedStrafe <= 1.0F; predictedStrafe += 1.0F) {
                if (predictedStrafe == 0.0F && predictedForward == 0.0F) {
                    continue;
                }

                double predictedAngle = MathHelper.wrapDegrees(Math.toDegrees(direction(mc.player.getYaw(), predictedForward, predictedStrafe)));
                double difference = Math.abs(angle - predictedAngle);

                if (difference < closestDifference) {
                    closestDifference = (float)difference;
                    closestForward = predictedForward;
                    closestStrafe = predictedStrafe;
                }
            }
        }

        event.setForward(closestForward);
        event.setStrafe(closestStrafe);
    }

    public static void moveToPosition(EventMoveInput event, Vec3d position, float currentYaw) {
        double deltaX = position.x - mc.player.getX();
        double deltaZ = position.z - mc.player.getZ();
        double angleToTarget = Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0D;
        angleToTarget = MathHelper.wrapDegrees(angleToTarget);

        float bestForward = 0.0F;
        float bestStrafe = 0.0F;
        float minDifference = Float.MAX_VALUE;

        for (float forward = -1.0F; forward <= 1.0F; forward += 1.0F) {
            for (float strafe = -1.0F; strafe <= 1.0F; strafe += 1.0F) {
                if (forward == 0.0F && strafe == 0.0F) {
                    continue;
                }

                double moveAngle = Math.toDegrees(direction(currentYaw, forward, strafe));
                double difference = Math.abs(angleToTarget - MathHelper.wrapDegrees(moveAngle));

                if (difference < minDifference) {
                    minDifference = (float)difference;
                    bestForward = forward;
                    bestStrafe = strafe;
                }
            }
        }

        event.setForward(bestForward);
        event.setStrafe(bestStrafe);
    }
}
