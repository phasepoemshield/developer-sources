package This.skycore.tyca1337.client.modules.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(
        name = "BabyMod",
        category = Category.RENDER,
        description = "Уменьшает модель и ник локального игрока"
)
public final class BabyMod extends Module {

    public static final BabyMod INSTANCE = new BabyMod();
    // Slightly larger scale to keep head proportions close to normal.
    public static final float MODEL_SCALE = 0.85F;

    private BabyMod() {
    }

    public static boolean isActiveForLocalPlayer() {
        try {
            return INSTANCE.isEnabled() && MinecraftClient.getInstance().player != null;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean useScaledNametag(Entity entityIn) {
        return entityIn != null && entityIn == MinecraftClient.getInstance().player && isActiveForLocalPlayer();
    }

    public static boolean shouldApplyModel() {
        return isActiveForLocalPlayer();
    }
}
