package This.skycore.tyca1337.client.modules.impl.movement;

import net.minecraft.entity.LivingEntity;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.util.math.Timer;

@ModuleAnnotation(
        name = "ElytraPredict",
        description = "Перегон цели на элитрах",
        category = Category.MOVEMENT
)
public final class ElytraPredict extends Module {

    public static final ElytraPredict INSTANCE = new ElytraPredict();

    /**
     * Насколько далеко вперед по скорости цели мы будем считать предикт.
     */
    private final NumberSetting distance = new NumberSetting(
            "Дистанция обгона",
            3.0F,
            0.0F,
            4.25F,
            0.05F
    );

    private final Timer timer = new Timer();
    private boolean disabled = false;

    private ElytraPredict() {
    }

    /**
     * Значение, используемое для предикта при HVH на элитрах.
     */
    public double getElytraDistance(LivingEntity target) {
        return distance.getCurrent();
    }

    /**
     * Ограничитель, чтобы не предиктить сразу после получения урона.
     */
    public boolean canPredict(LivingEntity target) {
        if (mc.player == null) {
            return false;
        }

        if (mc.player.hurtTime > 0) {
            disabled = true;
            timer.reset();
        }

        if (disabled && timer.finished(500L)) {
            disabled = false;
        }

        return !disabled;
    }
}

