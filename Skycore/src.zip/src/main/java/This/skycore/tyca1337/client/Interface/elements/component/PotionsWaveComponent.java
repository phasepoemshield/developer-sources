package This.skycore.tyca1337.client.Interface.elements.component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.tyca1337.client.modules.impl.render.Hud2;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;

public class PotionsWaveComponent extends DraggableHudElement {
    private final Animation widthAnimation;
    private final Animation heightAnimation;
    private final List<PotionItem> potionItems;
    private float maxTextWidth = 0.0F;

    private static final float ITEM_HEIGHT = 11.0F;
    private static final float HEADER_HEIGHT = 15.0F;
    private static final float PADDING = 4.0F;
    private static final float MIN_WIDTH = 60.0F;

    public PotionsWaveComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
        this.widthAnimation = new Animation(300L, Easing.CUBIC_OUT);
        this.heightAnimation = new Animation(200L, Easing.CUBIC_OUT);
        this.potionItems = new CopyOnWriteArrayList<>();
    }

    @Native
    public void render(CustomDrawContext ctx) {
        if (mc.player == null) return;

        this.updatePotions();
        float posX = this.getX();
        float posY = this.getY();

        // Вычисляем максимальную ширину текста
        maxTextWidth = Fonts.REGULAR.getFont(7.0F).width("potions");
        for (PotionItem item : potionItems) {
            if (item.animation.getValue() > 0.01F) {
                String effectName = item.name.toLowerCase();
                if (effectName.length() > 10) {
                    effectName = effectName.substring(0, 8) + "..";
                }
                String amplifier = item.amplifier > 0 ? " > " + getRomanNumeral(item.amplifier + 1) : " > I";
                String time = formatTime(item.duration);
                float textWidth = Fonts.REGULAR.getFont(6.0F).width(effectName + amplifier + " " + time);
                if (textWidth > maxTextWidth) {
                    maxTextWidth = textWidth;
                }
            }
        }

        float targetWidth = Math.max(MIN_WIDTH, maxTextWidth + PADDING * 2);
        widthAnimation.update(1.0F);
        float currentWidth = targetWidth * widthAnimation.getValue();

        int visibleCount = 0;
        for (PotionItem item : potionItems) {
            if (item.animation.getValue() > 0.01F) {
                visibleCount++;
            }
        }

        boolean shouldShow = visibleCount > 0 || mc.currentScreen instanceof ChatScreen;

        if (!shouldShow && heightAnimation.getValue() <= 0.01F) {
            this.width = currentWidth;
            this.height = HEADER_HEIGHT;
            return;
        }

        heightAnimation.update(shouldShow ? 1.0F : 0.0F);

        float currentHeight = HEADER_HEIGHT + (visibleCount * ITEM_HEIGHT * heightAnimation.getValue());

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();

        ColorRGBA background = Hud2.INSTANCE.getBackgroundColor();

        DrawUtil.drawRect(ctx.getMatrices(), posX, posY, currentWidth, currentHeight, background);

        float topLineHeight = 1.5F;
        for (float i = 0; i < currentWidth; i++) {
            float hue = (float)(System.currentTimeMillis() % 6000L) / 6000.0F + (i / currentWidth);
            if (hue > 1.0F) hue -= 1.0F;
            int rainbowColor = java.awt.Color.HSBtoRGB(hue, 0.6F, 1.0F);
            ColorRGBA rainbowRGBA = new ColorRGBA(
                (rainbowColor >> 16) & 0xFF,
                (rainbowColor >> 8) & 0xFF,
                rainbowColor & 0xFF,
                255
            );
            DrawUtil.drawRect(ctx.getMatrices(), posX + i, posY, 1.0F, topLineHeight, rainbowRGBA);
        }

        float titleY = posY + 4.0F;
        float alpha = widthAnimation.getValue();
        ctx.drawText(Fonts.REGULAR.getFont(7.0F), "potions", posX + PADDING, titleY, ColorRGBA.WHITE.withAlpha(alpha * 255.0F));

        float lineY = posY + HEADER_HEIGHT - 1.5F;
        float lineHeight = 1.5F;
        for (float i = 0; i < currentWidth; i++) {
            float hue = (float)(System.currentTimeMillis() % 6000L) / 6000.0F + (i / currentWidth);
            if (hue > 1.0F) hue -= 1.0F;
            int rainbowColor = java.awt.Color.HSBtoRGB(hue, 0.6F, 1.0F);
            ColorRGBA rainbowRGBA = new ColorRGBA(
                (rainbowColor >> 16) & 0xFF,
                (rainbowColor >> 8) & 0xFF,
                rainbowColor & 0xFF,
                255
            );
            DrawUtil.drawRect(ctx.getMatrices(), posX + i, lineY, 1.0F, lineHeight, rainbowRGBA);
        }

        // Список эффектов (меньше отступ)
        float itemY = posY + HEADER_HEIGHT;
        for (PotionItem item : potionItems) {
            if (item.animation.getValue() > 0.01F) {
                float itemAlpha = item.animation.getValue() * alpha;

                String effectName = item.name.toLowerCase();
                if (effectName.length() > 10) {
                    effectName = effectName.substring(0, 8) + "..";
                }
                String amplifier = item.amplifier > 0 ? " > " + getRomanNumeral(item.amplifier + 1) : " > I";
                String time = formatTime(item.duration);

                ctx.drawText(Fonts.REGULAR.getFont(6.0F), effectName + amplifier, posX + PADDING, itemY + 1.5F,
                    ColorRGBA.WHITE.withAlpha(itemAlpha * 255.0F));

                float timeWidth = Fonts.REGULAR.getFont(6.0F).width(time);
                ctx.drawText(Fonts.REGULAR.getFont(6.0F), time, posX + currentWidth - PADDING - timeWidth, itemY + 1.5F,
                    ColorRGBA.WHITE.withAlpha(itemAlpha * 255.0F));

                itemY += ITEM_HEIGHT * item.animation.getValue();
            }
        }

        this.width = currentWidth;
        this.height = currentHeight;
    }

    private void updatePotions() {
        if (mc.player == null) return;

        Map<RegistryEntry<StatusEffect>, StatusEffectInstance> effects = mc.player.getActiveStatusEffects();

        // Удаляем неактивные эффекты
        potionItems.removeIf(item -> {
            boolean exists = false;
            for (Map.Entry<RegistryEntry<StatusEffect>, StatusEffectInstance> entry : effects.entrySet()) {
                StatusEffect effect = entry.getKey().value();
                if (Registries.STATUS_EFFECT.getId(effect).toString().equals(item.id)) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                item.animation.update(0.0F);
                return item.animation.getValue() <= 0.01F;
            }
            return false;
        });

        // Добавляем новые эффекты
        for (Map.Entry<RegistryEntry<StatusEffect>, StatusEffectInstance> entry : effects.entrySet()) {
            StatusEffect effect = entry.getKey().value();
            StatusEffectInstance instance = entry.getValue();
            String effectId = Registries.STATUS_EFFECT.getId(effect).toString();

            boolean exists = false;
            for (PotionItem item : potionItems) {
                if (item.id.equals(effectId)) {
                    exists = true;
                    item.duration = instance.getDuration();
                    item.amplifier = instance.getAmplifier();
                    item.animation.update(1.0F);
                    break;
                }
            }

            if (!exists) {
                String name = I18n.translate(effect.getTranslationKey());
                boolean beneficial = effect.getCategory().name().equals("BENEFICIAL");
                PotionItem newItem = new PotionItem(effectId, name, instance.getDuration(), instance.getAmplifier(), beneficial);
                potionItems.add(newItem);
            }
        }
    }

    private String formatTime(int ticks) {
        int seconds = ticks / 20;
        int minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format("%d:%02d", minutes, seconds);
    }

    private String getRomanNumeral(int number) {
        String[] romanNumerals = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        if (number > 0 && number <= 10) {
            return romanNumerals[number - 1];
        }
        return String.valueOf(number);
    }

    private static class PotionItem {
        String id;
        String name;
        int duration;
        int amplifier;
        boolean isBeneficial;
        Animation animation;

        PotionItem(String id, String name, int duration, int amplifier, boolean isBeneficial) {
            this.id = id;
            this.name = name;
            this.duration = duration;
            this.amplifier = amplifier;
            this.isBeneficial = isBeneficial;
            this.animation = new Animation(200L, Easing.CUBIC_OUT);
            this.animation.setValue(0.0F);
        }
    }
}
