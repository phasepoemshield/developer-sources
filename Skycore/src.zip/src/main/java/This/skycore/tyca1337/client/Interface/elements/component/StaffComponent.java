package This.skycore.tyca1337.client.Interface.elements.component;

import com.mojang.authlib.GameProfile;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.GameMode;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import net.minecraft.client.util.DefaultSkinHelper;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;
import This.skycore.util.render.display.shader.DrawUtil;

public class StaffComponent extends DraggableHudElement {

    private static final boolean SHOW_ROW_SKIN = true;
    private final Map<String, StaffComponent.StaffModule> modules = new ConcurrentHashMap<>();
    private static final Pattern VALID_USER_PATTERN = Pattern.compile("^\\w{3,16}$");
    private static final Set<String> STAFF_PREFIX_KEYWORDS = Set.of(
            "developer", "moder", "helper", "admin", "owner",
            "хелпер", "модер", "админ", "kurator", "сотрудник",
            "стажер", "мл.сотрудник", "поддержка", "модератор", "j.moder",
            "curator", "стажёр", "помощник", "staff", "ꔗ", "ꔥ", "ꔡ", "ꔳ"
    );
    private static final Set<String> EXCLUDED_PREFIX_KEYWORDS = Set.of(
            "d.moder", "d.helper", "d.admin"
    );
    private long lastStaffUpdate = 0L;
    private volatile Set<String> currentStaffKeys = new HashSet<>();
    private final Animation widthAnimation;
    private final Animation alpha;
    private volatile boolean isUpdating = false;

    public StaffComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
        this.widthAnimation = new Animation(100L, 90.0F, Easing.LINEAR);
        this.alpha = new Animation(100L, 0.0F, Easing.LINEAR);
    }

    @Native
    public void render(CustomDrawContext ctx) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastStaffUpdate > 100L && mc.getNetworkHandler() != null && !this.isUpdating) {
            this.updateStaffList();
            this.lastStaffUpdate = currentTime;
        }

        this.modules.entrySet().removeIf((entry) -> {
            boolean inSet = this.currentStaffKeys.contains(entry.getKey());
            if (!inSet) {
                entry.getValue().animation.update(0.0F);
            }
            return entry.getValue().isDelete() && !inSet;
        });

        float posX = this.getX();
        float posY = this.getY();

        boolean hasActive = false;
        for (Map.Entry<String, StaffModule> e : this.modules.entrySet()) {
            boolean active = this.currentStaffKeys.contains(e.getKey());
            StaffModule staffModule = e.getValue();
            staffModule.animation.update(active ? 1.0F : 0.0F);
            if (staffModule.animation.getValue() > 0.01F) {
                hasActive = true;
            }
        }

        boolean show = mc.currentScreen instanceof ChatScreen || hasActive;
        this.alpha.update(show ? 1.0F : 0.0F);
        float globalAlpha = this.alpha.getValue();
        if (globalAlpha <= 0.01F) {
            this.width = 90.0F;
            this.height = 25.0F;
            return;
        }

        float totalWidthBase = 180.0F / 2f;
        float paddingX = 12.0F / 2f;
        float paddingY = 15.0F / 2f;
        float gap = 15.0F / 2f;
        float itemGap = 12.0F / 2f;
        float borderRadius = 5.5F;
        float iconSize = 12.0F / 2f;
        float headerGap = 6.0F / 2f;
        float itemHeight = 14.0F / 2f;
        float headSize = 6.0F;
        float headGap = 4.0F;

        float headerTextSize = 6.5F;
        float headerIconSize = 7.0F;
        float rowTextSize = 6.5F;

        List<String> sortedKeys = new ArrayList<>(this.modules.keySet());
        Collections.sort(sortedKeys, String.CASE_INSENSITIVE_ORDER);

        float maxItemWidth = 0.0F;
        float headerHeight = 12.0F + gap;
        float contentHeight = 0.0F;

        for (String key : sortedKeys) {
            StaffModule sm = this.modules.get(key);
            if (sm == null) {
                continue;
            }
            float animVal = sm.animation.getValue();
            if (animVal <= 0.01F) {
                continue;
            }
            float nameWidth = Fonts.REGULAR.getWidth(key, rowTextSize);
            String statusText = sm.status == Status.VANISHED ? "SPEC" : "ACTIVE";
            float statusWidth = Fonts.REGULAR.getWidth(statusText, rowTextSize);
            float rowLeft = SHOW_ROW_SKIN ? headSize + headGap : 0.0F;
            float itemWidth = rowLeft + nameWidth + itemGap + statusWidth;
            maxItemWidth = Math.max(maxItemWidth, itemWidth);
            contentHeight += (itemHeight + itemGap) * animVal;
        }

        float targetWidth = Math.max(totalWidthBase, maxItemWidth + paddingX * 2f);
        float animatedHeight = paddingY + headerHeight + contentHeight + paddingY - 10.0F;

        this.widthAnimation.update(targetWidth);
        float panelWidth = this.widthAnimation.getValue();

        posY = this.adjustRenderYAboveChat(posY, animatedHeight);

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA logoColor = theme.getColor();
        ColorRGBA bgColor = ColorUtil.darkenBrightness(logoColor, 0.1f).mulAlpha(globalAlpha);
        ColorRGBA iconColor = logoColor.mulAlpha(globalAlpha);
        ColorRGBA textColor = ColorRGBA.WHITE.mulAlpha(globalAlpha);
        ColorRGBA statusTint = logoColor.mulAlpha(globalAlpha);

        ctx.drawRoundedRect(posX, posY, panelWidth, animatedHeight, BorderRadius.all(borderRadius), bgColor);

        float currentY = posY + paddingY;
        float headerRowX = posX + paddingX;

        ctx.drawText(Fonts.SKYCORE.getFont(headerIconSize), "d", headerRowX, currentY + 2.9f, iconColor);
        headerRowX += iconSize + headerGap;
        ctx.drawText(Fonts.REGULAR.getFont(headerTextSize), "Personal", headerRowX + 1.0F, currentY + 2.5f, textColor);

        currentY += headerHeight;

        for (String key : sortedKeys) {
            StaffModule entry = this.modules.get(key);
            if (entry == null) {
                continue;
            }
            float animVal = entry.animation.getValue();
            if (animVal <= 0.01F) {
                continue;
            }

            float slideOffset = (1.0F - animVal) * 10.0F;
            float rowX = posX + paddingX;
            float headY = currentY - 3.5f - slideOffset;

            if (SHOW_ROW_SKIN) {
                Identifier skin = this.resolveStaffSkin(key);
                DrawUtil.drawPlayerHeadWithRoundedShader(ctx.getMatrices(), skin, rowX, headY, headSize, BorderRadius.all(headSize / 2f), ColorRGBA.WHITE.mulAlpha(animVal * globalAlpha));
                rowX += headSize + headGap;
            }

            ctx.drawText(Fonts.REGULAR.getFont(rowTextSize), key, rowX, currentY - 2.0F - slideOffset, textColor.mulAlpha(animVal));

            String statusText = entry.status == Status.VANISHED ? "SPEC" : "ACTIVE";
            float statusWidth = Fonts.REGULAR.getWidth(statusText, rowTextSize);
            float statusX = posX + panelWidth - paddingX - statusWidth;
            ctx.drawText(Fonts.REGULAR.getFont(rowTextSize), statusText, statusX + slideOffset, currentY - 2.0F - slideOffset, statusTint.mulAlpha(animVal));

            currentY += (itemHeight + itemGap) * animVal;
        }

        this.width = panelWidth;
        this.height = animatedHeight;
    }

    private Identifier resolveStaffSkin(String name) {
        if (mc.getNetworkHandler() != null) {
            for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
                if (e.getProfile() != null && name.equalsIgnoreCase(e.getProfile().getName())) {
                    return e.getSkinTextures().texture();
                }
            }
        }
        return DefaultSkinHelper.getSteve().texture();
    }

    private void updateStaffList() {
        if (mc.getNetworkHandler() == null) return;

        isUpdating = true;
        try {
            Set<String> newKeys = new HashSet<>();

            Set<String> onlinePlayers = getOnlinePlayers();
            List<StaffMember> allStaff = new ArrayList<>();

            // 1. Собираем стафф из таблиста (онлайн игроки)
            allStaff.addAll(getOnlineStaff());

            // 2. Собираем ваниш стафф из скорборда
            allStaff.addAll(getVanishedStaff(onlinePlayers));

            // 3. Собираем игроков из StaffManager которые онлайн но не были найдены выше
            Set<String> alreadyFound = new HashSet<>();
            for (StaffMember s : allStaff) {
                alreadyFound.add(s.name);
            }
            allStaff.addAll(getStaffManagerOnline(onlinePlayers, alreadyFound));

            // Дедупликация — приоритет последнему (vanish перезаписывает online если дубль)
            Map<String, StaffMember> result = new LinkedHashMap<>();
            for (StaffMember staff : allStaff) {
                result.put(staff.name, staff);
            }

            for (StaffMember staff : result.values()) {
                String key = staff.name;
                newKeys.add(key);

                StaffModule existingModule = this.modules.get(key);

                if (existingModule == null) {
                    StaffModule newModule = new StaffModule(staff.name, staff.prefix, staff.status);
                    this.modules.put(key, newModule);
                } else if (existingModule.status != staff.status || !Objects.equals(existingModule.prefix, staff.prefix)) {
                    StaffModule newModule = new StaffModule(staff.name, staff.prefix, staff.status);
                    float currentValue = existingModule.animation.getValue();
                    if (currentValue > 0.01F) {
                        newModule.animation.update(1.0F);
                    }
                    this.modules.put(key, newModule);
                }
            }

            this.currentStaffKeys = newKeys;
        } finally {
            isUpdating = false;
        }
    }

    private Set<String> getOnlinePlayers() {
        if (mc.getNetworkHandler() == null) return Collections.emptySet();
        return mc.getNetworkHandler().getPlayerList().stream()
                .map(PlayerListEntry::getProfile)
                .filter(Objects::nonNull)
                .map(GameProfile::getName)
                .filter(StaffComponent::isValidName)
                .collect(Collectors.toSet());
    }

    private List<StaffMember> getOnlineStaff() {
        if (mc.getNetworkHandler() == null) return Collections.emptyList();
        List<StaffMember> result = new ArrayList<>();

        for (PlayerListEntry info : mc.getNetworkHandler().getPlayerList()) {
            GameProfile profile = info.getProfile();
            if (profile == null) continue;

            String name = profile.getName();
            if (!isValidName(name)) continue;

            Text displayNameText = info.getDisplayName();
            String display = displayNameText != null ? displayNameText.getString() : name;
            String prefix = normalizePrefix(display.replace(name, "").trim());

            // Спектатор = ваниш
            if (info.getGameMode() == GameMode.SPECTATOR) {
                result.add(new StaffMember(name, prefix, Status.VANISHED));
                continue;
            }

            // Проверяем префикс ИЛИ наличие в StaffManager
            if (isStaffPrefix(prefix) || isInStaffManager(name)) {
                result.add(new StaffMember(name, prefix, Status.NONE));
            }
        }

        return result;
    }

    /**
     * Ищет игроков которые есть в StaffManager, онлайн в табе,
     * но не были найдены в getOnlineStaff (например displayName был null
     * в старом коде, или префикс не подошёл).
     */
    private List<StaffMember> getStaffManagerOnline(Set<String> onlinePlayers, Set<String> alreadyFound) {
        if (mc.getNetworkHandler() == null) return Collections.emptyList();
        List<StaffMember> result = new ArrayList<>();

        for (String playerName : onlinePlayers) {
            if (alreadyFound.contains(playerName)) continue;
            if (!isInStaffManager(playerName)) continue;

            // Игрок есть в StaffManager и онлайн, но не был найден ранее
            // Попробуем достать его префикс из таба
            String prefix = "";
            for (PlayerListEntry info : mc.getNetworkHandler().getPlayerList()) {
                GameProfile profile = info.getProfile();
                if (profile == null) continue;
                if (!playerName.equals(profile.getName())) continue;

                Text displayNameText = info.getDisplayName();
                if (displayNameText != null) {
                    prefix = normalizePrefix(displayNameText.getString().replace(playerName, "").trim());
                }
                break;
            }

            result.add(new StaffMember(playerName, prefix, Status.NONE));
        }

        return result;
    }

    private List<StaffMember> getVanishedStaff(Set<String> onlinePlayers) {
        if (mc.world == null) return Collections.emptyList();
        List<StaffMember> result = new ArrayList<>();

        for (Team team : mc.world.getScoreboard().getTeams()) {
            for (String name : team.getPlayerList()) {
                if (!isValidName(name) || onlinePlayers.contains(name)) continue;

                Text prefixComponent = team.getPrefix();
                if (prefixComponent == null) continue;

                String prefix = normalizePrefix(prefixComponent.getString());

                if (isStaffPrefix(prefix) || isInStaffManager(name)) {
                    String teamDisplayName = team.getDisplayName().getString().trim();
                    if (teamDisplayName.toLowerCase().startsWith("cit-")) continue;
                    if (teamDisplayName.startsWith("модер") || teamDisplayName.startsWith("FS_") ||
                            teamDisplayName.startsWith("npc") || (!name.trim().contains(teamDisplayName) &&
                            teamDisplayName.startsWith("J") && teamDisplayName.endsWith("A"))) continue;

                    result.add(new StaffMember(name, prefix, Status.VANISHED));
                }
            }
        }

        return result;
    }

    private String normalizePrefix(String prefix) {
        if (prefix == null) return "";

        return prefix.replaceAll("ꔗ", Formatting.BLUE + "MODER")
                .replaceAll("ꔥ", Formatting.BLUE + "ST.MODER")
                .replaceAll("ꔡ", Formatting.LIGHT_PURPLE + "MODER+")
                .replaceAll("ꔀ", Formatting.GRAY + "PLAYER")
                .replaceAll("ꔉ", Formatting.YELLOW + "HELPER")
                .replaceAll("◆", "@")
                .replaceAll("┃", "|")
                .replaceAll("ꔳ", Formatting.AQUA + "ML.ADMIN")
                .replaceAll("ꔅ", Formatting.RED + "Y" + Formatting.WHITE + "T")
                .replaceAll("ꔂ", Formatting.BLUE + "D.MODER")
                .replaceAll("ꕠ", Formatting.YELLOW + "D.HELPER")
                .replaceAll("ꕄ", Formatting.RED + "DRACULA")
                .replaceAll("ꔖ", Formatting.AQUA + "OVERLORD")
                .replaceAll("ꕈ", Formatting.GREEN + "COBRA")
                .replaceAll("ꔨ", Formatting.LIGHT_PURPLE + "DRAGON")
                .replaceAll("ꔤ", Formatting.RED + "IMPERATOR")
                .replaceAll("ꔠ", Formatting.GOLD + "MAGISTER")
                .replaceAll("ꔄ", Formatting.BLUE + "HERO")
                .replaceAll("ꔒ", Formatting.GREEN + "AVENGER")
                .replaceAll("ꕒ", Formatting.WHITE + "RABBIT")
                .replaceAll("ꔈ", Formatting.YELLOW + "TITAN")
                .replaceAll("ꕀ", Formatting.DARK_GREEN + "HYDRA")
                .replaceAll("ꔶ", Formatting.GOLD + "TIGER")
                .replaceAll("ꔲ", Formatting.DARK_PURPLE + "BULL")
                .replaceAll("ꕖ", Formatting.BLACK + "BUNNY")
                .replaceAll("ꕗꕘ", Formatting.YELLOW + "SPONSOR")
                .replaceAll("\ud83d\udd25", "@")
                .replaceAll("ᴀ", "A").replaceAll("ʙ", "B").replaceAll("ᴄ", "C")
                .replaceAll("ᴅ", "D").replaceAll("ᴇ", "E").replaceAll("ғ", "F")
                .replaceAll("ɢ", "G").replaceAll("ʜ", "H").replaceAll("ɪ", "I")
                .replaceAll("ᴊ", "J").replaceAll("ᴋ", "K").replaceAll("ʟ", "L")
                .replaceAll("ᴍ", "M").replaceAll("ɴ", "N").replaceAll("ꜱ", "S")
                .replaceAll("ᴏ", "O").replaceAll("ᴘ", "P").replaceAll("ǫ", "Q")
                .replaceAll("ʀ", "R").replaceAll("ᴛ", "T").replaceAll("ᴜ", "U")
                .replaceAll("ᴠ", "V").replaceAll("ᴡ", "W").replaceAll("ꜰ", "F")
                .replaceAll("ʏ", "Y").replaceAll("ᴢ", "Z");
    }

    private boolean isInStaffManager(String name) {
        return SkyCore.getInstance().getStaffManager().isStaff(name);
    }

    private boolean isStaffPrefix(String prefix) {
        if (prefix == null || prefix.length() < 2) return false;

        String normalized = Formatting.strip(prefix).toLowerCase(Locale.ROOT);

        for (String excluded : EXCLUDED_PREFIX_KEYWORDS) {
            if (normalized.contains(excluded)) return false;
        }

        for (String keyword : STAFF_PREFIX_KEYWORDS) {
            if (normalized.contains(keyword)) return true;
        }

        return false;
    }

    private static boolean isValidName(String name) {
        return name != null && !name.isEmpty() && !containsRussianChars(name)
                && (VALID_USER_PATTERN.matcher(name).matches() || name.contains(","));
    }

    private static boolean containsRussianChars(String input) {
        return input != null && input.matches(".*[А-Яа-яЁё].*");
    }

    private static class StaffMember {
        final String name;
        final String prefix;
        final Status status;

        StaffMember(String name, String prefix, Status status) {
            this.name = name;
            this.prefix = prefix;
            this.status = status;
        }
    }

    private class StaffModule {
        private final Animation animation;
        private final String name;
        private final String prefix;
        private final StaffComponent.Status status;

        public StaffModule(String name, String prefix, StaffComponent.Status status) {
            this.animation = new Animation(250L, 0.01F, Easing.CUBIC_OUT);
            this.name = name;
            this.prefix = prefix != null ? prefix : "";
            this.status = status;
        }

        public boolean isDelete() {
            return this.animation.getValue() < 0.01F;
        }
    }

    public enum Status {
        NONE,
        VANISHED;
    }
}