package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.security.SecureRandom;
import java.util.Objects;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SnowBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.AmbientEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.FishEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import This.skycore.SkyCore;
import This.skycore.tyca1337.client.modules.impl.movement.ElytraMotion;
import This.skycore.util.component.ElytraComponent;
import This.skycore.base.events.impl.other.EventGameUpdate;
import This.skycore.base.events.impl.other.EventTick;
import This.skycore.base.events.impl.other.EventTickMovement;
import This.skycore.base.events.impl.player.EventMoveInput;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.player.EventPostUpdate;
import This.skycore.base.player.AttackUtil;
import This.skycore.base.request.ScriptManager;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.NumberSetting;
import This.skycore.tyca1337.client.modules.impl.movement.AutoSprint;
import This.skycore.tyca1337.helpers.AuraUtil;
import This.skycore.tyca1337.helpers.MoveUtil;
import This.skycore.tyca1337.client.modules.impl.movement.Speed;
import This.skycore.util.component.FreeLookComponent;
import This.skycore.util.component.MoveComponent;
import This.skycore.util.component.RotationComponent;
import This.skycore.util.component.SmoothRotationComponent;
import This.skycore.util.game.player.PlayerInventoryUtil;
import This.skycore.util.game.player.RaytracingUtil;
import This.skycore.util.game.player.rotation.Rotation;
import This.skycore.util.game.player.rotation.RotationUtil;
import This.skycore.util.math.MultipointUtils;
import This.skycore.util.math.Timer;
import This.skycore.util.predict.PredictUtils;

@ModuleAnnotation(
        name = "AttackAura",
        category = Category.COMBAT,
        description = "Автоматически бьет цель"
)
public final class Aura extends Module {
    public static final Aura INSTANCE = new Aura();

    private final MultiBooleanSetting targetTypeSetting = MultiBooleanSetting.create("Атаковать", List.of("Игроков", "Мобов", "Животных"));
    public final ModeSetting rotationMode = new ModeSetting("Ротация", new String[0]);

    private final ModeSetting.Value hvh;
    private final ModeSetting.Value matrixVulcan;
    private final ModeSetting.Value lonyJir;
    private final ModeSetting.Value cake;
    private final ModeSetting.Value legendsGrief;
    private final ModeSetting.Value wellMine;
    private final ModeSetting.Value test;
    private ModeSetting.Value droid;
    private final ModeSetting.Value botinokBypass;
    private final ModeSetting.Value lonyBypass;

    private final ModeSetting correctionType;
    private final ModeSetting.Value correctionFree;
    private final ModeSetting.Value correctionFocus;
    private final ModeSetting.Value correctionTarget;

    private final NumberSetting distance;
    private final NumberSetting distanceRotation;
    private final NumberSetting elytraDistanceRotation;
    private final NumberSetting elytraAttackDistance;
    private final BooleanSetting shieldBreak;
    private final BooleanSetting legitSwap;
    private final BooleanSetting raycastCheck;

    public final BooleanSetting smartOvertake = new BooleanSetting("Умный перегон", "Бьет от касания до лимита", true);
    public final NumberSetting predict = new NumberSetting("Лимит перегона", 3.0F, 1.0F, 6.0F, 0.1F, "На сколько блоков перегонять цель");
    public final NumberSetting hitboxExpand = new NumberSetting("Расширение хитбокса", 0.5F, 0.0F, 1.5F, 0.1F);

    public final BooleanSetting onlyCriticals = new BooleanSetting("Только криты", "Бить только при падении (крит)", true);
    public final BooleanSetting smartCrits = new BooleanSetting("Умные криты", "Не бить на земле без прыжка", true);
    public final BooleanSetting critsOnlyWithSpace = new BooleanSetting("Криты с пробелом", false);

    public final BooleanSetting visualTurnBack = new BooleanSetting("Визуальный разворот", "Разворачивает камеру назад при перегоне", true);
    public final NumberSetting visualTurnSpeed = new NumberSetting("Скорость разворота", 15.0F, 5.0F, 45.0F, 1.0F, "Скорость визуального разворота камеры");

    public static LivingEntity target;
    private float acceleration;
    private boolean isBack;
    private final Timer hurtTimer;
    private final Timer attackTimer;
    private final Timer neuroTimer;
    private final ScriptManager.ScriptTask script;
    private int lastSlot;
    public float lastYaw;
    public float lastPitch;
    private float neuroOffset;
    public Vec3d lastPredictedPosition;

    private float currentTargetSpeed = 0.0F;
    private boolean isPredictionActive = false;
    private float overtakeAmount = 0.0F;
    private int ticksInRange = 0;
    private boolean shouldStopOvertake = false;
    private float lastYawDelta = 0.0F;
    private float lastPitchDelta = 0.0F;
    private Vec3d randomOffset = Vec3d.ZERO;

    private final Map<Entity, Vec3d> previousPositions = new HashMap<>();

    private float smoothLerpYaw;
    private float smoothLerpPitch;

    private float visualYawOffset = 0.0F;
    private boolean isVisuallyTurnedBack = false;

    private boolean wasOnGround = false;
    private long timeOnGround = 0;
    private long lastJumpTime = 0;

    private boolean isPostUpdateAttack = false;
    private int legitSprintResetTicks;

    private Aura() {
        this.hvh = new ModeSetting.Value(this.rotationMode, "Smooth");
        this.matrixVulcan = new ModeSetting.Value(this.rotationMode, "Matrix/Vulcan");
        this.lonyJir = (new ModeSetting.Value(this.rotationMode, "LonyOld")).select();
        this.cake = (new ModeSetting.Value(this.rotationMode, "LonyGrief")).select();
        this.legendsGrief = (new ModeSetting.Value(this.rotationMode, "LegendsGrief")).select();
        this.wellMine = new ModeSetting.Value(this.rotationMode, "WellMine");
        this.test = new ModeSetting.Value(this.rotationMode, "Test");
        this.droid = new ModeSetting.Value(this.rotationMode, "LonyGriefPro");
        this.botinokBypass = new ModeSetting.Value(this.rotationMode, "BotinokBypass");
        this.lonyBypass = new ModeSetting.Value(this.rotationMode, "LonyBypass");

        this.correctionType = new ModeSetting("Коррекция движения", new String[0]);
        this.correctionFree = (new ModeSetting.Value(this.correctionType, "Свободная")).select();
        this.correctionFocus = new ModeSetting.Value(this.correctionType, "Сфокусированная");
        this.correctionTarget = new ModeSetting.Value(this.correctionType, "Таргет");

        this.distance = new NumberSetting("Дистанция", 3.0F, 0.5F, 6.0F, 0.1F);
        this.distanceRotation = new NumberSetting("Дистанция аима", 0.1F, 0.0F, 6.0F, 0.1F);
        this.elytraDistanceRotation = new NumberSetting("Дистанция аима на элитрах", 30.0F, 10.0F, 100.0F, 1.0F);
        this.elytraAttackDistance = new NumberSetting("Дистанция атаки на элитре", 5.0F, 3.0F, 10.0F, 0.1F);

        this.shieldBreak = new BooleanSetting("Ломать щит", true);
        BooleanSetting var10005 = this.shieldBreak;
        Objects.requireNonNull(var10005);
        this.legitSwap = new BooleanSetting("Легитно ломать", true, var10005::isEnabled);
        this.raycastCheck = new BooleanSetting("Проверка на наведение", false);

        this.target = null;
        this.hurtTimer = new Timer();
        this.attackTimer = new Timer();
        this.neuroTimer = new Timer();
        this.script = new ScriptManager.ScriptTask();
        this.lastSlot = -1;
        this.neuroOffset = 0.0F;
        this.lastPredictedPosition = null;
    }

    // ========== shouldUsePostUpdate — после sendMovementPackets (криты + PacketCriticals), как в референсе ==========
    private boolean shouldUsePostUpdate() {
        if (mc.player == null) return false;

        PacketCriticals packetCriticals = PacketCriticals.INSTANCE;
        if (packetCriticals == null || !packetCriticals.isEnabled()) return false;

        if (mc.player.isGliding()) return true;

        if (mc.player.hasStatusEffect(StatusEffects.SLOW_FALLING)
                || mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                || this.isPlayerInWeb()) {
            return true;
        }

        return false;
    }

    private boolean isPlayerInWeb() {
        if (mc.player == null || mc.world == null) return false;
        for (double x = -0.31; x <= 0.31; x += 0.31) {
            for (double z = -0.31; z <= 0.31; z += 0.31) {
                for (double y = 0.0; y <= (double) mc.player.getStandingEyeHeight(); y += 0.5) {
                    BlockPos pos = BlockPos.ofFloored(mc.player.getX() + x, mc.player.getY() + y, mc.player.getZ() + z);
                    if (mc.world.getBlockState(pos).isOf(Blocks.COBWEB)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // ========== EventTick — только обновление состояния ==========
    @EventTarget
    public void onTick(EventTick e) {
        if (!this.isEnabled() || mc.player == null || mc.world == null) {
            return;
        }
        this.updateVisualTurnBack();
    }

    // ========== EventUpdate — атака БЕЗ PostUpdate ==========
    @EventTarget
    public void onUpdate(EventUpdate e) {
        if (mc.player == null || mc.world == null) return;

        boolean usePostUpdate = this.shouldUsePostUpdate();

        // Если под плавкой/левитацией/паутиной с PacketCriticals — НЕ атакуем тут
        if (usePostUpdate) {
            return;
        }

        // Обычная атака
        this.isPostUpdateAttack = false;
        this.handleAuraLogic();
    }

    // ========== EventPostUpdate — атака ПОСЛЕ крит-пакетов ==========
    @EventTarget
    public void onPostUpdate(EventPostUpdate e) {
        if (mc.player == null || mc.world == null) return;

        boolean usePostUpdate = this.shouldUsePostUpdate();

        // Атакуем тут ТОЛЬКО если shouldUsePostUpdate
        if (!usePostUpdate) {
            return;
        }

        // Атака после крит-пакетов
        this.isPostUpdateAttack = true;
        this.handleAuraLogic();
        this.isPostUpdateAttack = false;
    }

    // ========== handleAuraLogic — 1-в-1 как в референсе ==========
    private void handleAuraLogic() {
        if (mc.player == null || mc.world == null) return;

        target = this.updateTarget();

        if (target != null) {
            ElytraComponent.updateTarget(target);
            ElytraComponent.smartPredict();
            ElytraComponent.processTargetLogic();
            ElytraComponent.updateDefensiveState(target);
            this.updateState();
            this.updateAttack();
        } else {
            this.releaseRotation();
            this.resetState();
        }
    }

    // ========== updateAttack — 1-в-1 как в референсе ==========
    private void updateAttack() {
        if (target == null) return;

        boolean canAttack = this.canAttackSvin();

        if (canAttack) {
            this.attackTarget();
        }
    }

    // ========== canAttackSvin — 1-в-1 как в референсе ==========
    private boolean canAttackSvin() {
        if (mc.player == null || mc.world == null || target == null) return false;

        // Таймер атаки
        if (!this.attackTimer.finished(500)) return false;

        // Кулдаун
        if (mc.player.getAttackCooldownProgress(0.5f) < 0.93f) return false;

        // Проверка паутины
        boolean headInWeb = false;
        boolean feetInWeb = false;
        boolean inBerryBush = false;

        for (double x = -0.31; x <= 0.31; x += 0.31) {
            for (double z = -0.31; z <= 0.31; z += 0.31) {
                for (double y = (double) mc.player.getStandingEyeHeight(); y >= 0.0; y -= 0.1) {
                    BlockPos headPos = BlockPos.ofFloored(mc.player.getX() + x, mc.player.getY() + y, mc.player.getZ() + z);
                    BlockState state = mc.world.getBlockState(headPos);
                    if (state.isOf(Blocks.COBWEB)) {
                        headInWeb = true;
                        break;
                    }
                    if (state.isOf(Blocks.SWEET_BERRY_BUSH)) {
                        inBerryBush = true;
                        break;
                    }
                }
            }
        }

        if (!headInWeb && !inBerryBush) {
            for (double x = -0.31; x <= 0.31; x += 0.31) {
                for (double z = -0.31; z <= 0.31; z += 0.31) {
                    BlockPos pos = BlockPos.ofFloored(mc.player.getX() + x, mc.player.getY(), mc.player.getZ() + z);
                    BlockState state = mc.world.getBlockState(pos);
                    if (state.isOf(Blocks.COBWEB)) {
                        feetInWeb = true;
                        break;
                    }
                    if (state.isOf(Blocks.SWEET_BERRY_BUSH)) {
                        inBerryBush = true;
                        break;
                    }
                }
            }
        }

        // Проверка снега
        boolean inSnow = false;
        BlockPos feetPos = BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        BlockState feetState = mc.world.getBlockState(feetPos);
        if (feetState.isOf(Blocks.SNOW)) {
            try {
                int snowLayers = feetState.get(SnowBlock.LAYERS);
                if (snowLayers == 2) {
                    inSnow = true;
                }
            } catch (Exception ignored) {}
        }

        // Отслеживание ground
        boolean currentlyOnGround = mc.player.isOnGround();
        if (currentlyOnGround && !this.wasOnGround) {
            this.timeOnGround = System.currentTimeMillis();
        } else if (!currentlyOnGround && this.wasOnGround && mc.options.jumpKey.isPressed()) {
            this.lastJumpTime = System.currentTimeMillis();
        } else if (!currentlyOnGround) {
            this.timeOnGround = 0;
        }
        this.wasOnGround = currentlyOnGround;

        // Блоки над головой
        BlockPos headPosAbove = BlockPos.ofFloored(mc.player.getX(), mc.player.getY() + 1.5, mc.player.getZ());
        BlockPos headPosAbov = BlockPos.ofFloored(mc.player.getX(), mc.player.getY() + 2, mc.player.getZ());
        boolean blockAbove = !mc.world.getBlockState(headPosAbove).isAir();
        boolean blockAbov = !mc.world.getBlockState(headPosAbov).isAir();

        // Люк
        BlockPos blockBelow = BlockPos.ofFloored(mc.player.getX(), mc.player.getY() - 1, mc.player.getZ());
        boolean standingOnTrapdoor = mc.world.getBlockState(blockBelow).getBlock() instanceof TrapdoorBlock;

        // Умные криты
        final boolean onSpace = this.smartCrits.isEnabled()
                && mc.player.isOnGround()
                && !mc.options.jumpKey.isPressed();

        // Дистанция
        if (!this.isDistanceValidForAttack()) return false;

        // Сила атаки
        if (mc.player.getAttackCooldownProgress(0.95f) < 0.95f) return false;

        // Ступеньки
        double yDiff = ((double) ((int) mc.player.getY()) - mc.player.getY());
        boolean bl4 = yDiff == -0.01250004768371582;
        boolean bl5 = yDiff == -0.1875;

        // PacketCriticals
        PacketCriticals packetCriticals = PacketCriticals.INSTANCE;
        boolean packetCriticalsOn = packetCriticals != null && packetCriticals.isEnabled();

        // Под плавкой + PacketCriticals: при подъёме (velocity.y >= 0) атака даёт флаг Grim
        if (packetCriticalsOn && mc.player.hasStatusEffect(StatusEffects.SLOW_FALLING) && mc.player.getVelocity().y >= 0) {
            return false;
        }

        // reasonForAttack — ситуации когда крит невозможен
        boolean reasonForAttack;
        if (!packetCriticalsOn) {
            reasonForAttack = (
                    mc.player.fallDistance > 0
                            || mc.player.isClimbing()
                            || (mc.player.isTouchingWater() && mc.player.isSubmergedIn(FluidTags.WATER))
                            || mc.player.hasVehicle()
                            || (!mc.player.isTouchingWater() && (bl5 || bl4)) && !mc.player.isSneaking()
                            || mc.player.getAbilities().flying
                            || mc.player.isGliding()
                            || mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                            || (mc.player.isInLava() && mc.player.isSubmergedIn(FluidTags.LAVA))
                            || headInWeb
                            || feetInWeb
                            || inSnow
                            || inBerryBush
                            || (standingOnTrapdoor && blockAbove)
            );
        } else {
            reasonForAttack = (
                    mc.player.fallDistance > 0
                            || mc.player.isClimbing()
                            || (mc.player.isTouchingWater() && mc.player.isSubmergedIn(FluidTags.WATER))
                            || mc.player.hasVehicle()
                            || (!mc.player.isTouchingWater() && (bl5 || bl4)) && !mc.player.isSneaking()
                            || mc.player.getAbilities().flying
                            || mc.player.isGliding()
                            || mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                            || mc.player.isInLava()
                            || this.isPlayerInWeb()
                            || inSnow
                            || inBerryBush
                            || (standingOnTrapdoor && blockAbove)
            );
        }

        // В воде с блоком над головой
        if (mc.player.isTouchingWater() && blockAbov) {
            return true;
        }

        // Под блоком
        if (!mc.player.isSneaking() && blockAbove && !mc.player.verticalCollision) {
            return true;
        }

        // Если reasonForAttack — бьём
        if (reasonForAttack) {
            return true;
        }

        // Проверка "Только криты"
        if (!this.onlyCriticals.isEnabled()) {
            return true;
        }

        // Финальная проверка крита
        boolean isFallingMotion = mc.player.getVelocity().y < 0;
        boolean packetCriticalsCheck = !mc.player.isOnGround() && mc.player.fallDistance > 0.2F;

        return isFallingMotion && (onSpace || (!inBerryBush && packetCriticalsCheck));
    }

    // ========== attackTarget — атака ==========
    private void attackTarget() {
        if (target == null) return;
        if (target.isBlocking()) return;

        this.attackTimer.reset();

        if (!this.isPostUpdateAttack && mc.player.isSprinting() && !mc.player.isOnGround() && !mc.player.isSwimming() && !mc.player.isGliding()) {
            if (AutoSprint.INSTANCE.isEnabled()) {
                this.legitSprintResetTicks = 1;
            }
            mc.player.setSprinting(false);
            if (!AutoSprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
        }

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        this.hurtTimer.reset();
    }

    private boolean isDistanceValidForAttack() {
        if (target == null || mc.player == null) return false;

        if (this.isElytraCombat() && this.smartOvertake.isEnabled()) {
            return this.isTouchingTargetHitbox() || this.canHitWithOvertake();
        }

        float attackDistance = mc.player.isGliding() ? this.elytraAttackDistance.getCurrent() : this.distance.getCurrent();
        double dist = mc.player.getEyePos().distanceTo(MultipointUtils.getNearestPoint(target, (double) attackDistance));
        return dist <= (double) attackDistance;
    }

    private float getAimDistance() {
        return mc.player != null && mc.player.isGliding()
                ? (this.distance.getCurrent() + this.elytraDistanceRotation.getCurrent())
                : this.distance.getCurrent();
    }

    private void updateState() {
        if (target == null || mc.player == null) return;

        this.currentTargetSpeed = (float) target.getVelocity().length() * 20.0F;
        this.overtakeAmount = this.calculateOvertake();
        this.shouldStopOvertake = this.shouldStopOvertaking();

        if (this.isTouchingTargetHitbox()) {
            this.ticksInRange++;
        } else {
            this.ticksInRange = 0;
        }
    }

    private void breakShieldAndAttack() {
        boolean wasSwapped = false;
        boolean wasSwappedInventory = false;
        int slotHotbar = PlayerInventoryUtil.find((List) List.of(Items.WOODEN_AXE, Items.STONE_AXE, Items.IRON_AXE, Items.GOLDEN_AXE, Items.DIAMOND_AXE, Items.NETHERITE_AXE), 0, 8);
        int slotInventory = PlayerInventoryUtil.find((List) List.of(Items.WOODEN_AXE, Items.STONE_AXE, Items.IRON_AXE, Items.GOLDEN_AXE, Items.DIAMOND_AXE, Items.NETHERITE_AXE), 8, 35);

        if (slotHotbar != -1 && this.shieldBreak.isEnabled() && target.isBlocking()) {
            if (this.legitSwap.isEnabled()) {
                this.lastSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = slotHotbar;
            } else {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slotHotbar));
            }
            wasSwapped = true;
        }

        if (slotHotbar == -1 && slotInventory != -1 && this.shieldBreak.isEnabled() && target.isBlocking()) {
            if (this.legitSwap.isEnabled()) {
                mc.interactionManager.clickSlot(0, slotInventory, 8, SlotActionType.SWAP, mc.player);
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
                this.lastSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = 8;
            } else {
                mc.interactionManager.clickSlot(0, slotInventory, 8, SlotActionType.SWAP, mc.player);
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slotHotbar));
            }
            wasSwappedInventory = true;
        }

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);

        if (wasSwapped) {
            if (this.legitSwap.isEnabled()) {
                SkyCore.getInstance().getScriptManager().addTask(this.script);
                this.script.schedule(EventUpdate.class, (eventUpdate) -> {
                    mc.player.getInventory().selectedSlot = this.lastSlot;
                    this.lastSlot = -1;
                    return true;
                });
            } else {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().selectedSlot));
            }
        }

        if (wasSwappedInventory) {
            if (this.legitSwap.isEnabled()) {
                SkyCore.getInstance().getScriptManager().addTask(this.script);
                this.script.schedule(EventUpdate.class, (eventUpdate) -> {
                    mc.player.getInventory().selectedSlot = this.lastSlot;
                    mc.interactionManager.clickSlot(0, slotInventory, 8, SlotActionType.SWAP, mc.player);
                    mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
                    this.lastSlot = -1;
                    return true;
                });
            } else {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().selectedSlot));
                mc.interactionManager.clickSlot(0, slotInventory, 8, SlotActionType.SWAP, mc.player);
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
            }
        }
    }

    @EventTarget
    public void onTickMovement(EventTickMovement e) {
        if (target != null) {
            if (target.isBlocking() && this.hurtTimer.finished(50L)) {
                if (!this.isPostUpdateAttack && mc.player.isSprinting() && !mc.player.isOnGround() && !mc.player.isSwimming()) {
                    mc.player.setSprinting(false);
                    mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, Mode.STOP_SPRINTING));
                    if (!AutoSprint.INSTANCE.isEnabled()) {
                        mc.options.sprintKey.setPressed(false);
                    }
                }
                this.breakShieldAndAttack();
                this.hurtTimer.reset();
            }
        }
    }

    @EventTarget
    public void eventRotate(EventGameUpdate e) {
        if (target != null) {
            SkyCore.getInstance().getModuleManager().setAcceleration(0.0F);
            Vec3d eyes = mc.player.getEyePos();

            Vec3d point;
            boolean isElytra = this.isElytraCombat();
            Box box = target.getBoundingBox();
            if (ElytraComponent.isReallyWorldChaseActive()) {
                ElytraComponent.setVector(ElytraComponent.getVector3d(mc.player, target));
                point = eyes.add(ElytraComponent.vector);
            } else if (target instanceof PlayerEntity && ElytraTarget.INSTANCE != null && ElytraTarget.INSTANCE.isEnabled() && this.smartOvertake.isEnabled() && mc.player.isGliding() && target.isGliding()) {
                float predictTicks = mc.player.getEyePos().distanceTo(target.getBoundingBox().getCenter()) > 8.0D ? 8.0F : this.predict.getCurrent();
                point = PredictUtils.predict(target, target.getPos(), predictTicks);
            } else {
                double aimDistance = this.getAimDistance();
                point = this.hvh.isSelected() ? target.getBoundingBox().getCenter() :
                        (this.legendsGrief.isSelected() || this.wellMine.isSelected() || this.cake.isSelected() ?
                                MultipointUtils.getNearestPoint(target, aimDistance) :
                                MultipointUtils.getMultipoint(target, aimDistance));
            }

            Rotation angle = RotationUtil.fromVec3d(point.subtract(eyes));
            float deltaYaw = MathHelper.wrapDegrees(angle.getYaw() - this.lastYaw);
            float deltaPitch = angle.getPitch() - this.lastPitch;

            if (this.legendsGrief.isSelected() && Math.random() < 0.3) {
                angle = new Rotation(angle.getYaw(), angle.getPitch() + this.neuroOffset);
            }

            if (isElytra) {
                if (ElytraComponent.isReallyWorldChaseActive()) {
                    ElytraComponent.updateRotation(new Vec2f(this.lastYaw, this.lastPitch));
                    this.lastYaw = mc.player.getYaw();
                    this.lastPitch = mc.player.getPitch();
                } else {
                    this.lastYaw = angle.getYaw();
                    this.lastPitch = angle.getPitch();
                    applyDirectRotation(angle);
                }
            } else if (this.matrixVulcan.isSelected()) {
                this.lastYaw = angle.getYaw();
                this.lastPitch = angle.getPitch();
                applyDirectRotation(angle);
            } else if (this.hvh.isSelected()) {
                this.lastYaw = angle.getYaw();
                this.lastPitch = angle.getPitch();
                this.handleSmoothRotation(target, angle, isElytra);
            } else if (this.lonyJir.isSelected()) {
                this.handleLonyGriefRotation(deltaYaw, deltaPitch, angle);
            } else if (this.legendsGrief.isSelected() || this.cake.isSelected()) {
                this.handleLegendsGriefRotation(deltaYaw, deltaPitch, angle, isElytra);
            } else if (this.lonyBypass.isSelected()) {
                this.handleLonyBypassRotation(deltaYaw, deltaPitch, angle);
            } else if (this.wellMine.isSelected()) {
                this.handleWellMineRotation(deltaYaw, deltaPitch, angle, isElytra);
            } else if (this.test.isSelected()) {
                this.handleTestRotation(target);
            } else if (this.droid.isSelected()) {
                this.handleDroidRotation(target);
            } else if (this.botinokBypass.isSelected()) {
                this.handleBotinokBypassRotation(angle, eyes);
            }
        }
    }

    private void handleLonyGriefRotation(float deltaYaw, float deltaPitch, Rotation angle) {
        if (mc.player.isGliding()) {
            if (!this.isBack) {
                this.acceleration += 0.005F;
                if (this.acceleration >= 0.13F) this.isBack = true;
            } else {
                if (this.acceleration >= -0.02F) this.acceleration -= 0.005F;
                if (this.acceleration <= -0.02F) this.isBack = false;
            }
        } else if (!RaytracingUtil.rayTrace(mc.player.getRotationVector(), 1488.0D, target.getBoundingBox())) {
            this.acceleration += 0.0015F;
        } else if (this.acceleration > 0.0F) {
            this.acceleration -= 0.01F;
        }

        float smooth = Math.max(this.acceleration, 0.0F);
        float newYaw = this.lastYaw + deltaYaw * Math.min(smooth * 0.9F, 1.0F);
        float newPitch = this.lastPitch + deltaPitch * Math.min(smooth * 0.9F / 2.0F, 1.0F);
        newYaw += (float) (Math.random() * 15.0 - 10.0);
        newPitch += (float) (Math.random() * 15.0 - 10.0);
        newYaw -= (newYaw - this.lastYaw) % Rotation.gcd();
        newPitch -= (newPitch - this.lastPitch) % Rotation.gcd();

        Rotation smoothRot = new Rotation(newYaw, newPitch);
        float deltaYaw2 = MathHelper.wrapDegrees(mc.gameRenderer.getCamera().getYaw() - this.lastYaw);
        float deltaPitch2 = mc.gameRenderer.getCamera().getPitch() - this.lastPitch;
        if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
            deltaYaw2 = MathHelper.wrapDegrees(mc.gameRenderer.getCamera().getYaw() - 180.0F - this.lastYaw);
            deltaPitch2 = -mc.gameRenderer.getCamera().getPitch() - this.lastPitch;
        }

        applyDirectRotation(smoothRot);
        this.lastYaw = smoothRot.getYaw();
        this.lastPitch = smoothRot.getPitch();
    }

    private void handleLegendsGriefRotation(float deltaYaw, float deltaPitch, Rotation angle, boolean isElytra) {
        Box box = target.getBoundingBox();
        boolean visible = RaytracingUtil.rayTrace(mc.player.getRotationVector(), 999.0D, box);
        float boost = ElytraMotion.INSTANCE.isEnabled() ? 2.5F : 1.0F;

        if (mc.player.isGliding() && target.isGliding()) {
            if (this.isBack) {
                if (this.acceleration >= -0.02F) {
                    this.acceleration -= Math.abs(MathHelper.wrapDegrees(angle.getYaw() - this.lastYaw)) > 80.0F ? 0.1F : 0.01F;
                }
                if (this.acceleration <= -0.02F) this.isBack = false;
            } else {
                this.acceleration += 0.004F;
                if (this.acceleration >= 0.17F || visible) this.isBack = true;
            }
        } else if (this.isBack) {
            if (this.acceleration >= -0.01F) {
                this.acceleration -= Math.abs(MathHelper.wrapDegrees(angle.getYaw() - this.lastYaw)) > 80.0F ? 0.1F : 0.01F;
            }
            if (this.acceleration <= -0.01F) this.isBack = false;
        } else {
            this.acceleration += 0.004F;
            if (this.acceleration >= 0.18F || visible) this.isBack = true;
        }

        float smooth = Math.max(this.acceleration, 0.0F);
        float newYaw = this.lastYaw + deltaYaw * Math.min(smooth, 1.0F);
        float newPitch = this.lastPitch + deltaPitch * Math.min(smooth / 2.0F, 1.0F);
        newYaw -= (newYaw - this.lastYaw) % Rotation.gcd();
        newPitch -= (newPitch - this.lastPitch) % Rotation.gcd();

        Rotation smoothRot = new Rotation(newYaw, newPitch);
        float deltaYaw2 = MathHelper.wrapDegrees(mc.gameRenderer.getCamera().getYaw() - this.lastYaw);
        float deltaPitch2 = mc.gameRenderer.getCamera().getPitch() - this.lastPitch;
        if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
            deltaYaw2 = MathHelper.wrapDegrees(mc.gameRenderer.getCamera().getYaw() - 180.0F - this.lastYaw);
            deltaPitch2 = -mc.gameRenderer.getCamera().getPitch() - this.lastPitch;
        }

        applyDirectRotation(smoothRot);
        this.lastYaw = smoothRot.getYaw();
        this.lastPitch = smoothRot.getPitch();
    }

    private void handleWellMineRotation(float deltaYaw, float deltaPitch, Rotation angle, boolean isElytra) {
        boolean visible = RaytracingUtil.rayTrace(mc.player.getRotationVector(), 999.0D, target.getBoundingBox());

        if (this.isBack) {
            float diff = Math.abs(MathHelper.wrapDegrees(angle.getYaw() - this.lastYaw));
            this.acceleration -= diff > 70.0F ? 0.03F : (diff > 40.0F ? 0.015F : 0.004F);
            if (this.acceleration <= -0.005F) this.isBack = false;
        } else {
            this.acceleration += 0.0015F;
            if (this.acceleration >= 0.10F || visible) this.isBack = true;
        }

        float smooth = Math.max(this.acceleration, 0.02F);
        float newYaw = this.lastYaw + deltaYaw * smooth;
        float newPitch = this.lastPitch + deltaPitch * smooth * 0.8F;
        newYaw -= (newYaw - this.lastYaw) % Rotation.gcd();
        newPitch -= (newPitch - this.lastPitch) % Rotation.gcd();

        Rotation rot = new Rotation(newYaw, newPitch);
        applyDirectRotation(rot);
        this.lastYaw = newYaw;
        this.lastPitch = newPitch;
    }

    private void handleTestRotation(LivingEntity t) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d look = mc.player.getRotationVec(1.0F);
        Vec3d targetPos = t.getPos().add(0, t.getHeight() / 2, 0);
        Box box = t.getBoundingBox().expand(-0.1);

        if (t instanceof PlayerEntity && mc.player.isGliding() && t.isGliding() && ElytraComponent.isReallyWorldChaseActive()) {
            Vec3d chasePoint = ElytraComponent.pos.add(t.getRotationVec(1.0F).normalize().multiply(2.0D));
            targetPos = chasePoint.add(0, t.getEyeHeight(t.getPose()) * 0.9, 0);
            box = t.getBoundingBox().offset(chasePoint.subtract(t.getPos())).expand(-0.05);
        } else if (t instanceof PlayerEntity && mc.player.isGliding() && t.isGliding() && this.smartOvertake.isEnabled()) {
            // Test mode on elytra: move/aim strictly by predict point.
            Vec3d predicted = PredictUtils.predict(t, t.getPos(), this.predict.getCurrent());
            targetPos = predicted.add(0, t.getEyeHeight(t.getPose()) * 0.9, 0);
            box = t.getBoundingBox().offset(predicted.subtract(t.getPos())).expand(-0.05);
        }

        double dist = eye.distanceTo(targetPos);
        Vec3d proj = eye.add(look.multiply(dist));
        double x = MathHelper.clamp(proj.x, box.minX, box.maxX);
        double y = MathHelper.clamp(proj.y, box.minY, box.maxY);
        double z = MathHelper.clamp(proj.z, box.minZ, box.maxZ);

        Rotation needed = RotationUtil.fromVec3d(new Vec3d(x, y, z).subtract(eye));
        float yd = MathHelper.wrapDegrees(needed.getYaw() - this.lastYaw);
        float pd = needed.getPitch() - this.lastPitch;
        float speed = mc.player.isGliding() ? 0.6f : 0.2f;
        if (ElytraMotion.INSTANCE.isEnabled()) speed += 0.3f;

        float newYaw = this.lastYaw + MathHelper.clamp(yd * speed, -80.0F, 80.0F);
        float newPitch = MathHelper.clamp(this.lastPitch + MathHelper.clamp(pd * speed, -60.0F, 60.0F), -90.0F, 90.0F);
        newYaw = Rotation.applyGCD(newYaw, this.lastYaw);
        newPitch = Rotation.applyGCD(newPitch, this.lastPitch);

        Rotation rot = new Rotation(newYaw, newPitch);
        applyDirectRotation(rot);
        this.lastYaw = newYaw;
        this.lastPitch = newPitch;
    }

    private void handleDroidRotation(LivingEntity t) {
        if (t == null) return;
        Vec3d targetPos = t.getBoundingBox().getCenter().add(randomOffset);
        Vec3d eyes = mc.player.getEyePos();
        double diffX = targetPos.x - eyes.x;
        double diffY = targetPos.y - eyes.y;
        double diffZ = targetPos.z - eyes.z;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        float yaw = (float) (Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F);
        float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        float deltaYaw = MathHelper.wrapDegrees(yaw - this.lastYaw);
        float deltaPitch = pitch - this.lastPitch;

        float overshoot = (float) (Math.sin(System.currentTimeMillis() / 150.0) * 2.0);
        deltaYaw += overshoot * 0.1f;
        deltaPitch += overshoot * 0.05f;

        float speed = MathHelper.clamp((float) Math.max(Math.abs(deltaYaw), Math.abs(deltaPitch)), 5.0f, 60.0f);
        speed *= (0.6f + Math.random() * 0.3f);

        float currentYawDelta = MathHelper.clamp(lastYawDelta * 0.6f + deltaYaw * 0.4f, -speed, speed);
        float currentPitchDelta = MathHelper.clamp(lastPitchDelta * 0.6f + deltaPitch * 0.4f, -speed, speed);

        float finalYaw = Rotation.applyGCD(this.lastYaw + currentYawDelta, this.lastYaw);
        float finalPitch = Rotation.applyGCD(MathHelper.clamp(this.lastPitch + currentPitchDelta, -90.0F, 90.0F), this.lastPitch);

        lastYawDelta = currentYawDelta;
        lastPitchDelta = currentPitchDelta;

        Rotation rot = new Rotation(finalYaw, finalPitch);
        applyDirectRotation(rot);
        this.lastYaw = finalYaw;
        this.lastPitch = finalPitch;
    }

    private void handleBotinokBypassRotation(Rotation angle, Vec3d eyes) {
        Box targetBox = target.getBoundingBox();
        if (ElytraComponent.isReallyWorldChaseActive()) {
            Vec3d chasePoint = ElytraComponent.pos.add(target.getRotationVec(1.0F).normalize().multiply(2.0D));
            targetBox = target.getBoundingBox().offset(chasePoint.subtract(target.getPos()));
        } else if (ElytraTarget.INSTANCE != null && ElytraTarget.INSTANCE.isEnabled() && this.smartOvertake.isEnabled() && target instanceof PlayerEntity) {
            Vec3d predictedPos = PredictUtils.predict(target, target.getPos(), this.predict.getCurrent());
            targetBox = target.getBoundingBox().offset(predictedPos.subtract(target.getPos()));
        }

        Box innerBox = targetBox.expand(-0.15D);
        Vec3d lookVec = mc.player.getRotationVector();
        double dist = eyes.distanceTo(targetBox.getCenter());
        Vec3d projectedView = eyes.add(lookVec.multiply(dist));
        double x = MathHelper.clamp(projectedView.x, innerBox.minX, innerBox.maxX);
        double y = MathHelper.clamp(projectedView.y, innerBox.minY, innerBox.maxY);
        double z = MathHelper.clamp(projectedView.z, innerBox.minZ, innerBox.maxZ);

        Rotation needed = RotationUtil.fromVec3d(new Vec3d(x, y, z).subtract(eyes));
        float yawDiff = MathHelper.wrapDegrees(needed.getYaw() - this.lastYaw);
        float pitchDiff = needed.getPitch() - this.lastPitch;
        float baseSpeed = (mc.player.isGliding() ? 0.5F : 0.4F) + (float) Math.random() * 0.3F;

        float newYaw = this.lastYaw + yawDiff * baseSpeed;
        float newPitch = this.lastPitch + pitchDiff * baseSpeed;

        long time = System.currentTimeMillis();
        newYaw += (float) (Math.sin(time / 50.0D) * 0.8D);
        newPitch += (float) (Math.cos(time / 65.0D) * 0.6D);
        newPitch = MathHelper.clamp(newPitch, -80.0F, 89.9F);

        float gcd = Rotation.gcd();
        newYaw -= (newYaw - this.lastYaw) % gcd;
        newPitch -= (newPitch - this.lastPitch) % gcd;

        Rotation s = new Rotation(newYaw, newPitch);
        float turnSpeed = mc.player.isGliding() ? 3.5F : 2.0F;
        applyDirectRotation(s);
        this.lastYaw = s.getYaw();
        this.lastPitch = s.getPitch();
    }

    private void handleLonyBypassRotation(float deltaYaw, float deltaPitch, Rotation angle) {
        Box box = target.getBoundingBox();
        if (mc.player.isGliding() && target.isGliding()) {
            if (this.isBack) {
                if (this.acceleration >= -0.02F) this.acceleration -= Math.abs(MathHelper.wrapDegrees(angle.getYaw() - this.lastYaw)) > 80.0F ? 0.1F : 0.01F;
                if (this.acceleration <= -0.02F) this.isBack = false;
            } else {
                this.acceleration += 0.004F;
                if (this.acceleration >= 0.17F || RaytracingUtil.rayTrace(mc.player.getRotationVector(), 1488.0D, box)) this.isBack = true;
            }
        } else if (this.isBack) {
            if (this.acceleration >= -0.01F) this.acceleration -= Math.abs(MathHelper.wrapDegrees(angle.getYaw() - this.lastYaw)) > 80.0F ? 0.1F : 0.01F;
            if (this.acceleration <= -0.01F) this.isBack = false;
        } else {
            this.acceleration += 0.004F;
            if (this.acceleration >= 0.18F || RaytracingUtil.rayTrace(mc.player.getRotationVector(), 999.0D, box.expand(-0.5D))) this.isBack = true;
        }

        float smooth = Math.max(this.acceleration, 0.0F);
        float newYaw = this.lastYaw + deltaYaw * Math.min(smooth, 1.0F);
        float newPitch = this.lastPitch + deltaPitch * Math.min(smooth / 2.0F, 1.0F);

        newYaw -= (newYaw - this.lastYaw) % Rotation.gcd();
        newPitch -= (newPitch - this.lastPitch) % Rotation.gcd();

        Rotation smoothRot = new Rotation(newYaw, newPitch);
        float deltaYaw2 = MathHelper.wrapDegrees(mc.gameRenderer.getCamera().getYaw() - this.lastYaw);
        float deltaPitch2 = mc.gameRenderer.getCamera().getPitch() - this.lastPitch;
        if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
            deltaYaw2 = MathHelper.wrapDegrees(mc.gameRenderer.getCamera().getYaw() - 180.0F - this.lastYaw);
            deltaPitch2 = -mc.gameRenderer.getCamera().getPitch() - this.lastPitch;
        }

        applyDirectRotation(smoothRot);
        this.lastYaw = smoothRot.getYaw();
        this.lastPitch = smoothRot.getPitch();
    }

    private boolean shouldVisuallyTurnBack() {
        return this.visualTurnBack.isEnabled() && this.smartOvertake.isEnabled() && this.isElytraCombat() && target != null && this.shouldStopOvertake;
    }

    private void updateVisualTurnBack() {
        boolean needTurnBack = this.shouldVisuallyTurnBack();
        float targetOffset = needTurnBack ? 180.0F : 0.0F;
        float speed = this.visualTurnSpeed.getCurrent();
        if (Math.abs(this.visualYawOffset - targetOffset) < speed) this.visualYawOffset = targetOffset;
        else if (this.visualYawOffset < targetOffset) this.visualYawOffset += speed;
        else this.visualYawOffset -= speed;
        this.visualYawOffset = MathHelper.clamp(this.visualYawOffset, 0.0F, 180.0F);
        this.isVisuallyTurnedBack = this.visualYawOffset > 1.0F;
    }

    private void handleSmoothRotation(LivingEntity entity, Rotation targetAngle, boolean isElytra) {
        if (entity == null || mc.player == null || targetAngle == null) {
            return;
        }

        if (isElytra || mc.player.isGliding()) {
            this.applyDirectRotation(targetAngle);
            return;
        }

        float speed = new SecureRandom().nextBoolean() ? this.randomLerp(0.3F, 0.4F) : this.randomLerp(0.5F, 0.6F);
        float cos = (float)Math.cos(System.currentTimeMillis() / 70.0D);
        float sin = (float)Math.sin(System.currentTimeMillis() / 115.0D);
        float yawOffset = (float)Math.ceil(this.randomLerp(1.0F, 3.0F) * cos);
        float pitchOffset = (float)Math.ceil(this.randomLerp(1.0F, 2.0F) * sin);

        this.smoothLerpYaw = this.wrapLerp(speed, this.smoothLerpYaw, targetAngle.getYaw() + yawOffset);
        this.smoothLerpPitch = this.wrapLerp(speed / 2.0F, this.smoothLerpPitch, MathHelper.clamp(targetAngle.getPitch() + pitchOffset, -90.0F, 90.0F));
        this.fastSmoothRotation();
    }

    private void fastSmoothRotation() {
        if (mc.player == null) {
            return;
        }

        float currentYaw = mc.player.getYaw();
        float currentPitch = mc.player.getPitch();
        float deltaYaw = MathHelper.wrapDegrees(this.smoothLerpYaw - currentYaw);
        float deltaPitch = MathHelper.wrapDegrees(this.smoothLerpPitch - currentPitch);
        Rotation rotation = new Rotation(currentYaw + deltaYaw, currentPitch + deltaPitch);
        this.lastYaw = rotation.getYaw();
        this.lastPitch = rotation.getPitch();
        RotationComponent.update(rotation, 180.0F, 180.0F, 0, 5);
    }

    private float wrapLerp(float step, float input, float target) {
        return input + step * MathHelper.wrapDegrees(target - input);
    }

    private float randomLerp(float min, float max) {
        return MathHelper.lerp(new SecureRandom().nextFloat(), min, max);
    }

    private void applyDirectRotation(Rotation rotation) {
        if (rotation == null) return;
        Rotation sanitized = new Rotation(rotation.getYaw(), MathHelper.clamp(rotation.getPitch(), -90.0F, 90.0F));
        // Не показываем крутку локально в first-person: только боевая ротация.
        RotationComponent.update(sanitized, 360.0F, 360.0F, 360.0F, 360.0F, 0, 1, false);
    }

    public float getVisualYawOffset() { return this.visualYawOffset; }
    public boolean isVisuallyTurnedBack() { return this.isVisuallyTurnedBack; }
    public float getVisualCameraYaw(float originalYaw) { return originalYaw + this.visualYawOffset; }
    public float getVisualCameraPitch(float originalPitch) {
        if (this.visualYawOffset > 90.0F) return MathHelper.lerp((this.visualYawOffset - 90.0F) / 90.0F, originalPitch, -originalPitch);
        return originalPitch;
    }

    private float calculateOvertake() {
        if (target == null || mc.player == null) return 0.0F;
        Vec3d targetVel = target.getVelocity();
        Vec3d direction = targetVel.horizontalLength() > 0.01 ? new Vec3d(targetVel.x, 0, targetVel.z).normalize() : new Vec3d(target.getRotationVec(1.0F).x, 0, target.getRotationVec(1.0F).z).normalize();
        return (float) new Vec3d(mc.player.getX() - target.getX(), 0, mc.player.getZ() - target.getZ()).dotProduct(direction);
    }

    private boolean isTouchingTargetHitbox() {
        if (target == null || mc.player == null) return false;
        Box targetBox = target.getBoundingBox().expand(this.hitboxExpand.getCurrent());
        if (this.lastPredictedPosition != null) targetBox = targetBox.union(new Box(this.lastPredictedPosition.x - 0.3, this.lastPredictedPosition.y - 0.3, this.lastPredictedPosition.z - 0.3, this.lastPredictedPosition.x + 0.3, this.lastPredictedPosition.y + 0.3, this.lastPredictedPosition.z + 0.3));
        Vec3d closest = new Vec3d(MathHelper.clamp(mc.player.getEyePos().x, targetBox.minX, targetBox.maxX), MathHelper.clamp(mc.player.getEyePos().y, targetBox.minY, targetBox.maxY), MathHelper.clamp(mc.player.getEyePos().z, targetBox.minZ, targetBox.maxZ));
        return mc.player.getEyePos().distanceTo(closest) <= 3.4D;
    }

    public boolean canHitWithOvertake() { return !this.smartOvertake.isEnabled() || !this.isElytraCombat() || (this.isTouchingTargetHitbox() && this.overtakeAmount <= this.predict.getCurrent()); }
    public boolean shouldStopOvertaking() { return this.smartOvertake.isEnabled() && this.isElytraCombat() && target != null && this.overtakeAmount >= (this.predict.getCurrent() + 1.5F); }
    public Vec3d getStopPosition() {
        if (target == null) return null;
        Vec3d direction = target.getVelocity().horizontalLength() > 0.01 ? new Vec3d(target.getVelocity().x, 0, target.getVelocity().z).normalize() : new Vec3d(target.getRotationVec(1.0F).x, 0, target.getRotationVec(1.0F).z).normalize();
        return target.getPos().add(direction.multiply(this.predict.getCurrent())).add(0, mc.player.getY() - target.getY(), 0);
    }

    private void resetState() {
        lockedTarget = null; // сброс состояния
        this.currentTargetSpeed = 0.0F;
        this.overtakeAmount = 0.0F;
        this.ticksInRange = 0;
        this.shouldStopOvertake = false;
        this.visualYawOffset = 0.0F;
        this.isVisuallyTurnedBack = false;
        this.wasOnGround = false;
        this.timeOnGround = 0;
        this.lastJumpTime = 0;
        this.lastPredictedPosition = null;
        this.isPredictionActive = false;
        ElytraComponent.resetState();
    }

    private boolean isElytraCombat() { return mc.player != null && mc.player.isGliding() && target != null && target.isGliding() && target instanceof PlayerEntity; }

    private LivingEntity lockedTarget = null;

    private LivingEntity updateTarget() {
        if (mc.world == null || mc.player == null) return null;

        // Если есть залоченный таргет — проверяем что он всё ещё валиден
        if (lockedTarget != null) {
            if (this.isValid(lockedTarget)) {
                return lockedTarget;
            } else {
                // Таргет больше не валиден — сбрасываем
                lockedTarget = null;
            }
        }

        // Ищем нового таргета (только если lockedTarget == null)
        List<LivingEntity> targets = new ArrayList<>();
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof LivingEntity living && this.isValid(living)) {
                targets.add(living);
            }
        }

        if (!targets.isEmpty()) {
            // Сортировка по дистанции — только один раз при выборе нового таргета
            targets.sort(Comparator.comparingDouble(e -> mc.player.getPos().distanceTo(e.getPos())));
            lockedTarget = targets.get(0);
            return lockedTarget;
        }

        return null;
    }

    public boolean isValid(LivingEntity entity) {
        if (entity == null || entity == mc.player || !entity.isAlive() || entity.getHealth() <= 0.0F) return false;
        if (mc.player == null || !mc.player.isAlive() || mc.player.getHealth() <= 0.0F) return false;
        if (entity instanceof PlayerEntity) {
            if (!this.targetTypeSetting.isEnable("Игроков")) return false;
            if (SkyCore.getInstance().getFriendManager().isFriend(entity.getName().getString())) return false;
            if (AntiBot.INSTANCE.isBot((PlayerEntity) entity)) return false;
        }
        if ((entity instanceof PassiveEntity || entity instanceof FishEntity) && (!this.targetTypeSetting.isEnable("Животных") || SkyCore.getInstance().getServerHandler().isPvp())) return false;
        if ((entity instanceof HostileEntity || entity instanceof AmbientEntity) && (!this.targetTypeSetting.isEnable("Мобов") || SkyCore.getInstance().getServerHandler().isPvp())) return false;
        float maxDist = mc.player.isGliding()
                ? this.getAimDistance()
                : (this.distance.getCurrent() + this.distanceRotation.getCurrent());
        if (mc.player.getEyePos().distanceTo(MultipointUtils.getNearestPoint(entity, maxDist)) > maxDist) return false;
        return !(entity instanceof ArmorStandEntity);
    }

    public boolean appliesMovementCorrection() {
        return this.isEnabled() && target != null && mc.player != null;
    }

    public double getEntitySpeed(Entity entity) {
        Vec3d currentPos = entity.getPos();
        Vec3d previousPos = this.previousPositions.getOrDefault(entity, currentPos);
        double dx = currentPos.x - previousPos.x;
        double dz = currentPos.z - previousPos.z;
        double speed = Math.sqrt(dx * dx + dz * dz) * 20.0D;
        this.previousPositions.put(entity, currentPos);
        return speed;
    }

    @EventTarget
    private void setCorrection(EventMoveInput e) {
        if (RotationComponent.instance.isRotating() || SmoothRotationComponent.instance.isRotating()) {
            if (target == null || mc.player == null) {
                return;
            }

            if (this.correctionFree.isSelected()) {
                MoveUtil.fixMovement(e, FreeLookComponent.getFreeYaw());
            } else if (this.correctionTarget.isSelected()) {
                Vec3d targetVector = target.getPos();
                if (Speed.INSTANCE.isEnabled() && this.getEntitySpeed(target) > 5.0D) {
                    Vec3d forward = Vec3d.fromPolar(0.0F, target.getYaw()).normalize();
                    targetVector = target.getPos().add(forward.multiply(2.0D));
                }
                if (!MoveComponent.isStop()) {
                    MoveUtil.moveToPosition(e, targetVector, mc.player.getYaw());
                }
            } else if (this.correctionFocus.isSelected()) {
                Vec3d direction = AuraUtil.getClosestVec(target);
                float targetYaw = MathHelper.wrapDegrees((float)(Math.toDegrees(Math.atan2(direction.z, direction.x)) - 90.0D));
                MoveUtil.fixMovement(e, targetYaw);
            }
        }

        if (this.legitSprintResetTicks > 0) {
            e.setForward(0.0F);
            e.setStrafe(0.0F);
            --this.legitSprintResetTicks;
        }
    }

    public LivingEntity getTarget() { return this.isEnabled() ? target : null; }

    public void onEnable() {
        target = null;
        lockedTarget = null; // сброс при включении
        this.neuroOffset = 0.0F;
        this.neuroTimer.reset();
        this.attackTimer.reset();
        this.isPostUpdateAttack = false;
        if (mc.player != null) {
            this.smoothLerpYaw = mc.player.getYaw();
            this.smoothLerpPitch = mc.player.getPitch();
        }
        this.resetState();
        super.onEnable();
    }

    public void onDisable() {
        SkyCore.getInstance().getModuleManager().setAcceleration(0.0F);
        this.isPostUpdateAttack = false;
        lockedTarget = null;
        this.releaseRotation();
        this.resetState();
        super.onDisable();
    }

    private void releaseRotation() {
        RotationComponent.instance.stopRotation();
        SmoothRotationComponent.instance.stopRotation();
        FreeLookComponent.setActive(false);
        if (mc.player != null && mc.gameRenderer != null && mc.gameRenderer.getCamera() != null) {
            float yaw = mc.gameRenderer.getCamera().getYaw();
            float pitch = mc.gameRenderer.getCamera().getPitch();
            mc.player.setYaw(yaw);
            mc.player.setPitch(pitch);
        }
    }



    public boolean isPredictionActive() { return this.isPredictionActive; }
    public float getCurrentTargetSpeed() { return this.currentTargetSpeed; }
    public float getOvertakeAmount() { return this.overtakeAmount; }
    public boolean needsToStopForward() { return this.shouldStopOvertake; }
}