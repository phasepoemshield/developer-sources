package This.skycore.tyca1337.client.Interface.elements.component;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.util.math.MathHelper;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Font;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.impl.render.Interface;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;
import This.skycore.util.render.display.shader.DrawUtil;

public class NotifyComponent extends DraggableHudElement {
    /** Как в src new: высота карточки, отступ сверху внутри строки, шаг стека. */
    private static final float NOTIF_H = 16f;
    private static final float NOTIF_Y_INSET = 3f;
    /** Как в KeybindsComponent: blur 4, затемнение 0.72, скругление оверлея 3. */
    private static final float NOTIF_BLUR_RADIUS = 4f;
    private static final float NOTIF_RECT_RADIUS = 3f;
    private static final float NOTIF_BLUR = 12f;
    private static final float ICON_PAD_L = 2f;
    /** Расстояние от слота иконки до имени модуля (шире = дальше текст от J/K). */
    private static final float MODULE_ICON_TO_TEXT_GAP = 3.5f;
    private static final float MODULE_LEFT_GUTTER = ICON_PAD_L +  MODULE_ICON_TO_TEXT_GAP;
    private static final float TEXT_SIZE = 6.5f;
    private static final float ICON_SIZE = 8.8f;
    private static final float NURSULTAN_STACK = 13.5f;
    /**
     * Режим «Обычный» — как sky.core FontNotification / NotificationRender preview (1.16.5),
     * с MSDF-размерами под Recode (не 12/13 pt).
     */
    private static final float SKY_ORD_H = 19f;
    private static final float SKY_ORD_R = 5f;
    private static final float SKY_ORD_PAD_X = 8f;
    private static final float SKY_ORD_PAD_Y = 6f;
    private static final float SKY_ORD_GAP = 4f;
    private static final float SKY_ORD_ICON_SLOT = 7f;
    private static final float SKY_ORD_MIN_W = 98f;
    /** skycore[13] → компактный глиф в слоте 7px. */
    private static final float SKY_ORD_SKYCORE_PT = 7f;
    /** Как NotificationManager при ordinaryMode. */
    private static final float SKY_ORD_STACK_STEP = 21f;
    /** Сдвиг текста вверх внутри карточки «Обычный». */
    private static final float SKY_ORD_TEXT_NUDGE_Y = -1.35f;
    /** То же по вертикали для иконки слева. */
    private static final float SKY_ORD_ICON_NUDGE_Y = -1.35f;

    /** Текст модуля: «Module» + отступ + имя + отступ + enabled/disabled (MSDF даёт нулевую ширину обычного пробела). */
    private static final String MODULE_NOTIFY_LABEL = "Module  ";
    /** Фиксированный зазор между сегментами строки, пиксели. */
    private static final float MODULE_NOTIFY_SEGMENT_GAP_PX = 0f;

    private final Animation toggleAnimation;
    private final List<NotifyComponent.BaseNotification> notifications;

    public NotifyComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
        this.toggleAnimation = new Animation(300L, Easing.BACK_OUT);
        this.notifications = new ArrayList();
    }

    public void addNotification(Module module, boolean enabled) {
        this.notifications.addLast(new NotifyComponent.ModuleNotification(module, enabled));
    }

    private static float notifWidth(float textWidthPx, float leftGutter) {
        return leftGutter + textWidthPx;
    }

    private static float contentY(float rowY) {
        return rowY + NOTIF_Y_INSET;
    }

    private static float ordinaryCardWidth(float textBodyWidth) {
        return Math.max(SKY_ORD_MIN_W, SKY_ORD_PAD_X + SKY_ORD_ICON_SLOT + SKY_ORD_GAP + textBodyWidth + SKY_ORD_PAD_X);
    }

    /** Как RenderUtil.drawRoundedRectangle + ColorUtil.darken(icon, 0.1f) в 1.16. */
    private static void drawSkycoreOrdinaryCard(CustomDrawContext ctx, float x, float yTop, float w, Theme theme, float alpha, float darkness) {
        if (notifTransparentBg()) {
            return;
        }
        ColorRGBA bg = ColorUtil.darkenBrightness(theme.getColor(), 0.1f);
        ColorRGBA panelBg = bg.mulAlpha(MathHelper.clamp(alpha * darkness, 0f, 1f));
        ctx.drawRoundedRect(x, yTop, w, SKY_ORD_H, BorderRadius.all(SKY_ORD_R), panelBg);
    }

    private static boolean ordinaryNotifMode() {
        Interface ui = Interface.INSTANCE;
        return ui.isEnabled() && ui.notificationRenderMode.is("Обычный");
    }

    private static boolean notifTransparentBg() {
        Interface ui = Interface.INSTANCE;
        return ui.isEnabled() && ui.notificationTransparentBg.isEnabled();
    }

    /** Иконки категорий как в 1.16.5 (Combat l, Movement m, Visuals b, Player i, Misc d). */
    private static String legacyCategoryIcon(Module module) {
        return switch (module.getCategory()) {
            case COMBAT -> "l";
            case MOVEMENT -> "m";
            case RENDER -> "b";
            case PLAYER -> "i";
            case MISC, THEMES -> "d";
        };
    }

    private static void drawNotifBackground(CustomDrawContext ctx, float x, float cy, float w, float alpha, float darkness) {
        if (notifTransparentBg()) {
            return;
        }
        ColorRGBA panelBg = new ColorRGBA(
                (int) (15 * darkness),
                (int) (15 * darkness),
                (int) (15 * darkness),
                (int) (255 * 0.72f * alpha * darkness)
        );
        BorderRadius blurR = BorderRadius.all(NOTIF_BLUR_RADIUS);
        BorderRadius rectR = BorderRadius.all(NOTIF_RECT_RADIUS);
        DrawUtil.drawBlur(ctx.getMatrices(), x, cy, w, NOTIF_H, NOTIF_BLUR * darkness, blurR, ColorRGBA.WHITE);
        DrawUtil.drawRoundedRect(ctx.getMatrices(), x, cy, w, NOTIF_H, rectR, panelBg);
    }

    private static float iconXLeft(float panelX, Font iconFont, String icon) {
        return panelX + ICON_PAD_L + (iconFont.width(icon)) * 0.5f;
    }

    private static float textYCentered(float cy, Font textFont) {
        return cy + (NOTIF_H - textFont.height()) * 0.5f - 0.5f;
    }

    @Native
    public void render(CustomDrawContext ctx) {
        notifications.removeIf(e -> System.currentTimeMillis() - e.startTime > 2500 && e.scaleAnimation.getValue() < 0.01f);

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();

        float yOffset = 0.0f;
        int activeNotifications = 0;

        for (int i = notifications.size() - 1; i >= 0; i--) {
            NotifyComponent.BaseNotification notification = notifications.get(i);
            int visualIndex = notifications.size() - 1 - i;

            if (visualIndex > 4) {
                notification.scaleAnimation.update(0);
            } else {
                long timeElapsed = System.currentTimeMillis() - notification.startTime;
                if (timeElapsed > 1500) {
                    notification.scaleAnimation.update(0);
                } else {
                    notification.scaleAnimation.update(1);
                }
            }

            float alpha = notification.scaleAnimation.getValue();
            if (alpha < 0.01f) continue;

            boolean ordinary = ordinaryNotifMode();
            float stackStep = ordinary ? SKY_ORD_STACK_STEP : NURSULTAN_STACK;
            float width = notification.getWidth();
            float x = (mc.getWindow().getScaledWidth() - width) / 2f;
            float baseY = mc.getWindow().getScaledHeight() / 2f + (ordinary ? 15f : 21f);
            float targetY = baseY + yOffset;

            if (notification.y >= mc.getWindow().getScaledHeight() - 20f) {
                notification.y = targetY;
            } else {
                notification.y = notification.y + (targetY - notification.y) * 0.15f;
            }

            notification.x = x;

            float darkness = MathHelper.clamp(1.0f - (activeNotifications * 0.1f), 0.7f, 1.0f);

            if (alpha > 0.01f) {
                notification.render(ctx, notification.x, notification.y, theme, alpha, darkness);
                yOffset += stackStep;
                activeNotifications++;
            }
        }
    }

    private static class ModuleNotification extends NotifyComponent.BaseNotification {
        final Module module;
        final boolean enabled;

        ModuleNotification(Module module, boolean enabled) {
            this.module = module;
            this.enabled = enabled;
        }

        @Native
        void render(CustomDrawContext ctx, float x, float y, Theme theme, float alpha, float darkness) {
            if (ordinaryNotifMode()) {
                this.renderOrdinary(ctx, x, y, theme, alpha, darkness);
            } else {
                this.renderNursultan(ctx, x, y, theme, alpha, darkness);
            }
        }

        private void renderOrdinary(CustomDrawContext ctx, float x, float y, Theme theme, float alpha, float darkness) {
            String moduleName = this.module.getName();
            String status = this.enabled ? "  enabled" : "  disabled";

            Font textFont = Fonts.REGULAR.getFont(TEXT_SIZE);
            Font iconFont = Fonts.SKYCORE.getFont(SKY_ORD_SKYCORE_PT);
            String catIcon = legacyCategoryIcon(this.module);

            float labelW = Fonts.REGULAR.getWidth(MODULE_NOTIFY_LABEL, TEXT_SIZE);
            float nameW = Fonts.REGULAR.getWidth(moduleName, TEXT_SIZE);
            float statusW = Fonts.REGULAR.getWidth(status, TEXT_SIZE);
            float gap = MODULE_NOTIFY_SEGMENT_GAP_PX;
            float textInnerW = labelW + gap + nameW + gap + statusW;
            float w = ordinaryCardWidth(textInnerW);
            float top = y;

            drawSkycoreOrdinaryCard(ctx, x, top, w, theme, alpha, darkness);

            ctx.getMatrices().push();
            int a = (int) (255 * MathHelper.clamp(alpha * darkness, 0f, 1f));
            ColorRGBA logoTint = theme.getColor().mulAlpha(MathHelper.clamp(alpha * darkness, 0f, 1f));
            float iconX = x + SKY_ORD_PAD_X;
            float iconY = top + SKY_ORD_PAD_Y + (SKY_ORD_ICON_SLOT - 7f) * 0.5f + 2.5f + SKY_ORD_ICON_NUDGE_Y;
            ctx.drawText(iconFont, catIcon, iconX, iconY, logoTint);

            float textY = top + SKY_ORD_PAD_Y + (SKY_ORD_H - SKY_ORD_PAD_Y * 2f - textFont.height()) * 0.5f + 1f + SKY_ORD_TEXT_NUDGE_Y;
            float textX = iconX + SKY_ORD_ICON_SLOT + SKY_ORD_GAP;

            ColorRGBA white = new ColorRGBA(255, 255, 255, a);
            ColorRGBA nameBlue = new ColorRGBA(theme.getColor().getRed(), theme.getColor().getGreen(), theme.getColor().getBlue(), a);

            ctx.drawText(textFont, MODULE_NOTIFY_LABEL, textX, textY, white);
            textX += labelW + gap;
            ctx.drawText(textFont, moduleName, textX, textY, nameBlue);
            textX += nameW + gap;
            ctx.drawText(textFont, status, textX, textY, white);
            ctx.getMatrices().pop();
        }

        private void renderNursultan(CustomDrawContext ctx, float x, float y, Theme theme, float alpha, float darkness) {
            String moduleName = this.module.getName();
            String statusWord = this.enabled ? "enabled" : "disabled";
            String nurIcon = this.enabled ? "J" : "K";

            Font textFont = Fonts.SEMIBOLD.getFont(TEXT_SIZE);
            Font iconFont = Fonts.NUR.getFont(ICON_SIZE);
            float labelW = Fonts.SEMIBOLD.getWidth(MODULE_NOTIFY_LABEL, TEXT_SIZE);
            float nameW = Fonts.SEMIBOLD.getWidth(moduleName, TEXT_SIZE);
            float statusW = Fonts.SEMIBOLD.getWidth(statusWord, TEXT_SIZE);
            float gap = MODULE_NOTIFY_SEGMENT_GAP_PX;
            float textWidth = labelW + gap + nameW + gap + statusW;
            float w = notifWidth(textWidth, MODULE_LEFT_GUTTER);
            float cy = contentY(y);

            ctx.getMatrices().push();

            ColorRGBA iconColor = new ColorRGBA(
                    (int) (theme.getColor().getRed() * darkness),
                    (int) (theme.getColor().getGreen() * darkness),
                    (int) (theme.getColor().getBlue() * darkness),
                    (int) (255 * alpha)
            );

            drawNotifBackground(ctx, x, cy, w, alpha, darkness);

            float iconX = iconXLeft(x, iconFont, nurIcon);
            float iconY = cy + (NOTIF_H - iconFont.height()) * 0.5f;
            ctx.drawText(iconFont, nurIcon, iconX, iconY + 1, iconColor);

            float textX = x + MODULE_LEFT_GUTTER;
            float textY = textYCentered(cy, textFont);
            int a = (int) (255 * alpha * darkness);
            ColorRGBA nameColor = new ColorRGBA(255, 255, 255, a);
            ColorRGBA statusColor = this.enabled
                    ? new ColorRGBA(85, 255, 120, a)
                    : new ColorRGBA(255, 95, 95, a);

            ctx.drawText(textFont, MODULE_NOTIFY_LABEL, textX, textY + 0.3f, nameColor);
            textX += labelW + gap;
            ctx.drawText(textFont, moduleName, textX, textY + 0.3f, nameColor);
            textX += nameW + gap;
            ctx.drawText(textFont, statusWord, textX, textY + 0.3f, statusColor);

            ctx.getMatrices().pop();
        }

        @Override
        float getWidth() {
            if (ordinaryNotifMode()) {
                String moduleName = this.module.getName();
                String status = this.enabled ? "enabled" : "disabled";
                float labelW = Fonts.REGULAR.getWidth(MODULE_NOTIFY_LABEL, TEXT_SIZE);
                float nameW = Fonts.REGULAR.getWidth(moduleName, TEXT_SIZE);
                float statusW = Fonts.REGULAR.getWidth(status, TEXT_SIZE);
                float gap = MODULE_NOTIFY_SEGMENT_GAP_PX;
                return ordinaryCardWidth(labelW + gap + nameW + gap + statusW);
            }
            String moduleName = this.module.getName();
            String statusWord = this.enabled ? "enabled" : "disabled";
            float labelW = Fonts.SEMIBOLD.getWidth(MODULE_NOTIFY_LABEL, TEXT_SIZE);
            float nameW = Fonts.SEMIBOLD.getWidth(moduleName, TEXT_SIZE);
            float statusW = Fonts.SEMIBOLD.getWidth(statusWord, TEXT_SIZE);
            float gap = MODULE_NOTIFY_SEGMENT_GAP_PX;
            return notifWidth(labelW + gap + nameW + gap + statusW, MODULE_LEFT_GUTTER);
        }
    }

    private abstract static class BaseNotification {
        long startTime;
        float x, y;
        final Animation scaleAnimation;

        BaseNotification() {
            this.scaleAnimation = new Animation(300L, Easing.BACK_OUT);
            this.startTime = System.currentTimeMillis();
            this.y = mc.getWindow().getScaledHeight();
        }

        abstract void render(CustomDrawContext ctx, float x, float y, Theme theme, float alpha, float darkness);
        abstract float getWidth();
    }
}
