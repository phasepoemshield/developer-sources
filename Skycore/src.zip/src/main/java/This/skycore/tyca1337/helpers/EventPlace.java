package This.skycore.tyca1337.helpers;

import com.darkmagician6.eventapi.events.Event;
import lombok.AllArgsConstructor;
import lombok.Getter;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;

@Getter
@AllArgsConstructor
public class EventPlace implements Event {
    private final Block block;
    private final BlockPos pos;
}
