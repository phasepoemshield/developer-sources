package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.render.EventRender3D;
import This.skycore.tyca1337.client.handlers.richidog.RichiBrain;
import This.skycore.tyca1337.client.handlers.richidog.RichiDogModel;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.ModeSetting;
import This.skycore.util.interfaces.IMinecraft;

@ModuleAnnotation(
        name = "Pets",
        category = Category.RENDER,
        description = "Питомец-собака рядом с игроком"
)
public final class Pets extends Module implements IMinecraft {

    public static final Pets INSTANCE = new Pets();

    private final ModeSetting variant = new ModeSetting("Вид", new String[]{"Такса", "DJ"});

    private RichiDogModel model;
    private final RichiBrain brain = new RichiBrain();

    private Pets() {
    }

    @Override
    public void onEnable() {
        this.brain.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.brain.reset();
        super.onDisable();
    }

    @EventTarget
    private void onUpdate(EventUpdate e) {
        if (!isEnabled() || mc.player == null) {
            return;
        }
        brain.setEntity(mc.player);
        brain.onUpdate();
    }

    @EventTarget
    private void onWorld(EventRender3D e) {
        if (!isEnabled() || mc.player == null || mc.world == null) {
            return;
        }

        if (model == null) {
            model = new RichiDogModel(RichiDogModel.getTexturedModelData().createModel());
        }
        if (Double.isNaN(brain.getPos().x) || Double.isNaN(brain.getPos().y) || Double.isNaN(brain.getPos().z)) {
            return;
        }

        MatrixStack matrices = e.getMatrix();
        float partial = e.getPartialTicks();
        float age = mc.player.age + partial;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();

        matrices.push();
        // Render in camera-relative coordinates to avoid drifting into huge world offsets.
        matrices.translate(brain.getPos().x - cam.x, brain.getPos().y - cam.y, brain.getPos().z - cam.z);

        model.setRotationAngles(age, brain);
        Identifier tex = variant.is("DJ")
                ? SkyCore.id("textures/entity/richidog/djekrussel.png")
                : SkyCore.id("textures/entity/richidog/taksa.png");

        VertexConsumerProvider consumers = mc.getBufferBuilders().getEntityVertexConsumers();
        int light = 15728880;
        model.render(matrices, consumers, light, net.minecraft.client.render.OverlayTexture.DEFAULT_UV, tex, brain, age);

        matrices.pop();
    }
}
