package This.skycore.tyca1337.helpers;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;

public interface QuickImports {
    MinecraftClient mc = MinecraftClient.getInstance();
    Tessellator tessellator = Tessellator.getInstance();
}
