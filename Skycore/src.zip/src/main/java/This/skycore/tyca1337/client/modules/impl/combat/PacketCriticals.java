package This.skycore.tyca1337.client.modules.impl.combat;

import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(
        name = "Criticals",
        category = Category.COMBAT,
        description = "Всегда даёт критический удар"
)
public final class PacketCriticals extends Module {

    public static final PacketCriticals INSTANCE = new PacketCriticals();
}
