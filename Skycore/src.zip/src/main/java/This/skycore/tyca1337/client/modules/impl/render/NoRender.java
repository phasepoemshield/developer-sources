package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.util.List;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.render.EventCamera;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.MultiBooleanSetting;

@ModuleAnnotation(
   name = "NoRender",
   category = Category.RENDER,
   description = "Убирает лишние элементы с экрана"
)
public final class NoRender extends Module {
   public static final NoRender INSTANCE = new NoRender();
   private final MultiBooleanSetting settings = MultiBooleanSetting.create(
           "Убрать",
           List.of("Огонь", "Плохие эффекты", "Камера клип", "Интерполяция руки")
   );

   @Native
   public boolean isRemoveFire() {
      return this.isEnabled() && this.settings.isEnable(0);
   }

   @Native
   public boolean isRemoveBadEffect() {
      return this.isEnabled() && this.settings.isEnable(1);
   }

   @Native
   public boolean isRemoveHandInterpolation() {
      return this.isEnabled() && this.settings.isEnable("Интерполяция руки");
   }

   @EventTarget
   @Native
   private void onCamera(EventCamera e) {
      e.setCameraClip(this.settings.isEnable("Камера клип"));
      e.cancel();
   }
}
