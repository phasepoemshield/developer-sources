package This.skycore.tyca1337.client.Interface.elements.component;

import This.nexusguard.UserProfile;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;

public class WatermarkComponent extends DraggableHudElement {
    public WatermarkComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Native
    public void render(CustomDrawContext ctx) {
        float posX = this.getX();
        float posY = this.getY();

        String titleText = "SkyCore";
        String icon = "a";
        String nameText = UserProfile.username;
        String iconName = "b";
        String ipIcon = "g";
        String ip = mc.getNetworkHandler() != null && mc.getNetworkHandler().getServerInfo() != null
                ? mc.getNetworkHandler().getServerInfo().address
                : "localhost";

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA logoColor = theme.getColor();
        ColorRGBA bgColor = ColorUtil.darkenBrightness(logoColor, 0.1f);
        ColorRGBA iconColor = logoColor;
        ColorRGBA textColor = ColorRGBA.WHITE;
        ColorRGBA separatorColor = new ColorRGBA(38, 38, 42, 195);

        float mediumTextSize = 6.5f;
        float contentOffsetY = -0.85f;
        float iconDrawSize = 7.0f;

        float skyCoreWidth = Fonts.MEDIUM.getWidth(titleText, mediumTextSize);
        float userWidth = Fonts.MEDIUM.getWidth(nameText, mediumTextSize);
        float ipWidth = Fonts.MEDIUM.getWidth(ip, mediumTextSize);

        float totalHeight = 44.0f / 2f;
        float padding = 12.0f / 2f;
        float gap = 12.0f / 2f;
        float innerGap = 8.0f / 2f;
        float smallGap = 4.0f / 2f;
        float borderRadius = 6.0f;
        float iconSize = 14.0f / 2f;
        float fontSize = 12.0f / 2f;
        float separatorWidth = 0.61f;
        float separatorHeight = 21f;

        float leftSectionWidth = iconSize + innerGap + skyCoreWidth;
        float rightSectionWidth = iconSize + smallGap + userWidth + gap + gap + iconSize + smallGap + ipWidth;
        float totalWidth = padding + leftSectionWidth + gap + separatorWidth + gap + rightSectionWidth + padding;

        ctx.drawRoundedRect(posX, posY, totalWidth, totalHeight, BorderRadius.all(borderRadius), bgColor);

        float currentX = posX + padding;
        float textY = posY + (totalHeight - fontSize) / 2f + 1.5f + contentOffsetY;
        float iconRowY1 = posY + (totalHeight - iconSize) / 2f + 2f + contentOffsetY;
        float iconRowY2 = posY + (totalHeight - iconSize) / 2f + 2.5f + contentOffsetY;
        float dotY = posY + totalHeight / 2f - 1f + contentOffsetY;

        ctx.drawText(Fonts.SKYCORE.getFont(iconDrawSize), icon, currentX, iconRowY1, iconColor);

        currentX += iconSize + innerGap;

        ctx.drawText(Fonts.MEDIUM.getFont(mediumTextSize), titleText, currentX, textY, textColor);

        currentX += skyCoreWidth + gap;

        ctx.drawRect(currentX, posY + 0.6f + contentOffsetY, separatorWidth - 0.5f, separatorHeight, separatorColor);

        currentX += separatorWidth + gap;

        ctx.drawText(Fonts.SKYCORE.getFont(iconDrawSize), iconName, currentX, iconRowY2, iconColor);

        currentX += iconSize + smallGap;

        float nameStartX = currentX;
        ctx.drawText(Fonts.MEDIUM.getFont(mediumTextSize), nameText, nameStartX, textY, textColor);
        float nameEndX = nameStartX + userWidth;
        float ipIconStartX = nameEndX + gap + gap;
        float dotCenterX = nameEndX + gap;
        ctx.drawRoundedRect(dotCenterX - 1.5f, dotY, 3f, 3f, BorderRadius.all(0.5f), ColorRGBA.WHITE.mulAlpha(0.1f));

        currentX = ipIconStartX;
        ctx.drawText(Fonts.SKYCORE.getFont(iconDrawSize), ipIcon, currentX, iconRowY2, iconColor);

        currentX += iconSize + smallGap;

        ctx.drawText(Fonts.MEDIUM.getFont(mediumTextSize), ip, currentX, textY, textColor);

        this.width = totalWidth;
        this.height = totalHeight;
    }
}
