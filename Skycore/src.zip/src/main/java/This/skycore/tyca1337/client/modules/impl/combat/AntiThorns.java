package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import This.skycore.base.events.impl.player.EventThornsDamage;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(
        name = "AntiThorns",
        category = Category.COMBAT,
        description = "Убирает урон и откидывание от шипов"
)
public final class AntiThorns extends Module {

    public static final AntiThorns INSTANCE = new AntiThorns();

    private static final int THORNS_VELOCITY_SUPPRESS_TICKS = 8;
    private static final int THORNS_ENTITY_STATUS_OPCODE = 33;

    private int suppressVelocityTicks;

    private AntiThorns() {
    }

    @EventTarget
    public void onThornsDamage(EventThornsDamage event) {
        if (shouldCancelThornsDamage(event.getAttacker())) {
            event.cancel();
        }
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (!event.isReceive() || mc.player == null || mc.world == null) {
            return;
        }

        if (event.getPacket() instanceof EntityStatusS2CPacket packet) {
            Entity entity = packet.getEntity(mc.world);
            if (packet.getStatus() == THORNS_ENTITY_STATUS_OPCODE
                    && entity == mc.player
                    && isLocalPlayerElytraFlying()) {
                armVelocitySuppress();
            }
            return;
        }

        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket packet
                && shouldCancelVelocityPacket(packet)) {
            event.cancel();
            resetVelocitySuppress();
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        tickSuppressTimer();
    }

    public void tickSuppressTimer() {
        if (mc.player == null || !isLocalPlayerElytraFlying()) {
            resetVelocitySuppress();
            return;
        }

        if (suppressVelocityTicks > 0) {
            --suppressVelocityTicks;
        }
    }

    public boolean shouldCancelThornsDamage(Entity attacker) {
        if (!isEnabled() || mc.player == null || attacker != mc.player) {
            return false;
        }

        if (isLocalPlayerElytraFlying()) {
            armVelocitySuppress();
        }

        return true;
    }

    public boolean shouldCancelVelocityPacket(EntityVelocityUpdateS2CPacket packet) {
        return isVelocitySuppressActive()
                && packet != null
                && mc.player != null
                && packet.getEntityId() == mc.player.getId();
    }

    public boolean isVelocitySuppressActive() {
        return suppressVelocityTicks > 0 && isLocalPlayerElytraFlying();
    }

    public int getSuppressVelocityTicks() {
        return suppressVelocityTicks;
    }

    public void armVelocitySuppress() {
        suppressVelocityTicks = THORNS_VELOCITY_SUPPRESS_TICKS;
    }

    public void resetVelocitySuppress() {
        suppressVelocityTicks = 0;
    }

    @Override
    public void onEnable() {
        resetVelocitySuppress();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        resetVelocitySuppress();
        super.onDisable();
    }

    private boolean isLocalPlayerElytraFlying() {
        LivingEntity player = mc.player;
        return player != null && player.isGliding();
    }
}
