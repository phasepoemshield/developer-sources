package This.skycore.tyca1337.client.Interface.elements.component;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;

public class PotionsComponent extends DraggableHudElement {

    private static final Map<String, String> EFFECT_TRANSLATIONS = new HashMap<>();

    static {
        EFFECT_TRANSLATIONS.put("effect.minecraft.speed", "Скорость");
        EFFECT_TRANSLATIONS.put("effect.minecraft.slowness", "Медлительность");
        EFFECT_TRANSLATIONS.put("effect.minecraft.haste", "Спешка");
        EFFECT_TRANSLATIONS.put("effect.minecraft.mining_fatigue", "Усталость");
        EFFECT_TRANSLATIONS.put("effect.minecraft.strength", "Сила");
        EFFECT_TRANSLATIONS.put("effect.minecraft.instant_health", "Моментальное лечение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.instant_damage", "Моментальный урон");
        EFFECT_TRANSLATIONS.put("effect.minecraft.jump_boost", "Прыгучесть");
        EFFECT_TRANSLATIONS.put("effect.minecraft.nausea", "Тошнота");
        EFFECT_TRANSLATIONS.put("effect.minecraft.regeneration", "Регенерация");
        EFFECT_TRANSLATIONS.put("effect.minecraft.resistance", "Сопротивление");
        EFFECT_TRANSLATIONS.put("effect.minecraft.fire_resistance", "Огнестойкость");
        EFFECT_TRANSLATIONS.put("effect.minecraft.water_breathing", "Подводное дыхание");
        EFFECT_TRANSLATIONS.put("effect.minecraft.invisibility", "Невидимость");
        EFFECT_TRANSLATIONS.put("effect.minecraft.blindness", "Слепота");
        EFFECT_TRANSLATIONS.put("effect.minecraft.night_vision", "Ночное зрение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.hunger", "Голод");
        EFFECT_TRANSLATIONS.put("effect.minecraft.weakness", "Слабость");
        EFFECT_TRANSLATIONS.put("effect.minecraft.poison", "Отравление");
        EFFECT_TRANSLATIONS.put("effect.minecraft.wither", "Иссушение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.health_boost", "Прилив здоровья");
        EFFECT_TRANSLATIONS.put("effect.minecraft.absorption", "Поглощение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.saturation", "Насыщение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.glowing", "Свечение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.levitation", "Левитация");
        EFFECT_TRANSLATIONS.put("effect.minecraft.luck", "Удача");
        EFFECT_TRANSLATIONS.put("effect.minecraft.unluck", "Невезение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.slow_falling", "Медленное падение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.conduit_power", "Мощь источника");
        EFFECT_TRANSLATIONS.put("effect.minecraft.dolphins_grace", "Грация дельфина");
        EFFECT_TRANSLATIONS.put("effect.minecraft.bad_omen", "Дурное знамение");
        EFFECT_TRANSLATIONS.put("effect.minecraft.hero_of_the_village", "Герой деревни");
    }

    private static final Map<String, Integer> EFFECT_ICON_COLORS = new HashMap<>();

    static {
        EFFECT_ICON_COLORS.put("effect.minecraft.speed", 0x7CA8FF);
        EFFECT_ICON_COLORS.put("effect.minecraft.slowness", 0x8A8A8A);
        EFFECT_ICON_COLORS.put("effect.minecraft.haste", 0xD9C043);
        EFFECT_ICON_COLORS.put("effect.minecraft.mining_fatigue", 0x4A4A4A);
        EFFECT_ICON_COLORS.put("effect.minecraft.strength", 0xFF6B6B);
        EFFECT_ICON_COLORS.put("effect.minecraft.instant_health", 0xFF8B8B);
        EFFECT_ICON_COLORS.put("effect.minecraft.instant_damage", 0x5C2E2E);
        EFFECT_ICON_COLORS.put("effect.minecraft.jump_boost", 0x9FFF7C);
        EFFECT_ICON_COLORS.put("effect.minecraft.nausea", 0x55A855);
        EFFECT_ICON_COLORS.put("effect.minecraft.regeneration", 0xFF6B9D);
        EFFECT_ICON_COLORS.put("effect.minecraft.resistance", 0x8A8A8A);
        EFFECT_ICON_COLORS.put("effect.minecraft.fire_resistance", 0xFF8B3D);
        EFFECT_ICON_COLORS.put("effect.minecraft.water_breathing", 0x7CA8FF);
        EFFECT_ICON_COLORS.put("effect.minecraft.invisibility", 0xF0F0F0);
        EFFECT_ICON_COLORS.put("effect.minecraft.blindness", 0x1A1A1A);
        EFFECT_ICON_COLORS.put("effect.minecraft.night_vision", 0x5C2E8C);
        EFFECT_ICON_COLORS.put("effect.minecraft.hunger", 0x5C3A2E);
        EFFECT_ICON_COLORS.put("effect.minecraft.weakness", 0x8A6B5C);
        EFFECT_ICON_COLORS.put("effect.minecraft.poison", 0x4A8A2E);
        EFFECT_ICON_COLORS.put("effect.minecraft.wither", 0x2A2A2A);
        EFFECT_ICON_COLORS.put("effect.minecraft.health_boost", 0xFF5555);
        EFFECT_ICON_COLORS.put("effect.minecraft.absorption", 0xFFD9A3);
        EFFECT_ICON_COLORS.put("effect.minecraft.saturation", 0xD9A36B);
        EFFECT_ICON_COLORS.put("effect.minecraft.glowing", 0xFFFF8B);
        EFFECT_ICON_COLORS.put("effect.minecraft.levitation", 0xA3A3A3);
        EFFECT_ICON_COLORS.put("effect.minecraft.luck", 0x55D955);
        EFFECT_ICON_COLORS.put("effect.minecraft.unluck", 0x8A4444);
        EFFECT_ICON_COLORS.put("effect.minecraft.slow_falling", 0xA3D9FF);
        EFFECT_ICON_COLORS.put("effect.minecraft.conduit_power", 0x5C8AA3);
        EFFECT_ICON_COLORS.put("effect.minecraft.dolphins_grace", 0x7CD9FF);
        EFFECT_ICON_COLORS.put("effect.minecraft.bad_omen", 0x2A1A1A);
        EFFECT_ICON_COLORS.put("effect.minecraft.hero_of_the_village", 0xFF8B3D);
    }

    private static final boolean SHOW_BAD_EFFECTS_DEFAULT = true;

    private final Animation ordinaryAlphaAnimation = new Animation(100L, 0.0F, Easing.LINEAR);
    private final Map<StatusEffect, Animation> ordinaryEffectAnimations = new HashMap<>();

    private int currentEffectIndex = 0;
    private long lastEffectSwitchTime = 0L;
    private static final long EFFECT_SWITCH_INTERVAL = 1000L;

    private static final float NAME_TEXT_SIZE = 6.5f;

    /** Смещение второй строки (время) от базовой линии названия; чуть ниже одной строки MEDIUM, чем ×2. */
    private static float durationOffsetY() {
        return Fonts.MEDIUM.getFont(NAME_TEXT_SIZE).height() * 1.75f + -0.1f;
    }

    public PotionsComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Native
    public void render(CustomDrawContext ctx) {
        if (mc.player == null) {
            return;
        }
        this.renderOrdinary(ctx);
    }

    private void renderOrdinary(CustomDrawContext ctx) {
        float posX = this.getX();
        float posY = this.getY();

        List<StatusEffectInstance> activeEffects = new ArrayList<>();
        boolean hasActive = false;

        for (StatusEffectInstance effectInstance : mc.player.getActiveStatusEffects().values()) {
            StatusEffect effect = effectInstance.getEffectType().value();
            if (!SHOW_BAD_EFFECTS_DEFAULT && effect.getCategory() == StatusEffectCategory.HARMFUL) {
                continue;
            }

            Animation anim = this.ordinaryEffectAnimations.computeIfAbsent(effect, k -> new Animation(100L, 0.0F, Easing.LINEAR));
            anim.update(1.0F);

            activeEffects.add(effectInstance);
            hasActive = true;
        }

        for (Map.Entry<StatusEffect, Animation> entry : this.ordinaryEffectAnimations.entrySet()) {
            boolean hasEffect = mc.player.getActiveStatusEffects().values().stream()
                    .anyMatch(e -> {
                        StatusEffect eff = e.getEffectType().value();
                        if (eff != entry.getKey()) {
                            return false;
                        }
                        return SHOW_BAD_EFFECTS_DEFAULT || eff.getCategory() != StatusEffectCategory.HARMFUL;
                    });
            if (!hasEffect) {
                entry.getValue().update(0.0F);
            }
        }

        boolean isChatOpen = mc.currentScreen instanceof ChatScreen;
        boolean show = isChatOpen || hasActive;

        this.ordinaryAlphaAnimation.update(show ? 1.0F : 0.0F);
        float globalAlpha = this.ordinaryAlphaAnimation.getValue();
        if (globalAlpha <= 0.01F) {
            this.width = 51.5f;
            this.height = 11f;
            return;
        }

        List<StatusEffect> currentIds = new ArrayList<>();
        for (StatusEffectInstance effectInstance : activeEffects) {
            currentIds.add(effectInstance.getEffectType().value());
        }
        this.ordinaryEffectAnimations.entrySet().removeIf(e ->
                !currentIds.contains(e.getKey())
                        && e.getValue().isDone()
                        && e.getValue().getValue() <= 0.01F
        );

        if (isChatOpen && activeEffects.isEmpty()) {
            this.renderPreviewMode(ctx, posX, posY, globalAlpha);
            return;
        }

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA cardBgBase = ColorUtil.darkenBrightness(theme.getColor(), 0.1f);

        float baseCardWidth = 51.5f;
        float cardHeight = 22f;
        float cardRadius = 5f;
        float cardPaddingX = 6f;
        float cardPaddingYTop = 3.5f;
        float cardPaddingYBottom = 4f;
        float cardGap = 5f;
        float iconSize = 13f;
        float iconTextGap = 3f;

        float currentY = posY;
        float maxCardWidth = baseCardWidth;

        for (StatusEffectInstance effectInstance : activeEffects) {
            StatusEffect effect = effectInstance.getEffectType().value();
            Animation itemAnim = this.ordinaryEffectAnimations.get(effect);
            if (itemAnim == null) {
                continue;
            }
            float animVal = itemAnim.getValue();
            if (animVal <= 0.01f) {
                continue;
            }

            float itemAlpha = animVal * globalAlpha;
            ColorRGBA nameColor = ColorRGBA.WHITE.mulAlpha(itemAlpha);
            ColorRGBA timeColor = ColorRGBA.WHITE.withAlpha((int)(64.0F * itemAlpha));

            String effectName = this.getEffectNameTranslated(effect, effectInstance.getAmplifier());
            String durationText = StatusEffectUtil.getDurationText(effectInstance, 1.0F, 20.0F).getString();

            float nameWidth = Fonts.REGULAR.getWidth(effectName, NAME_TEXT_SIZE);
            float timeWidth = Fonts.REGULAR.getWidth(durationText, NAME_TEXT_SIZE);
            float textWidth = Math.max(nameWidth, timeWidth);
            float cardWidth = Math.max(baseCardWidth, cardPaddingX + iconSize + iconTextGap + textWidth + cardPaddingX);
            maxCardWidth = Math.max(maxCardWidth, cardWidth);

            ColorRGBA bgColor = cardBgBase.mulAlpha(itemAlpha);
            ctx.drawRoundedRect(posX, currentY, cardWidth, cardHeight, BorderRadius.all(cardRadius), bgColor);

            float iconX = posX + cardPaddingX;
            float iconY = currentY + cardPaddingYTop + (cardHeight - cardPaddingYTop - cardPaddingYBottom - iconSize) / 2f;

            this.drawEffectIcon(ctx, effectInstance, iconX, iconY, iconSize, itemAlpha);

            float textX = iconX + iconSize + iconTextGap;
            float textY = currentY + cardPaddingYTop + 2.5f;

            ctx.drawText(Fonts.REGULAR.getFont(NAME_TEXT_SIZE), effectName, textX, textY, nameColor);
            ctx.drawText(Fonts.REGULAR.getFont(NAME_TEXT_SIZE), durationText, textX, textY + durationOffsetY(), timeColor);

            currentY += (cardHeight + cardGap) * animVal;
        }

        float totalHeight = activeEffects.size() * (cardHeight + cardGap) - cardGap;
        if (totalHeight < 0) {
            totalHeight = cardHeight;
        }

        this.width = maxCardWidth;
        this.height = Math.max(totalHeight, cardHeight);
    }

    private void renderPreviewMode(CustomDrawContext ctx, float posX, float posY, float globalAlpha) {
        List<String> effectKeys = new ArrayList<>(EFFECT_TRANSLATIONS.keySet());
        if (effectKeys.isEmpty()) {
            return;
        }

        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastEffectSwitchTime >= EFFECT_SWITCH_INTERVAL) {
            this.lastEffectSwitchTime = currentTime;
            this.currentEffectIndex = (this.currentEffectIndex + 1) % effectKeys.size();
        }

        String currentEffectKey = effectKeys.get(this.currentEffectIndex % effectKeys.size());
        String effectName = EFFECT_TRANSLATIONS.getOrDefault(currentEffectKey, "Эффект")
                + " 2";

        float baseCardWidth = 51.5f;
        float cardHeight = 22f;
        float cardRadius = 5f;
        float cardPaddingX = 6f;
        float cardPaddingYTop = 3.5f;
        float cardPaddingYBottom = 4f;
        float iconSize = 13f;
        float iconTextGap = 3f;

        String durationText = "1:23";

        float nameWidth = Fonts.REGULAR.getWidth(effectName, NAME_TEXT_SIZE);
        float timeWidth = Fonts.REGULAR.getWidth(durationText, NAME_TEXT_SIZE);
        float textWidth = Math.max(nameWidth, timeWidth);
        float cardWidth = Math.max(baseCardWidth, cardPaddingX + iconSize + iconTextGap + textWidth + cardPaddingX);

        ColorRGBA nameColor = ColorRGBA.WHITE.mulAlpha(globalAlpha);
        ColorRGBA timeColor = ColorRGBA.WHITE.withAlpha((int)(64.0F * globalAlpha));

        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA bgColor = ColorUtil.darkenBrightness(theme.getColor(), 0.1f).mulAlpha(globalAlpha);

        ctx.drawRoundedRect(posX, posY, cardWidth, cardHeight, BorderRadius.all(cardRadius), bgColor);

        float iconX = posX + cardPaddingX;
        float iconY = posY + cardPaddingYTop + (cardHeight - cardPaddingYTop - cardPaddingYBottom - iconSize) / 2f;

        String path = currentEffectKey.replace("effect.minecraft.", "");
        Identifier effectRegistryId = Identifier.of("minecraft", path);
        StatusEffect previewEffect = Registries.STATUS_EFFECT.get(effectRegistryId);

        if (previewEffect != null) {
            Identifier tex = Identifier.of("minecraft", "textures/mob_effect/" + path + ".png");
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, globalAlpha);
            ctx.drawTexture(tex, iconX, iconY, iconSize, iconSize, ColorRGBA.WHITE.withAlpha(globalAlpha * 255.0F));
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        } else {
            this.drawPreviewColorIcon(ctx, iconX, iconY, iconSize, globalAlpha, currentEffectKey);
        }

        float textX = iconX + iconSize + iconTextGap;
        float textY = posY + cardPaddingYTop + 2.5f;

        ctx.drawText(Fonts.REGULAR.getFont(NAME_TEXT_SIZE), effectName, textX, textY, nameColor);
        ctx.drawText(Fonts.REGULAR.getFont(NAME_TEXT_SIZE), durationText, textX, textY + durationOffsetY(), timeColor);

        this.width = cardWidth;
        this.height = cardHeight;
    }

    private void drawPreviewColorIcon(CustomDrawContext ctx, float x, float y, float size, float alpha, String effectKey) {
        int rgb = EFFECT_ICON_COLORS.getOrDefault(effectKey, 0x8A8A8A);
        int r = rgb >> 16 & 255;
        int g = rgb >> 8 & 255;
        int b = rgb & 255;
        ColorRGBA c = new ColorRGBA(r, g, b, (int)(255.0F * alpha));
        ctx.drawRoundedRect(x, y, size, size, BorderRadius.all(2.0f), c);
    }

    private void drawEffectIcon(CustomDrawContext ctx, StatusEffectInstance effect, float x, float y, float size, float alpha) {
        if (effect == null) {
            return;
        }
        Identifier icon = this.getEffectIcon(effect);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
        ctx.drawTexture(icon, x, y, size, size, ColorRGBA.WHITE.withAlpha(alpha * 255.0F));
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private Identifier getEffectIcon(StatusEffectInstance effect) {
        String id = effect.getTranslationKey()
                .replace("effect.minecraft.", "")
                .replace("effect.", "");
        return Identifier.of("minecraft", "textures/mob_effect/" + id + ".png");
    }

    private String getEffectNameTranslated(StatusEffect effect, int amplifier) {
        String key = effect.getTranslationKey();
        String name = EFFECT_TRANSLATIONS.getOrDefault(key, I18n.translate(key));
        if (amplifier > 0) {
            name += " " + (amplifier + 1);
        }
        return name;
    }
}
