package This.skycore.tyca1337.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(
        name = "AutoTool",
        category = Category.PLAYER,
        description = "Берёт лучший инструмент для ломания блока"
)
public final class AutoTool extends Module {
    public static final AutoTool INSTANCE = new AutoTool();

    private int oldSlot = -1;
    private boolean swapping;
    private int visualSlot = -1;
    private int suppressTicks;
    private int postRestoreTicks;

    private AutoTool() {}

    @EventTarget
    @Native
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        if (this.suppressTicks > 0) {
            this.suppressTicks--;
            suppressHeldItemTooltip();
        }
        if (this.postRestoreTicks > 0) {
            this.postRestoreTicks--;
            suppressHeldItemTooltip();
            if (this.postRestoreTicks == 0) {
                this.visualSlot = -1;
            }
        }

        if (mc.crosshairTarget != null && mc.options.attackKey.isPressed()) {
            if (mc.crosshairTarget instanceof BlockHitResult hit) {
                BlockPos pos = hit.getBlockPos();
                if (pos == null) return;

                BlockState state = mc.world.getBlockState(pos);
                int bestSlot = findBestSlot(state);
                if (bestSlot == -1) {
                    return;
                }
                swapping = true;
                if (oldSlot == -1) {
                    oldSlot = mc.player.getInventory().selectedSlot;
                }
                if (bestSlot != oldSlot) {
                    visualSlot = oldSlot;
                } else {
                    visualSlot = -1;
                }
                this.suppressTicks = 4;
                this.postRestoreTicks = 0;
                suppressHeldItemTooltip();
                swapToSlot(bestSlot);
            }
        } else if (swapping) {
            int restore = oldSlot;
            swapToSlot(restore);
            if (restore >= 0 && restore < 9) {
                this.visualSlot = restore;
                this.postRestoreTicks = 10;
            } else {
                this.visualSlot = -1;
            }
            this.suppressTicks = 6;
            suppressHeldItemTooltip();
            oldSlot = -1;
            swapping = false;
        }
    }

    private static void suppressHeldItemTooltip() {
        if (mc != null && mc.inGameHud != null) {
            mc.inGameHud.heldItemTooltipFade = 0;
        }
    }

    private void swapToSlot(int slot) {
        if (slot < 0 || slot > 8 || mc.player == null) return;

        mc.player.getInventory().selectedSlot = slot;
    }

    private void resetState() {
        oldSlot = -1;
        swapping = false;
        visualSlot = -1;
        postRestoreTicks = 0;
        suppressTicks = Math.max(suppressTicks, 4);
        suppressHeldItemTooltip();
    }

    private int findBestSlot(BlockState state) {
        if (mc.player == null) return -1;

        int bestSlot = -1;
        float bestSpeed = 1.0F;

        for (int slot = 0; slot < 9; ++slot) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (!stack.isEmpty()) {
                float speed = stack.getMiningSpeedMultiplier(state);
                if (speed > bestSpeed) {
                    bestSpeed = speed;
                    bestSlot = slot;
                }
            }
        }

        return bestSlot;
    }

    public static int getBest(BlockPos pos) {
        if (pos == null || mc.player == null || mc.world == null) return -1;
        BlockState state = mc.world.getBlockState(pos);
        return INSTANCE.findBestSlot(state);
    }

    public static int getVisualSlot() {
        if (!INSTANCE.isEnabled()) return -1;
        return INSTANCE.visualSlot;
    }

    public static boolean shouldSuppressHeldItemTooltip() {
        return INSTANCE.isEnabled() && (INSTANCE.swapping || INSTANCE.suppressTicks > 0 || INSTANCE.visualSlot != -1 || INSTANCE.postRestoreTicks > 0);
    }

    @Override
    public void onDisable() {
        resetState();
        super.onDisable();
    }
}
