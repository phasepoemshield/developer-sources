package This.skycore.tyca1337.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import This.nexusguard.protection.annotations.Native;
import This.skycore.SkyCore;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.events.impl.render.EventRender2D;
import This.skycore.base.events.impl.render.EventRender3D;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.render.ShaderUtil;
import This.skycore.util.render.RenderUtil;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;
import This.skycore.util.render.display.shader.CustomRenderTarget;
import This.skycore.util.render.level.Render3DUtil;

/**
 * Как legacy SkyCore BlockOutline: маска блока в FBO + {@code ovbew} на весь экран. Без лишних слайдеров.
 */
@SuppressWarnings("all")
@ModuleAnnotation(
        name = "BlockOutline",
        category = Category.RENDER,
        description = "Обводит наведенный блок"
)
public class BlockOutline extends Module implements IMinecraft {
    public static final BlockOutline INSTANCE = new BlockOutline();

    private static final float WAVE_SPEED = 1.2f;
    private static final float WAVE_FREQUENCY = 1.0f;
    private static final float OUTLINE_WIDTH = 0.1f;
    private static final float GLOW_STRENGTH = 10.0f;
    private static final float FILL_STRENGTH = 0.6f;
    private static final float SHADER_ALPHA = 2.0f;

    private final Animation stretchAnim = new Animation(170L, 1.0F, Easing.CUBIC_OUT);
    private BlockPos lastBlock;
    private Box mirrorBox;
    private Box targetBox;
    private final CustomRenderTarget maskBuffer = new CustomRenderTarget(false);

    private BlockOutline() {
    }

    @EventTarget
    @Native
    public void onRender3D(EventRender3D e) {
        if (!this.isEnabled() || mc.player == null || mc.world == null) {
            this.clearMaskState();
            return;
        }

        HitResult hitResult = mc.crosshairTarget;
        if (hitResult == null || hitResult.getType() != HitResult.Type.BLOCK) {
            this.clearMaskState();
            return;
        }

        BlockHitResult blockHitResult = (BlockHitResult) hitResult;
        BlockPos blockPos = blockHitResult.getBlockPos();

        if (mc.world.getBlockState(blockPos).isAir()) {
            this.clearMaskState();
            return;
        }

        VoxelShape voxelShape = mc.world.getBlockState(blockPos).getOutlineShape(mc.world, blockPos);
        Box currentWorldBB = voxelShape.isEmpty() ? new Box(blockPos) : voxelShape.getBoundingBox().offset(blockPos);

        if (ShaderUtil.isBlockOutlineReady()) {
            if (this.lastBlock == null || this.mirrorBox == null || this.targetBox == null) {
                this.lastBlock = blockPos;
                this.mirrorBox = currentWorldBB;
                this.targetBox = currentWorldBB;
                this.stretchAnim.setValue(1.0F);
            } else if (!blockPos.equals(this.lastBlock)) {
                float t = this.stretchAnim.getValue();
                Box interpolated = lerpBox(this.mirrorBox, this.targetBox, t);
                this.lastBlock = blockPos;
                this.mirrorBox = interpolated;
                this.targetBox = currentWorldBB;
                this.stretchAnim.setValue(0.0F);
            } else {
                this.targetBox = currentWorldBB;
            }

            this.stretchAnim.update(1.0F);
            float animT = this.stretchAnim.getValue();
            Box animatedWorldBB = lerpBox(this.mirrorBox, this.targetBox, animT);

            Vec3d camPos = mc.gameRenderer.getCamera().getPos();
            // Чуть расширяем AABB — контур ложится на грань блока, меньше Z-fight с геометрией.
            Box bb = animatedWorldBB.expand(0.0025D).offset(-camPos.x, -camPos.y, -camPos.z);

            int[] savedViewport = new int[4];
            GL11.glGetIntegerv(GL11.GL_VIEWPORT, savedViewport);

            this.maskBuffer.setup(true);
            int vw = this.maskBuffer.textureWidth;
            int vh = this.maskBuffer.textureHeight;
            RenderSystem.viewport(0, 0, vw, vh);

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

            MatrixStack ms = e.getMatrix();
            BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            int white = 0xFFFFFFFF;
            this.emitBox(ms.peek(), buffer, bb, white);
            BufferRenderer.drawWithGlobalProgram(buffer.end());

            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            this.maskBuffer.stop();
            GL11.glViewport(savedViewport[0], savedViewport[1], savedViewport[2], savedViewport[3]);
            mc.getFramebuffer().beginWrite(true);
            return;
        }

        this.renderLegacySolidOutline(blockPos);
    }

    private void clearMaskState() {
        this.lastBlock = null;
        this.mirrorBox = null;
        this.targetBox = null;
    }

    private void renderLegacySolidOutline(BlockPos blockPos) {
        ColorRGBA themeColor = SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor();
        ColorRGBA themeSecondColor = SkyCore.getInstance().getThemeManager().getCurrentTheme().getSecondColor();

        int color1 = themeColor.getRGB();
        int color2 = themeSecondColor.getRGB();

        int outlineColor1 = ColorUtil.multAlpha(color1, 1.0F);
        int outlineColor2 = ColorUtil.multAlpha(color2, 1.0F);
        int fillColor1 = ColorUtil.multAlpha(color1, 0.3F);
        int fillColor2 = ColorUtil.multAlpha(color2, 0.3F);

        Box blockBox = new Box(blockPos).expand(0.001D);

        double x1 = blockBox.minX;
        double y1 = blockBox.minY;
        double z1 = blockBox.minZ;
        double x2 = blockBox.maxX;
        double y2 = blockBox.maxY;
        double z2 = blockBox.maxZ;
        Render3DUtil.drawQuad(new Vec3d(x1, y1, z1), new Vec3d(x2, y1, z1), new Vec3d(x2, y1, z2), new Vec3d(x1, y1, z2), fillColor1, true);

        Render3DUtil.drawQuad(new Vec3d(x1, y2, z1), new Vec3d(x1, y2, z2), new Vec3d(x2, y2, z2), new Vec3d(x2, y2, z1), fillColor2, true);
        Render3DUtil.drawGradientQuad(new Vec3d(x1, y1, z1), new Vec3d(x1, y2, z1), new Vec3d(x2, y2, z1), new Vec3d(x2, y1, z1), fillColor1, fillColor2, true);
        Render3DUtil.drawGradientQuad(new Vec3d(x2, y1, z1), new Vec3d(x2, y2, z1), new Vec3d(x2, y2, z2), new Vec3d(x2, y1, z2), fillColor1, fillColor2, true);
        Render3DUtil.drawGradientQuad(new Vec3d(x1, y1, z2), new Vec3d(x2, y1, z2), new Vec3d(x2, y2, z2), new Vec3d(x1, y2, z2), fillColor1, fillColor2, true);
        Render3DUtil.drawGradientQuad(new Vec3d(x1, y1, z1), new Vec3d(x1, y1, z2), new Vec3d(x1, y2, z2), new Vec3d(x1, y2, z1), fillColor1, fillColor2, true);

        float lw = 2.0F;
        Render3DUtil.drawLine(x1, y1, z1, x2, y1, z1, outlineColor1, lw, true);
        Render3DUtil.drawLine(x2, y1, z1, x2, y1, z2, outlineColor1, lw, true);
        Render3DUtil.drawLine(x2, y1, z2, x1, y1, z2, outlineColor1, lw, true);
        Render3DUtil.drawLine(x1, y1, z2, x1, y1, z1, outlineColor1, lw, true);

        Render3DUtil.drawLine(new Vec3d(x1, y1, z1), new Vec3d(x1, y2, z1), outlineColor1, outlineColor2, lw, true);
        Render3DUtil.drawLine(new Vec3d(x2, y1, z1), new Vec3d(x2, y2, z1), outlineColor1, outlineColor2, lw, true);
        Render3DUtil.drawLine(new Vec3d(x1, y1, z2), new Vec3d(x1, y2, z2), outlineColor1, outlineColor2, lw, true);
        Render3DUtil.drawLine(new Vec3d(x2, y1, z2), new Vec3d(x2, y2, z2), outlineColor1, outlineColor2, lw, true);

        Render3DUtil.drawLine(x1, y2, z1, x2, y2, z1, outlineColor2, lw, true);
        Render3DUtil.drawLine(x2, y2, z1, x2, y2, z2, outlineColor2, lw, true);
        Render3DUtil.drawLine(x2, y2, z2, x1, y2, z2, outlineColor2, lw, true);
        Render3DUtil.drawLine(x1, y2, z2, x1, y2, z1, outlineColor2, lw, true);
    }

    private void emitBox(MatrixStack.Entry entry, BufferBuilder buffer, Box bb, int color) {
        double x1 = bb.minX;
        double y1 = bb.minY;
        double z1 = bb.minZ;
        double x2 = bb.maxX;
        double y2 = bb.maxY;
        double z2 = bb.maxZ;

        Render3DUtil.vertexQuad(entry, buffer, new Vec3d(x1, y1, z1), new Vec3d(x1, y1, z2), new Vec3d(x2, y1, z2), new Vec3d(x2, y1, z1), color);
        Render3DUtil.vertexQuad(entry, buffer, new Vec3d(x1, y2, z1), new Vec3d(x2, y2, z1), new Vec3d(x2, y2, z2), new Vec3d(x1, y2, z2), color);
        Render3DUtil.vertexQuad(entry, buffer, new Vec3d(x1, y1, z1), new Vec3d(x1, y2, z1), new Vec3d(x2, y2, z1), new Vec3d(x2, y1, z1), color);
        Render3DUtil.vertexQuad(entry, buffer, new Vec3d(x2, y1, z1), new Vec3d(x2, y2, z1), new Vec3d(x2, y2, z2), new Vec3d(x2, y1, z2), color);
        Render3DUtil.vertexQuad(entry, buffer, new Vec3d(x1, y1, z2), new Vec3d(x2, y1, z2), new Vec3d(x2, y2, z2), new Vec3d(x1, y2, z2), color);
        Render3DUtil.vertexQuad(entry, buffer, new Vec3d(x1, y1, z1), new Vec3d(x1, y1, z2), new Vec3d(x1, y2, z2), new Vec3d(x1, y2, z1), color);
    }

    private static Box lerpBox(Box a, Box b, float t) {
        t = Math.max(0.0F, Math.min(1.0F, t));
        return new Box(
                lerp(a.minX, b.minX, t),
                lerp(a.minY, b.minY, t),
                lerp(a.minZ, b.minZ, t),
                lerp(a.maxX, b.maxX, t),
                lerp(a.maxY, b.maxY, t),
                lerp(a.maxZ, b.maxZ, t)
        );
    }

    private static double lerp(double u, double v, float t) {
        return u + (v - u) * t;
    }

    @EventTarget
    @Native
    public void onRender2D(EventRender2D event) {
        if (!this.isEnabled() || mc.world == null) {
            return;
        }
        if (!ShaderUtil.isBlockOutlineReady()) {
            return;
        }
        if (this.lastBlock == null || this.mirrorBox == null || this.targetBox == null) {
            return;
        }

        int fbW = mc.getFramebuffer().textureWidth;
        int fbH = mc.getFramebuffer().textureHeight;
        int texW = this.maskBuffer.textureWidth;
        int texH = this.maskBuffer.textureHeight;
        if (fbW <= 0 || fbH <= 0 || texW <= 0 || texH <= 0) {
            return;
        }

        ColorRGBA themeColor = SkyCore.getInstance().getThemeManager().getCurrentTheme().getColor();
        ColorRGBA themeSecondColor = SkyCore.getInstance().getThemeManager().getCurrentTheme().getSecondColor();
        ColorRGBA darkSecond = ColorUtil.darkenBrightness(themeSecondColor, 0.35f);
        float r1 = themeColor.getRed() / 255.0F;
        float g1 = themeColor.getGreen() / 255.0F;
        float b1 = themeColor.getBlue() / 255.0F;
        float r2 = darkSecond.getRed() / 255.0F;
        float g2 = darkSecond.getGreen() / 255.0F;
        float b2 = darkSecond.getBlue() / 255.0F;

        Matrix4f proj = new Matrix4f().setOrtho(0.0F, (float) fbW, (float) fbH, 0.0F, 1000.0F, 3000.0F);
        Matrix4f model = new Matrix4f().translation(0.0F, 0.0F, -2000.0F);
        Matrix4f mvp = proj.mul(model);

        int[] vp = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, vp);

        RenderSystem.disableDepthTest();
        GlStateManager._enableBlend();
        RenderSystem.defaultBlendFunc();

        GL11.glViewport(0, 0, fbW, fbH);

        ShaderUtil.LegacyGlProgram prog = ShaderUtil.blockOutlineProgram();
        prog.attach();
        prog.uniformMatrix4f("Transform", mvp);
        prog.uniform1i("uTex", 0);
        prog.uniform2f("texelSize", 1.0F / (float) texW, 1.0F / (float) texH);
        prog.uniform3f("color", r1, g1, b1);
        prog.uniform3f("color2", r2, g2, b2);
        prog.uniform1f("time", (float) ((System.currentTimeMillis() % 100000L) / 1000.0));
        prog.uniform1f("speed", WAVE_SPEED);
        prog.uniform1f("scale", WAVE_FREQUENCY);
        prog.uniform1f("outline", OUTLINE_WIDTH);
        prog.uniform1f("glow", GLOW_STRENGTH);
        prog.uniform1f("fill", FILL_STRENGTH);
        prog.uniform1f("alpha", SHADER_ALPHA);

        int maskTex = this.maskBuffer.getColorAttachment();
        if (maskTex <= 0) {
            prog.detach();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableDepthTest();
            GL11.glViewport(vp[0], vp[1], vp[2], vp[3]);
            return;
        }

        // RenderSystem.setShaderTexture сбрасывает пайплайн Minecraft и с legacy glUseProgram не гарантирует bind для sampler2D uTex — иначе на экране атлас предметов.
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, maskTex);
        RenderUtil.drawPreparedLegacyTexturedQuad((float) fbW, (float) fbH);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);

        prog.detach();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, mc.getFramebuffer().getColorAttachment());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();

        GL11.glViewport(vp[0], vp[1], vp[2], vp[3]);

        mc.getFramebuffer().beginWrite(true);
    }
}
