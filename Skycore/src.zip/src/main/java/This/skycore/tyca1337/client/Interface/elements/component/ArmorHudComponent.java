package This.skycore.tyca1337.client.Interface.elements.component;

import This.nexusguard.protection.annotations.Native;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.util.mixin.accessors.DrawContextAccessor;
import This.skycore.util.render.display.base.CustomDrawContext;
import net.minecraft.item.ItemStack;

public class ArmorHudComponent extends DraggableHudElement {

   public ArmorHudComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align) {
      super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
   }

   @Override
   @Native
   public void render(CustomDrawContext ctx) {
      if (mc.player == null) {
         return;
      }

      float slotSize = 18.0F;
      float spacing = 2.0F;
      float renderX = this.x;
      float renderY = this.y;

      for (int i = 0; i < 4; i++) {
         ItemStack armorStack = mc.player.getInventory().armor.get(3 - i);
         float itemX = renderX + i * (slotSize + spacing);

         if (!armorStack.isEmpty()) {
            ctx.pushMatrix();
            ctx.getMatrices().translate(itemX + 1.0F, renderY + 1.0F, 0.0F);
            ctx.drawItem(armorStack, 0, 0);
            ((DrawContextAccessor) ctx).callDrawItemBar(armorStack, 0, 0);
            ((DrawContextAccessor) ctx).callDrawCooldownProgress(armorStack, 0, 0);
            ctx.popMatrix();
         }
      }

      this.width = (slotSize + spacing) * 4.0F - spacing;
      this.height = slotSize;
   }
}
