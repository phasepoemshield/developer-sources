package This.skycore.tyca1337.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import This.skycore.SkyCore;
import This.skycore.base.events.impl.player.EventAttack;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(
        name = "NoFriendDamage",
        category = Category.COMBAT,
        description = "Убирает дамаг по друзьям"
)
public final class NoFriendDamage extends Module {

    public static final NoFriendDamage INSTANCE = new NoFriendDamage();

    private NoFriendDamage() {}

    @EventTarget
    public void onAttack(EventAttack event) {
        Entity target = event.getTarget();
        if (target instanceof PlayerEntity player) {
            String name = player.getName().getString();
            if (SkyCore.getInstance().getFriendManager().isFriend(name)) {
                event.setCancelled(true);
            }
        }
    }
}

