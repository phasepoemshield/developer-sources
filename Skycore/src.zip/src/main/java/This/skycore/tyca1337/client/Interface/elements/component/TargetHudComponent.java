package This.skycore.tyca1337.client.Interface.elements.component;

import This.skycore.SkyCore;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.ReadableScoreboardScore;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.animations.base.Animation;
import This.skycore.base.animations.base.Easing;
import This.skycore.base.font.Fonts;
import This.skycore.base.theme.Theme;
import This.skycore.tyca1337.client.Interface.elements.draggable.DraggableHudElement;
import This.skycore.tyca1337.client.modules.impl.combat.Aura;
import This.skycore.tyca1337.client.modules.impl.misc.NameProtect;
import This.skycore.tyca1337.client.modules.impl.misc.ScoreboardHealth;
import This.skycore.util.mixin.accessors.DrawContextAccessor;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.CustomDrawContext;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.base.color.ColorUtil;
import This.skycore.util.render.display.shader.DrawUtil;

/**
 * Target HUD — логика как legacy {@code sky.core.ui.Interface.elements.impl.TargetHudRender} (режим New).
 */
public class TargetHudComponent extends DraggableHudElement {

    private static final boolean ON_CROSSHAIR = false;
    private static final boolean GOLD_HEALTH = true;
    private static final boolean SHOW_ARMOR = true;

    private static final float MIN_PANEL_W = 190.0F / 2.0F;
    private static final float PANEL_H = 60.0F / 2.0F;
    private static final float PADDING = 10.0F / 2.0F;
    private static final float GAP = 10.0F / 2.0F;
    private static final float AVATAR = 40.0F / 2.0F;
    private static final float HEALTH_SIZE = 20.0F;
    /** Как legacy {@code drawCircle(..., thickness 1, ...)} — тонкое кольцо, не «колбаса». */
    private static final float RING_THICK = 1.15F;
    private static final float RING_OUTLINE = 0.9F;
    private static final float CORNER_R = 5.0F;
    private static final ColorRGBA ABSORB_GOLD = new ColorRGBA(255, 210, 0, 255);

    private final Animation hpMain = new Animation(150L, 0.0F, Easing.CUBIC_OUT);
    private final Animation hpTrail = new Animation(380L, 0.0F, Easing.LINEAR);
    private final Animation absMain = new Animation(150L, 0.0F, Easing.CUBIC_OUT);
    private final Animation absTrail = new Animation(380L, 0.0F, Easing.LINEAR);
    private final Animation fade = new Animation(200L, 0.0F, Easing.CUBIC_OUT);

    private Entity lastTarget;

    public TargetHudComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight,
                              float offsetX, float offsetY, DraggableHudElement.Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Native
    @Override
    public void render(CustomDrawContext ctx) {
        LivingEntity auraTarget = Aura.INSTANCE.getTarget();
        Entity target = this.resolveTarget(auraTarget);

        Entity forAnim = target != null ? target : this.lastTarget;
        if (forAnim instanceof LivingEntity living) {
            float hp = this.hudHealth(living);
            float ab = living.getAbsorptionAmount();
            if (target != null && target != this.lastTarget) {
                this.hpMain.setValue(hp);
                this.hpTrail.setValue(hp);
                this.absMain.setValue(ab);
                this.absTrail.setValue(ab);
            }
            this.hpMain.update(hp);
            this.hpTrail.update(hp);
            this.absMain.update(ab);
            this.absTrail.update(ab);
        }

        this.fade.update(target != null ? 1.0F : 0.0F);
        if (this.fade.getValue() <= 0.01F) {
            this.width = MIN_PANEL_W;
            this.height = PANEL_H;
            this.lastTarget = target != null ? target : this.lastTarget;
            return;
        }

        Entity draw = target != null ? target : this.lastTarget;
        if (draw instanceof LivingEntity living) {
            this.paint(ctx, living, this.fade.getValue());
        }

        this.lastTarget = target != null ? target : this.lastTarget;
    }

    private Entity resolveTarget(LivingEntity auraTarget) {
        if (ON_CROSSHAIR) {
            if (mc.currentScreen instanceof ChatScreen) {
                return mc.player;
            }
            HitResult ray = mc.crosshairTarget;
            if (ray instanceof EntityHitResult eer && eer.getEntity() instanceof LivingEntity le) {
                return le;
            }
            return auraTarget;
        }
        if (mc.currentScreen instanceof ChatScreen && auraTarget == null) {
            return mc.player;
        }
        return auraTarget;
    }

    private float hudHealth(LivingEntity entity) {
        if (!ScoreboardHealth.INSTANCE.isEnabled()) {
            return entity.getHealth();
        }
        if (!(entity instanceof PlayerEntity player)) {
            return entity.getHealth();
        }
        ScoreboardObjective obj = player.getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
        if (obj == null) {
            return entity.getHealth();
        }
        float tab;
        try {
            MutableText t = ReadableScoreboardScore.getFormattedScore(
                    player.getScoreboard().getScore(player, obj),
                    obj.getNumberFormatOr(StyledNumberFormat.EMPTY));
            tab = Float.parseFloat(ColorUtil.removeFormatting(t.getString()));
        } catch (Exception e) {
            return entity.getHealth();
        }
        float norm = entity.getHealth() + entity.getAbsorptionAmount();
        if (tab == Math.floor(norm)) {
            return entity.getHealth();
        }
        return Math.max(0.0F, tab);
    }

    private void paint(CustomDrawContext ctx, LivingEntity living, float a) {
        Theme theme = SkyCore.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA logo = theme.getColor();

        String cat = living instanceof PlayerEntity ? "Player" : this.stripOrMob(Text.translatable(living.getType().getTranslationKey()).getString());
        String name = living instanceof PlayerEntity pe ? NameProtect.getCustomName(pe.getGameProfile().getName()) : this.stripOrMob(living.getName().getString());
        float nameW = Fonts.REGULAR.getWidth(name, 6.5F);
        float minContent = AVATAR + GAP + nameW + GAP + HEALTH_SIZE + PADDING;
        float panelW = Math.max(MIN_PANEL_W, minContent + PADDING);

        float x = this.x;
        float y = this.y;
        ColorRGBA bg = ColorUtil.darkenBrightness(logo, 0.1f).mulAlpha(a);
        ctx.drawRoundedRect(x, y, panelW, PANEL_H, BorderRadius.all(CORNER_R), bg);

        float ax = x + PADDING;
        float ay = y + PADDING;
        if (living instanceof PlayerEntity pe) {
            DrawUtil.drawPlayerHeadWithRoundedShader(ctx.getMatrices(), this.skin(pe), ax, ay, AVATAR, BorderRadius.all(2.5F), ColorRGBA.WHITE.mulAlpha(a));
        } else {
            ctx.drawRoundedRect(ax, ay, AVATAR, AVATAR, BorderRadius.all(2.5F), ColorUtil.darkenBrightness(logo, 0.12f).mulAlpha(a));
        }

        float ix = ax + AVATAR + GAP;
        float iy = ay + 1.0F;

        ctx.drawText(Fonts.REGULAR.getFont(6.0F), cat, ix, iy , logo.mulAlpha(a));
        ctx.drawText(Fonts.REGULAR.getFont(6.5F), name, ix - 0.2f, iy + 6.5f, ColorRGBA.WHITE.mulAlpha(a));

        float maxHp = living.getMaxHealth();
        float absorb = living.getAbsorptionAmount();

        float healthX = x + panelW - HEALTH_SIZE - PADDING + 2.0F;
        if (SHOW_ARMOR && living instanceof PlayerEntity player) {
            this.armorRow(ctx, player, ix, iy + 28.0F / 2.0F, healthX - GAP, a);
        }

        float healthY = y + (PANEL_H - HEALTH_SIZE) / 2.0F;
        this.renderCircularHealth(ctx, healthX, healthY, maxHp, a, theme, absorb);

        this.width = panelW;
        this.height = PANEL_H;
    }

    private static String stripOrMob(String s) {
        if (s == null || s.isEmpty()) {
            return "Mob";
        }
        String t = Formatting.strip(s);
        return t == null || t.isEmpty() ? "Mob" : t;
    }

    /**
     * Как {@code TargetHudRender#renderCircularHealth}: обводка 360°, вторичное → HP → золото; углы 0…360·%.
     * Знаменатель дуг — {@code maxHealth}, не смешанный pool.
     */
    private void renderCircularHealth(CustomDrawContext ctx, float x, float y, float maxHealth, float a, Theme theme, float liveAbsorption) {
        float centerX = x + HEALTH_SIZE / 2.0F;
        float centerY = y + HEALTH_SIZE / 2.0F;
        float radius = HEALTH_SIZE / 2.0F - 2.0F;
        final float ang0 = 0.0F;

        ColorRGBA logo = theme.getColor();
        ColorRGBA borderColor = ColorRGBA.WHITE.mulAlpha(0.12f * a);
        DrawUtil.drawCircleOutline(ctx.getMatrices(), centerX, centerY, radius, RING_OUTLINE, borderColor);

        float mh = Math.max(0.01F, maxHealth);
        if (mh > 0.0F) {
            float secondaryPercent = Math.min(this.hpTrail.getValue() / mh, 1.0F);
            if (secondaryPercent > 0.01F) {
                ColorRGBA secondary = logo.mulAlpha(0.4F * a);
                DrawUtil.drawCircleArc(ctx.getMatrices(), centerX, centerY, radius, RING_THICK, ang0, ang0 + 360.0F * secondaryPercent, secondary);
            }
            float healthPercent = Math.min(this.hpMain.getValue() / mh, 1.0F);
            if (healthPercent > 0.01F) {
                DrawUtil.drawCircleArc(ctx.getMatrices(), centerX, centerY, radius, RING_THICK, ang0, ang0 + 360.0F * healthPercent, logo.mulAlpha(a));
            }
            boolean showGold = GOLD_HEALTH && (liveAbsorption > 0.01F || this.absMain.getValue() > 0.01F || this.absTrail.getValue() > 0.01F);
            if (showGold) {
                float secondaryAbsorptionPercent = Math.min(this.absTrail.getValue() / mh, 1.0F);
                if (secondaryAbsorptionPercent > 0.01F) {
                    ColorRGBA secGold = ColorUtil.darkenBrightness(ABSORB_GOLD, 0.4F).mulAlpha(0.65F * a);
                    DrawUtil.drawCircleArc(ctx.getMatrices(), centerX, centerY, radius, RING_THICK, ang0, ang0 + 360.0F * secondaryAbsorptionPercent, secGold);
                }
                float absorptionPercent = Math.min(this.absMain.getValue() / mh, 1.0F);
                if (absorptionPercent > 0.01F) {
                    DrawUtil.drawCircleArc(ctx.getMatrices(), centerX, centerY, radius, RING_THICK, ang0, ang0 + 360.0F * absorptionPercent, ABSORB_GOLD.mulAlpha(a));
                }
            }
        }

        String healthText = String.valueOf((int) this.hpMain.getValue());
        float fs = 6.5F;
        float maxTextWidth = Fonts.MEDIUM.getWidth("20", fs);
        float textWidth = Fonts.MEDIUM.getWidth(healthText, fs);
        float textHeight = Fonts.MEDIUM.getFont(fs).height();
        float blockX = centerX - maxTextWidth / 2.0F;
        float textX = blockX + (maxTextWidth - textWidth) / 2.0F;
        float textY = centerY - textHeight / 2.0F + 0.0F;
        ctx.drawText(Fonts.MEDIUM.getFont(fs), healthText, textX + 0.5f, textY + 0.3f, ColorRGBA.WHITE.mulAlpha(a));
    }

    /** Как legacy New: оффхенд, шлем, нагрудник, поножи, ботинки. */
    private void armorRow(CustomDrawContext ctx, PlayerEntity player, float sx, float top, float endX, float a) {
        float slotSize = 7.0F / 2.0F;       // 3.5 — как legacy
        float armorGap = 8.0F / 2.0F;        // 4.0 — как legacy
        float scale = slotSize / 16.0F * 2.0F; // 0.4375 — как legacy

        ColorRGBA empty = ColorRGBA.WHITE.mulAlpha(0.48f * a);

        float currentX = sx + 1.3F;
        float slotY = top + 1.0F;

        // Слот 0 — оффхенд
        ItemStack offhand = player.getEquippedStack(EquipmentSlot.OFFHAND);
        if (!offhand.isEmpty()) {
            ctx.pushMatrix();
            ctx.getMatrices().translate(currentX - 2.5F, slotY - 3.0F, 0.0F);
            ctx.getMatrices().scale(scale, scale, 1.0F);
            ctx.drawItem(offhand, 0, 0);
            ((DrawContextAccessor) ctx).callDrawItemBar(offhand, 0, 0);
            ctx.popMatrix();
        } else {
            float crossWidth = Fonts.SKYCORE.getWidth("k", 5f);
            float crossX = currentX + (slotSize - crossWidth) / 2.0F + 0.5F;
            float crossY = slotY + slotSize / 2.0F - 1.0F;
            ctx.drawText(Fonts.SKYCORE.getFont(5f), "k", crossX - 1.2F, crossY - 1.2f, empty);
        }
        currentX += slotSize + armorGap;

        // Слоты 1–4: шлем, нагрудник, поножи, ботинки
        EquipmentSlot[] armorSlots = {
                EquipmentSlot.HEAD,
                EquipmentSlot.CHEST,
                EquipmentSlot.LEGS,
                EquipmentSlot.FEET
        };

        for (int i = 0; i < 4; i++) {
            ItemStack stack = player.getEquippedStack(armorSlots[i]);
            if (!stack.isEmpty()) {
                ctx.pushMatrix();
                ctx.getMatrices().translate(currentX - 2.5F, slotY - 3.0F, 0.0F);
                ctx.getMatrices().scale(scale, scale, 1.0F);
                ctx.drawItem(stack, 0, 0);
                ((DrawContextAccessor) ctx).callDrawItemBar(stack, 0, 0);
                ctx.popMatrix();
            } else {
                float crossWidth = Fonts.SKYCORE.getWidth("k", 5f);
                float crossX = currentX + (slotSize - crossWidth) / 2.0F + 0.5F;
                float crossY = slotY + slotSize / 2.0F - 1.0F;
                ctx.drawText(Fonts.SKYCORE.getFont(5f), "k", crossX - 1.2F, crossY - 1.2f, empty);
            }
            currentX += slotSize + armorGap;
        }
    }

    private Identifier skin(PlayerEntity target) {
        if (mc.getNetworkHandler() != null) {
            for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
                if (e.getProfile().getName().equals(target.getGameProfile().getName())) {
                    return e.getSkinTextures().texture();
                }
            }
        }
        return DefaultSkinHelper.getSteve().texture();
    }
}
