package This.skycore.tyca1337.helpers;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import This.skycore.util.interfaces.IMinecraft;

public final class AttackOrder implements IMinecraft {

    private AttackOrder() {
    }

    public static void sendFixedAttack(PlayerEntity player, Entity target) {
        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }
}
