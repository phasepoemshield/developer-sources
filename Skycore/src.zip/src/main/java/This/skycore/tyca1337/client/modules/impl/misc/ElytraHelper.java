package This.skycore.tyca1337.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.util.PlayerInput;
import This.skycore.base.events.impl.input.EventKey;
import This.skycore.base.events.impl.player.EventMoveInput;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.tyca1337.client.modules.api.Category;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.api.ModuleAnnotation;
import This.skycore.tyca1337.client.modules.api.setting.impl.BooleanSetting;
import This.skycore.tyca1337.client.modules.api.setting.impl.KeySetting;
import This.skycore.tyca1337.helpers.InventoryUtil;
import This.skycore.util.game.player.MovingUtil;
import This.skycore.util.game.player.PlayerIntersectionUtil;

@ModuleAnnotation(
        name = "ElytraSwap",
        category = Category.MISC,
        description = "Позволяет быстро свапать элитру или нагрудник"
)
public final class ElytraHelper extends Module {
    public static final ElytraHelper INSTANCE = new ElytraHelper();

    private final KeySetting keySwap = new KeySetting("Кнопка свапа");
    private final BooleanSetting equipChestplate = new BooleanSetting("Снимать элитры при приземлении", false);
    private final KeySetting fireworkKey = new KeySetting("Кнопка фейера");
    private final BooleanSetting autoFly = new BooleanSetting("Автоматически взлетать", false);
    private final BooleanSetting autoJump = new BooleanSetting("Авто прыжок", false);
    private final BooleanSetting useFirework = new BooleanSetting("Автоматически использовать феерверк", false, autoFly::isEnabled);

    private boolean swapRequested;
    private boolean wasOnGround;
    private boolean wasInElytraFlight;
    private int tickSwap;
    private boolean hasFiredOnStart;
    private int sprintLockTicks;

    private ElytraHelper() {
    }

    private void lockSprint(int ticks) {
        this.sprintLockTicks = Math.max(this.sprintLockTicks, ticks);
    }

    private void applySprintLock() {
        if (this.sprintLockTicks <= 0 || mc.player == null) {
            return;
        }

        mc.player.setSprinting(false);
        if (mc.options != null) {
            mc.options.sprintKey.setPressed(false);
        }
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, Mode.STOP_SPRINTING));
        }
        this.sprintLockTicks--;
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (this.tickSwap > 0) {
            this.tickSwap--;
        }

        this.applySprintLock();

        if (this.swapRequested && !MovingUtil.hasPlayerMovement()) {
            this.executeSwap();
            this.swapRequested = false;
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
        }

        if (mc.player.isGliding()) {
            this.wasInElytraFlight = true;
        }

        if (this.equipChestplate.isEnabled()) {
            if (mc.player.isOnGround() && !this.wasOnGround && this.wasInElytraFlight) {
                if (mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
                    int chestplate = InventoryUtil.getChestPlateSlot();
                    if (chestplate != -1) {
                        InventoryUtil.moveToArmor(chestplate, 6);
                    } else {
                        InventoryUtil.pickupItem(6, 0);
                        int empty = InventoryUtil.findEmptyInventorySlot();
                        if (empty != -1) {
                            InventoryUtil.pickupItem(empty, 0);
                        }
                    }
                    this.wasInElytraFlight = false;
                }
            }
            this.wasOnGround = mc.player.isOnGround();
        }

        if (this.autoJump.isEnabled()
                && !mc.player.getAbilities().flying
                && mc.player.isOnGround()
                && mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)
                && !mc.options.jumpKey.isPressed()
                && !mc.player.isTouchingWater()
                && !mc.player.isInLava()) {
            mc.player.jump();
            this.lockSprint(12);
        }

        if (this.autoFly.isEnabled()
                && !mc.player.getAbilities().flying
                && !mc.player.isTouchingWater()
                && !mc.player.isInLava()
                && !mc.player.isOnGround()
                && !mc.player.isGliding()
                && mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            PlayerIntersectionUtil.startFallFlying();
            this.wasInElytraFlight = true;
            this.lockSprint(15);

            if (this.useFirework.isEnabled() && !this.hasFiredOnStart) {
                if (InventoryUtil.getSlot(Items.FIREWORK_ROCKET) != -1) {
                    InventoryUtil.inventorySwapClick(Items.FIREWORK_ROCKET);
                    this.hasFiredOnStart = true;
                }
            }
        }

        if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isInLava()) {
            this.hasFiredOnStart = false;
        }
    }

    @EventTarget
    public void onKey(EventKey event) {
        if (mc.currentScreen != null || mc.player == null || event.getAction() != 1) {
            return;
        }

        if (event.getKeyCode() == this.keySwap.getKeyCode() && this.keySwap.getKeyCode() != -1) {
            boolean hasElytra = InventoryUtil.getSlot(Items.ELYTRA) != -1;
            boolean hasChestplate = InventoryUtil.getChestPlateSlot() != -1;
            if (!hasElytra && !hasChestplate) {
                return;
            }
            this.tickSwap = 2;
            this.swapRequested = true;
        }

        if (event.getKeyCode() == this.fireworkKey.getKeyCode() && this.fireworkKey.getKeyCode() != -1) {
            InventoryUtil.inventorySwapClick(Items.FIREWORK_ROCKET);
        }
    }

    @EventTarget
    private void onMoveInput(EventMoveInput event) {
        if (this.sprintLockTicks > 0) {
            event.setInput(new PlayerInput(
                    event.getInput().forward(),
                    event.getInput().backward(),
                    event.getInput().left(),
                    event.getInput().right(),
                    event.getInput().jump(),
                    event.getInput().sneak(),
                    false
            ));
        }

        if (this.tickSwap > 0) {
            event.setForward(0.0F);
            event.setStrafe(0.0F);
            event.setInput(new PlayerInput(false, false, false, false, false, false, false));
            if (mc.options != null) {
                mc.options.jumpKey.setPressed(false);
                mc.options.sneakKey.setPressed(false);
            }
        }
    }

    private void executeSwap() {
        int targetSlot;
        if (mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            targetSlot = InventoryUtil.getChestPlateSlot();
        } else {
            targetSlot = InventoryUtil.getSlot(Items.ELYTRA);
        }

        if (targetSlot == -1) {
            return;
        }

        InventoryUtil.moveToArmor(targetSlot, 6);
    }

    @Override
    public void onDisable() {
        this.swapRequested = false;
        this.tickSwap = 0;
        this.sprintLockTicks = 0;
        super.onDisable();
    }
}
