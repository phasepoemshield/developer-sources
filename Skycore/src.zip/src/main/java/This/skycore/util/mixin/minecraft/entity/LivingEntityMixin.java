package This.skycore.util.mixin.minecraft.entity;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import This.skycore.base.events.impl.player.EventOnTravelPost;
import This.skycore.base.events.impl.player.EventThornsDamage;
import This.skycore.base.events.impl.player.EventTravel;
import This.skycore.tyca1337.client.modules.impl.combat.AntiThorns;
import This.skycore.util.interfaces.IMinecraft;

@Mixin({LivingEntity.class})
public class LivingEntityMixin implements IMinecraft {

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void skycore$eventTravel(Vec3d movementInput, CallbackInfo ci) {
        if (!((Object) this instanceof ClientPlayerEntity player)) {
            return;
        }
        if (MinecraftClient.getInstance().player != player) {
            return;
        }
        EventTravel event = new EventTravel((LivingEntity) (Object) this);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "calcGlidingVelocity", at = @At("RETURN"), cancellable = true)
    private void skycore$eventTravelPost(Vec3d oldVelocity, CallbackInfoReturnable<Vec3d> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!(self instanceof ClientPlayerEntity player) || player != MinecraftClient.getInstance().player) {
            return;
        }

        EventOnTravelPost event = new EventOnTravelPost(
                oldVelocity.multiply(0.9900000095367432D, 0.9800000190734863D, 0.9900000095367432D)
        );
        EventManager.call(event);
        cir.setReturnValue(event.getOldVelocity());
    }

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void skycore$antiThorns(
            ServerWorld world,
            DamageSource source,
            float amount,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (!((Object) this instanceof ClientPlayerEntity) || mc.player != (Object) this) {
            return;
        }
        if (!source.isOf(DamageTypes.THORNS)) {
            return;
        }

        AntiThorns antiThorns = AntiThorns.INSTANCE;
        if (!antiThorns.isEnabled()) {
            return;
        }

        Entity attacker = source.getAttacker();
        EventThornsDamage event = new EventThornsDamage(attacker, (LivingEntity) (Object) this, 0, amount);
        EventManager.call(event);
        if (event.isCancelled() || antiThorns.shouldCancelThornsDamage(attacker)) {
            cir.setReturnValue(false);
            cir.cancel();
        }
    }
}
