package This.skycore.util.game.other;

import lombok.experimental.UtilityClass;
import This.skycore.util.interfaces.IMinecraft;

@UtilityClass
public class SensUtil implements IMinecraft {
    
    public static float getSensitivity(float rot) {
        float gcdValue = getGCDValue();
        return getDeltaMouse(rot, gcdValue) * gcdValue;
    }
    
    public static float getGCDValue() {
        return (float) (getGCD() * 0.15);
    }
    
    public static float getGCD() {
        float sensitivityFactor = (float) (mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2);
        return sensitivityFactor * sensitivityFactor * sensitivityFactor * 8;
    }
    
    public static float getDeltaMouse(float delta, float gcdValue) {
        if (gcdValue == 0) {
            return 0;
        }
        return Math.round(delta / gcdValue);
    }
    
    public static float getRandomSensitivityOffset() {
        return (float) (Math.random() * 0.1 - 0.05);
    }
    
    public static float getImprovedSensitivity(float rot) {
        float sensitivity = getSensitivity(rot);
        return sensitivity + getRandomSensitivityOffset();
    }
    
    public float getSens(float rotation) {
        return getDeltaMouse(rotation) * getGCDValue();
    }
    
    public float getDeltaMouse(float delta) {
        return Math.round(delta / getGCDValue());
    }
}