package This.skycore.util.client;

import java.util.function.Consumer;
import net.minecraft.client.option.SimpleOption;
import This.skycore.util.render.sky.OptifineSkyLoader;

/**
 * Пункт «Небо из ресурс-пака» в экране настроек графики Minecraft.
 */
public final class SkycoreVideoPackSkyOption {
    private static SimpleOption<Boolean> option;

    private SkycoreVideoPackSkyOption() {
    }

    public static SimpleOption<Boolean> get() {
        if (option == null) {
            PackCustomSkyPreference.ensureLoaded();
            boolean initial = PackCustomSkyPreference.isEnabled();
            Consumer<Boolean> onChange = v -> {
                PackCustomSkyPreference.setEnabled(v);
                PackCustomSkyPreference.save();
                OptifineSkyLoader.INSTANCE.reloadFromClient();
            };
            option = SimpleOption.ofBoolean("skycore.options.pack_custom_sky", initial, onChange);
        }
        return option;
    }
}
