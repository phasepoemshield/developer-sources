package This.skycore.util.mixin.accessors;

import java.util.Map;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.ShaderProgram;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({ShaderProgram.class})
public interface ShaderProgramAccessor {
   @Accessor
   Map<String, GlUniform> getUniformsByName();
}
