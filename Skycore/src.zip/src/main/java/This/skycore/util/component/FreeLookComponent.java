package This.skycore.util.component;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import lombok.Generated;
import net.minecraft.util.math.MathHelper;
import This.skycore.base.events.impl.player.EventLook;
import This.skycore.base.events.impl.player.EventRotation;
import This.skycore.util.interfaces.IClient;

public class FreeLookComponent implements IClient {
    private static boolean active;
    private static float freeYaw;
    private static float freePitch;

    public FreeLookComponent() {
        EventManager.register(this);
    }

    @EventTarget
    public void onLook(EventLook event) {
        if (active) {
            this.rotateTowards(event.getYaw(), event.getPitch());
            event.cancel();
        }

    }

    @EventTarget
    public void onRotation(EventRotation event) {
        if (active) {
            event.setYaw(freeYaw);
            event.setPitch(freePitch);
        } else {
            freeYaw = event.getYaw();
            freePitch = event.getPitch();
        }

    }

    private void rotateTowards(double targetYaw, double targetPitch) {
        freePitch = MathHelper.clamp((float)((double)freePitch + targetPitch * 0.15D), -90.0F, 90.0F);
        freeYaw = (float)((double)freeYaw + targetYaw * 0.15D);
    }

    @Generated
    public static void setActive(boolean active) {
        if (active && !FreeLookComponent.active && mc.gameRenderer != null && mc.gameRenderer.getCamera() != null) {
            freeYaw = mc.gameRenderer.getCamera().getYaw();
            freePitch = mc.gameRenderer.getCamera().getPitch();
        }
        if (!active && FreeLookComponent.active && mc.player != null) {
            mc.player.setYaw(freeYaw);
            mc.player.setPitch(freePitch);
        }
        FreeLookComponent.active = active;
    }

    @Generated
    public static float getFreeYaw() {
        return freeYaw;
    }

    @Generated
    public static float getFreePitch() {
        return freePitch;
    }

    @Generated
    public static void setFreeYaw(float freeYaw) {
        FreeLookComponent.freeYaw = freeYaw;
    }

    @Generated
    public static void setFreePitch(float freePitch) {
        FreeLookComponent.freePitch = freePitch;
    }
}
