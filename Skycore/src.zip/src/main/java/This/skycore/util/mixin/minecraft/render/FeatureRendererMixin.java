package This.skycore.util.mixin.minecraft.render;

import net.minecraft.client.render.entity.feature.FeatureRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({FeatureRenderer.class})
public abstract class FeatureRendererMixin {
}
