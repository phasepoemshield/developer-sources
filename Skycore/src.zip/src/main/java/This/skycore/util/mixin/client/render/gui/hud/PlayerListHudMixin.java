package This.skycore.util.mixin.client.render.gui.hud;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.tyca1337.client.modules.impl.render.Animations;

@Mixin(PlayerListHud.class)
public class PlayerListHudMixin {

    @Unique
    private boolean skycore$tabPushed;

    @Inject(method = "render", at = @At("HEAD"))
    private void skycore$tabHead(DrawContext context, int width, Scoreboard scoreboard, @Nullable ScoreboardObjective objective, CallbackInfo ci) {
        Animations animations = Animations.INSTANCE;
        if (!animations.isModeEnabled("Список игроков")) {
            return;
        }

        float progress = animations.getTabSlideAnimation().getValue();
        if (progress >= 0.999F) {
            return;
        }

        int slideDistance = 220;
        context.getMatrices().push();
        context.getMatrices().translate(0.0F, -(1.0F - progress) * slideDistance, 0.0F);
        this.skycore$tabPushed = true;
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void skycore$tabReturn(DrawContext context, int width, Scoreboard scoreboard, @Nullable ScoreboardObjective objective, CallbackInfo ci) {
        if (this.skycore$tabPushed) {
            context.getMatrices().pop();
            this.skycore$tabPushed = false;
        }
    }
}
