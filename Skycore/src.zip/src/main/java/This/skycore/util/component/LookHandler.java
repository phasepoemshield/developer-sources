package This.skycore.util.component;

import com.darkmagician6.eventapi.EventTarget;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.util.math.MathHelper;
import This.skycore.base.events.impl.player.EventLook;
import This.skycore.base.events.impl.player.EventRotation;

public class LookHandler {

    @Getter
    @Setter
    private static boolean active;
    @Getter
    @Setter
    private static float freeYaw;
    @Getter
    @Setter
    private static float freePitch;

    @EventTarget
    public void onRotation(EventRotation e) {
        if (active) {
            e.setYaw(freeYaw);
            e.setPitch(freePitch);
        } else {
            freeYaw = e.getYaw();
            freePitch = e.getPitch();
        }
    }

    @EventTarget
    public void onLook(EventLook e) {
        if (active) {
            e.setCancelled(true);
            freePitch = MathHelper.clamp((float) (freePitch + e.getPitch() * 0.15D), -90.0F, 90.0F);
            freeYaw = (float) (freeYaw + e.getYaw() * 0.15D);
        }
    }
}
