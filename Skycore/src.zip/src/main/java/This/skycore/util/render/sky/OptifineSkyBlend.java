package This.skycore.util.render.sky;

import com.mojang.blaze3d.platform.GlStateManager;

public enum OptifineSkyBlend {
    ADD(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE),
    ALPHA(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA),
    REPLACE(GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ZERO),
    MULTIPLY(GlStateManager.SrcFactor.DST_COLOR, GlStateManager.DstFactor.ZERO),
    SCREEN(GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ONE_MINUS_SRC_COLOR);

    public final GlStateManager.SrcFactor src;
    public final GlStateManager.DstFactor dst;

    OptifineSkyBlend(GlStateManager.SrcFactor src, GlStateManager.DstFactor dst) {
        this.src = src;
        this.dst = dst;
    }

    public static OptifineSkyBlend fromProperty(String raw) {
        if (raw == null || raw.isBlank()) {
            return ADD;
        }
        return switch (raw.trim().toLowerCase()) {
            case "alpha" -> ALPHA;
            case "replace" -> REPLACE;
            case "multiply" -> MULTIPLY;
            case "screen" -> SCREEN;
            case "subtract", "dodge", "burn", "overlay" -> ADD;
            default -> ADD;
        };
    }
}
