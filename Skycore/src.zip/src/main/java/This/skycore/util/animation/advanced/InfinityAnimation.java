package This.skycore.util.animation.advanced;

public class InfinityAnimation {
    private float output;
    private float endpoint;
    private AdvEasing easing = AdvEasing.LINEAR;
    private AdvAnimation animation = new AdvAnimation().setSize(0).setSpeed(0).setForward(false).setEasing(easing);

    public float animate(float destination, int ms) {
        ms = Math.max(1, ms);
        output = endpoint - animation.get();
        endpoint = destination;
        if (output != (endpoint - destination)) {
            animation = new AdvAnimation().setSize(endpoint - output).setSpeed(ms).setForward(false).setEasing(easing);
        }
        return output;
    }

    public float get() {
        output = endpoint - animation.get();
        return output;
    }

    public InfinityAnimation easing(AdvEasing e) {
        this.easing = e;
        return this;
    }
}
