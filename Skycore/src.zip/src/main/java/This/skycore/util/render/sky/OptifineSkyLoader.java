package This.skycore.util.render.sky;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Properties;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

/**
 * Loads OptiFine-format custom sky from resource packs:
 * {@code assets/<namespace>/optifine/sky/world0|world1/sky<N>.properties}.
 */
public final class OptifineSkyLoader {
    public static final OptifineSkyLoader INSTANCE = new OptifineSkyLoader();

    private volatile List<OptifineSkyLayer> overworldLayers = List.of();
    private volatile List<OptifineSkyLayer> endLayers = List.of();

    private OptifineSkyLoader() {
    }

    public void reload(ResourceManager manager) {
        this.overworldLayers = loadWorld(manager, "world0");
        this.endLayers = loadWorld(manager, "world1");
    }

    /** Перечитать sky*.properties из текущего ResourceManager клиента (после F3+T или смены флага неба). */
    public void reloadFromClient() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getResourceManager() == null) {
            return;
        }
        reload(client.getResourceManager());
    }

    public List<OptifineSkyLayer> getLayersForOverworld() {
        return overworldLayers;
    }

    public List<OptifineSkyLayer> getLayersForEnd() {
        return endLayers;
    }

    public boolean hasOverworldLayers() {
        return !overworldLayers.isEmpty();
    }

    public boolean hasEndLayers() {
        return !endLayers.isEmpty();
    }

    private static List<OptifineSkyLayer> loadWorld(ResourceManager manager, String worldFolder) {
        List<OptifineSkyLayer> out = new ArrayList<>();
        for (int i = 0; i < 256; i++) {
            final int index = i;
            Optional<Identifier> propsId = resolveSkyPropertiesId(manager, worldFolder, index);
            propsId.flatMap(manager::getResource).ifPresent(resource -> {
                try (InputStream in = resource.getInputStream()) {
                    Properties p = new Properties();
                    p.load(in);
                    OptifineSkyLayer layer = parseLayer(manager, propsId.get(), index, p);
                    if (layer != null) {
                        out.add(layer);
                    }
                } catch (Exception ignored) {
                }
            });
        }
        out.sort(Comparator.comparingInt(l -> l.order));
        return out.isEmpty() ? List.of() : Collections.unmodifiableList(out);
    }

    /** Сначала {@code minecraft:}, затем остальные namespace (как слияние RP). */
    private static Optional<Identifier> resolveSkyPropertiesId(ResourceManager manager, String worldFolder, int index) {
        String path = "optifine/sky/" + worldFolder + "/sky" + index + ".properties";
        Identifier vanilla = Identifier.ofVanilla(path);
        if (manager.getResource(vanilla).isPresent()) {
            return Optional.of(vanilla);
        }
        for (String ns : manager.getAllNamespaces()) {
            if ("minecraft".equals(ns)) {
                continue;
            }
            Identifier id = Identifier.of(ns, path);
            if (manager.getResource(id).isPresent()) {
                return Optional.of(id);
            }
        }
        return Optional.empty();
    }

    private static @Nullable OptifineSkyLayer parseLayer(ResourceManager manager, Identifier propsId, int order, Properties p) {
        String source = p.getProperty("source");
        if (source == null || source.isBlank()) {
            source = p.getProperty("texture");
        }
        Identifier texture = resolveTexture(propsId, source);
        if (texture == null) {
            return null;
        }
        if (!manager.getResource(texture).isPresent()) {
            return null;
        }

        OptifineSkyBlend blend = OptifineSkyBlend.fromProperty(p.getProperty("blend"));
        boolean rotate = parseBool(p.getProperty("rotate"), true);
        float speed = parseFloat(p.getProperty("speed"), 1.0f);

        float ax = 0f, ay = 0f, az = 1f;
        String axis = p.getProperty("axis");
        if (axis != null && !axis.isBlank()) {
            String[] parts = axis.trim().split("\\s+");
            if (parts.length >= 3) {
                try {
                    ax = Float.parseFloat(parts[0]);
                    ay = Float.parseFloat(parts[1]);
                    az = Float.parseFloat(parts[2]);
                } catch (NumberFormatException ignored) {
                }
            }
        }

        String sfi = p.getProperty("startFadeIn");
        String efi = p.getProperty("endFadeIn");
        String sfo = p.getProperty("startFadeOut");
        String efo = p.getProperty("endFadeOut");
        boolean hasFade = sfi != null || efi != null || sfo != null || efo != null;
        int tSfi = Integer.MIN_VALUE;
        int tEfi = Integer.MIN_VALUE;
        int tSfo = Integer.MIN_VALUE;
        int tEfo = Integer.MIN_VALUE;
        if (hasFade) {
            try {
                if (sfi != null) {
                    tSfi = timeToTicks(sfi);
                }
                if (efi != null) {
                    tEfi = timeToTicks(efi);
                }
                if (sfo != null) {
                    tSfo = timeToTicks(sfo);
                }
                if (efo != null) {
                    tEfo = timeToTicks(efo);
                }
            } catch (Exception e) {
                hasFade = false;
            }
        }

        int weatherMask = parseWeatherMask(p.getProperty("weather", "clear"));

        return new OptifineSkyLayer(
                order,
                texture,
                blend,
                rotate,
                speed,
                ax,
                ay,
                az,
                tSfi,
                tEfi,
                tSfo,
                tEfo,
                hasFade,
                weatherMask
        );
    }

    private static int parseWeatherMask(String weather) {
        int mask = 0;
        for (String t : weather.toLowerCase(Locale.ROOT).split("\\s+")) {
            if (t.isEmpty()) {
                continue;
            }
            mask |= switch (t) {
                case "clear" -> 1;
                case "rain" -> 2;
                case "thunder" -> 4;
                default -> 0;
            };
        }
        return mask == 0 ? 1 : mask;
    }

    private static @Nullable Identifier resolveTexture(Identifier propsId, @Nullable String source) {
        String folder = propsId.getPath().substring(0, propsId.getPath().lastIndexOf('/') + 1);
        String ns = propsId.getNamespace();
        if (source == null || source.isBlank()) {
            String base = propsId.getPath().substring(propsId.getPath().lastIndexOf('/') + 1).replace(".properties", "");
            return Identifier.of(ns, folder + base + ".png");
        }
        source = source.trim();
        if (source.startsWith("./")) {
            source = source.substring(2);
        }
        if (source.contains(":")) {
            int c = source.indexOf(':');
            return Identifier.of(source.substring(0, c), source.substring(c + 1));
        }
        if (source.startsWith("assets/minecraft/")) {
            return Identifier.ofVanilla(source.substring("assets/minecraft/".length()));
        }
        if (source.startsWith("/")) {
            source = source.substring(1);
        }
        return Identifier.of(ns, source.contains("/") ? source : folder + source);
    }

    /**
     * OptiFine hh:mm with 06:00 = world tick 0 (same mapping as /time set).
     */
    private static int timeToTicks(String hhmm) {
        String[] p = hhmm.trim().split(":");
        int h = Integer.parseInt(p[0].trim());
        int m = p.length > 1 ? Integer.parseInt(p[1].trim()) : 0;
        int mins = (h * 60 + m - 6 * 60 + 24 * 60) % (24 * 60);
        return (int) (mins / (24f * 60) * 24000);
    }

    private static boolean parseBool(String s, boolean def) {
        if (s == null) {
            return def;
        }
        return Boolean.parseBoolean(s.trim());
    }

    private static float parseFloat(String s, float def) {
        if (s == null) {
            return def;
        }
        try {
            return Float.parseFloat(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
