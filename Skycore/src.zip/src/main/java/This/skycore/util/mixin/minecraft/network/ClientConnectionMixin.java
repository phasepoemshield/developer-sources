package This.skycore.util.mixin.minecraft.network;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.base.events.impl.server.EventPacket;
import This.skycore.util.game.other.NetworkUtils;
import This.skycore.util.interfaces.IMinecraft;

@Mixin(ClientConnection.class)
public class ClientConnectionMixin implements IMinecraft {

    @Unique
    private static boolean sending = false;

    @Inject(method = "handlePacket", at = @At("HEAD"), cancellable = true)
    private static <T extends PacketListener> void onReceivePacket(Packet<T> packet, PacketListener listener, CallbackInfo ci) {
        EventPacket event = new EventPacket(EventPacket.Action.RECEIVE, packet);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    public void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        // Пропускаем если уже отправляем (защита от рекурсии)
        if (sending) return;

        // Пропускаем silent пакеты
        if (NetworkUtils.getSilentPackets().remove(packet)) {
            return;
        }

        EventPacket event = new EventPacket(EventPacket.Action.SENT, packet);
        EventManager.call(event);

        if (event.isCancelled()) {
            ci.cancel();
            return;
        }

        // Если пакет заменён — отменяем оригинал и отправляем новый
        if (event.getPacket() != packet) {
            ci.cancel();
            sending = true;
            try {
                mc.getNetworkHandler().sendPacket(event.getPacket());
            } finally {
                sending = false;
            }
        }
    }
}