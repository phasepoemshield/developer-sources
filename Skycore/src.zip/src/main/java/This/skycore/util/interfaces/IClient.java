package This.skycore.util.interfaces;

import This.skycore.SkyCore;

public interface IClient extends IWindow {
   SkyCore SKY_CORE = SkyCore.getInstance();
}
