package This.skycore.util.capes;

import This.skycore.util.capes.config.Config;

/**
 * Упрощённый аналог WaveyCapesBase из skycore recode.
 * Хранит глобальный конфиг плащей.
 */
public class WaveyCapesBase {

    public static WaveyCapesBase INSTANCE;
    public static Config config;

    public WaveyCapesBase start() {
        INSTANCE = this;
        config = new Config();
        return this;
    }
}

