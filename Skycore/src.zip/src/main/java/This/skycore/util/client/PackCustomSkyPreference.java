package This.skycore.util.client;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.client.MinecraftClient;

/**
 * Хранит флаг «небо из ресурс-пака» (OptiFine sky), как отдельная настройка вне чита.
 * Файл в корне игры рядом с {@code options.txt}.
 */
public final class PackCustomSkyPreference {
    private static final String FILE_NAME = "skycore_optifine_sky.txt";

    private static final Object LOCK = new Object();
    private static volatile boolean loaded;
    private static boolean enabled;

    private PackCustomSkyPreference() {
    }

    public static boolean isEnabled() {
        ensureLoaded();
        return enabled;
    }

    public static void setEnabled(boolean value) {
        ensureLoaded();
        enabled = value;
    }

    public static void ensureLoaded() {
        if (loaded) {
            return;
        }
        synchronized (LOCK) {
            if (loaded) {
                return;
            }
            loadFromDisk();
            loaded = true;
        }
    }

    private static void loadFromDisk() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.runDirectory == null) {
            enabled = false;
            return;
        }
        Path path = client.runDirectory.toPath().resolve(FILE_NAME);
        if (!Files.isRegularFile(path)) {
            enabled = false;
            return;
        }
        try {
            String line = Files.readString(path, StandardCharsets.UTF_8).trim().toLowerCase();
            enabled = line.equals("1") || line.equals("true") || line.equals("on") || line.equals("yes");
        } catch (IOException ignored) {
            enabled = false;
        }
    }

    public static void save() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.runDirectory == null) {
            return;
        }
        Path path = client.runDirectory.toPath().resolve(FILE_NAME);
        try {
            Files.writeString(path, enabled ? "true" : "false", StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }
}
