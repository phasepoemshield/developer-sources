package This.skycore.util.game;

import lombok.experimental.UtilityClass;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@UtilityClass
public class Sound {
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    public void playSound(final String location, double volume, float pitch) {
        executorService.execute(() -> {
            try {
                // сначала ищем в fabric‑ресурсах мода
                InputStream inputStream = Sound.class.getResourceAsStream("/assets/skycore/sounds/" + location);
                // fallback на старый путь из skycore recode, если вдруг ты закинул туда
                if (inputStream == null) {
                    inputStream = Sound.class.getResourceAsStream("/assets/minecraft/skycore/sounds/" + location);
                }
                if (inputStream == null) {
                    System.err.println("Audio not found: " + location);
                    return;
                }

                try (BufferedInputStream bufferedIn = new BufferedInputStream(inputStream);
                     AudioInputStream baseStream = AudioSystem.getAudioInputStream(bufferedIn)) {

                    AudioInputStream pitchedStream = resampleStream(baseStream, pitch);

                    Clip clip = AudioSystem.getClip();
                    clip.open(pitchedStream);

                    setVolume(clip, volume);
                    clip.start();
                }
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                e.printStackTrace();
            }
        });
    }

    public void playSound(final String location) {
        playSound(location, 0.5, 1.0f);
    }

    private void setVolume(Clip clip, double volume) {
        if (volume < 0) volume = 0;
        if (volume > 1) volume = 1;

        FloatControl volumeControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
        float dB = (float) (Math.log10(volume <= 0 ? 0.0001 : volume) * 20);
        volumeControl.setValue(dB);
    }

    private AudioInputStream resampleStream(AudioInputStream originalStream, float pitch) throws IOException {
        AudioFormat originalFormat = originalStream.getFormat();

        byte[] audioBytes = originalStream.readAllBytes();

        float newSampleRate = originalFormat.getSampleRate() * pitch;

        AudioFormat newFormat = new AudioFormat(
                newSampleRate,
                originalFormat.getSampleSizeInBits(),
                originalFormat.getChannels(),
                true,
                originalFormat.isBigEndian()
        );

        return new AudioInputStream(
                new BufferedInputStream(new java.io.ByteArrayInputStream(audioBytes)),
                newFormat,
                audioBytes.length / newFormat.getFrameSize()
        );
    }
}
