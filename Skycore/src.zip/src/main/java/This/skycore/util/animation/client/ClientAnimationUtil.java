package This.skycore.util.animation.client;

import net.minecraft.util.math.MathHelper;

public class ClientAnimationUtil {
    private float currentValue;
    private float targetValue;
    private float fromValue;
    private final float speed;
    private final ClientEasing easing;
    private long startTimeNs;
    private double durationSec;
    private boolean isRunning;

    public ClientAnimationUtil(float initialValue, float speed, ClientEasing easing) {
        this.currentValue = initialValue;
        this.targetValue = initialValue;
        this.fromValue = initialValue;
        this.speed = speed;
        this.easing = easing != null ? easing : ClientEasings.LINEAR;
        this.startTimeNs = 0L;
        this.durationSec = 0.0;
        this.isRunning = false;
    }

    public void update(float target) {
        if (this.targetValue != target || !this.isRunning) {
            this.targetValue = target;
            this.fromValue = this.currentValue;
            this.startTimeNs = System.nanoTime();
            this.durationSec = 1.0 / speed * 2.0;
            this.isRunning = true;
        }

        if (this.isDone()) {
            this.currentValue = this.targetValue;
            this.isRunning = false;
            return;
        }

        double part = this.calculatePart();
        float easedPart = (float) easing.ease(part);
        this.currentValue = MathHelper.lerp(easedPart, this.fromValue, this.targetValue);
    }

    private double calculatePart() {
        if (!this.isRunning) {
            return 1.0;
        }
        long now = System.nanoTime();
        double elapsed = (now - this.startTimeNs) / 1_000_000_000.0;
        return MathHelper.clamp(elapsed / this.durationSec, 0.0, 1.0);
    }

    public float getValue() {
        return currentValue;
    }

    public void setValue(float value) {
        this.currentValue = value;
        this.targetValue = value;
        this.fromValue = value;
        this.isRunning = false;
    }

    public boolean isDone() {
        return this.calculatePart() >= 1.0;
    }

    public boolean isAlive() {
        return !isDone();
    }
}
