package This.skycore.util.render.display.shader;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.Framebuffer;
import This.skycore.util.interfaces.IWindow;

public class CustomRenderTarget extends Framebuffer implements IWindow {
   private boolean linear;

   public CustomRenderTarget(boolean useDepth) {
      super(useDepth);
   }

   public CustomRenderTarget(int width, int height, boolean useDepth) {
      super(useDepth);
      this.resize(width, height);
   }

   public CustomRenderTarget setLinear() {
      this.linear = true;
      RenderSystem.recordRenderCall(() -> {
         this.setTexFilter(9729);
      });
      return this;
   }

   public void setTexFilter(int framebufferFilterIn) {
      super.setTexFilter(this.linear ? 9729 : framebufferFilterIn);
   }

   private void resizeFramebuffer() {
      if (this.needsNewFramebuffer()) {
         Framebuffer main = mc.getFramebuffer();
         this.initFbo(Math.max(main.textureWidth, 1), Math.max(main.textureHeight, 1));
      }

   }

   public void setup(boolean clear) {
      this.resizeFramebuffer();
      if (clear) {
         this.clear();
      }

      this.beginWrite(false);
   }

   public void setup() {
      this.setup(true);
   }

   public void stop() {
      this.endWrite();
      mc.getFramebuffer().beginWrite(true);
   }

   private boolean needsNewFramebuffer() {
      Framebuffer main = mc.getFramebuffer();
      return this.textureWidth != main.textureWidth || this.textureHeight != main.textureHeight;
   }
}
