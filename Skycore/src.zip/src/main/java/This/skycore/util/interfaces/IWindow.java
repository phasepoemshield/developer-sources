package This.skycore.util.interfaces;

import net.minecraft.client.util.Window;

public interface IWindow extends IMinecraft {
   Window mw = mc.getWindow();
}
