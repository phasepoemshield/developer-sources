package This.skycore.util.capes.config;

import This.skycore.util.capes.CapeMovement;
import This.skycore.util.capes.CapeStyle;
import This.skycore.util.capes.WindMode;

/**
 * Конфиг поведения плащей (гравитация, стиль и т.п.).
 * Значения взяты из skycore recode.
 */
public class Config {

    public WindMode windMode = WindMode.NONE;
    public CapeStyle capeStyle = CapeStyle.SMOOTH;
    public CapeMovement capeMovement = CapeMovement.BASIC_SIMULATION;
    public int gravity = 25;
    public int heightMultiplier = 6;
    public int straveMultiplier = 2;
}

