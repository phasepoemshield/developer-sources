package This.skycore.util.capes;

public enum WindMode {
    NONE
}

