package This.skycore.util.game.other;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextContent;
import net.minecraft.text.PlainTextContent.Literal;
import This.nexusguard.protection.annotations.Native;

/**
 * Замены текста для отображения (ранги, малые буквы, символы префикса).
 */
public class ReplaceUtil {
   private static final Map<Integer, String> MSDF_SYMBOL_REPLACEMENTS = new HashMap<>();

   static {
      MSDF_SYMBOL_REPLACEMENTS.put((int) '⚡', "");
      MSDF_SYMBOL_REPLACEMENTS.put((int) '★', "");

      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔀ', "PLAYER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔄ', "HERO");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔈ', "TITAN");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔒ', "AVENGER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔖ', "OVERLORD");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔠ', "MAGISTER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔤ', "IMPERATOR");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔨ', "DRAGON");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꕠ', "D.HELPER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔲ', "BULL");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔶ', "TIGER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꕄ', "DRACULA");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꕖ', "BUNNY");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꕈ', "COBRA");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꕀ', "HYDRA");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꕒ', "RABBIT");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔉ', "HELPER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔓ', "ML.MODER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔗ', "MODER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔡ', "MODER+");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔥ', "ST.MODER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔩ', "GL.MODER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔳ', "ML.ADMIN");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔷ', "ADMIN");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔁ', "MEDIA");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔅ', "YT");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꕁ', "GOD");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꔂ', "D.MODER");
      MSDF_SYMBOL_REPLACEMENTS.put((int) '◆', "@");
      MSDF_SYMBOL_REPLACEMENTS.put((int) '┃', "|");
      MSDF_SYMBOL_REPLACEMENTS.put(0x1F525, "@");

      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴀ', "A");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ʙ', "B");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴄ', "C");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴅ', "D");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴇ', "E");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꜰ', "F");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ɢ', "G");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ʜ', "H");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ɪ', "I");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴊ', "J");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴋ', "K");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ʟ', "L");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴍ', "M");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ɴ', "N");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴏ', "O");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴘ', "P");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ǫ', "Q");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ʀ', "R");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴛ', "T");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴜ', "U");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ꜱ', "S");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴠ', "V");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴡ', "W");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᵡ', "X");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ʏ', "Y");
      MSDF_SYMBOL_REPLACEMENTS.put((int) 'ᴢ', "Z");
   }

   private static String replaceCodePointForMsdf(int codePoint) {
      return MSDF_SYMBOL_REPLACEMENTS.get(codePoint);
   }

   @Native
   public static Text replace(Text input, String target, String replacement) {
      if (input != null && target != null && replacement != null) {
         MutableText result = Text.empty().setStyle(input.getStyle());
         appendReplaced(result, input, target, replacement);
         return result;
      } else {
         return input;
      }
   }

   @Native
   private static void appendReplaced(MutableText result, Text current, String target, String replacement) {
      TextContent content = current.getContent();
      Style style = current.getStyle();
      if (content instanceof Literal literal) {
         Pattern pattern = Pattern.compile(Pattern.quote(target), 2);
         String replaced = pattern.matcher(literal.string()).replaceAll(replacement);
         result.append(Text.literal(replaced).setStyle(style));
      }

      for (Text sibling : current.getSiblings()) {
         appendReplaced(result, sibling, target, replacement);
      }
   }

   @Native
   public static Text replaceLiteral(Text input, String target, String replacement) {
      if (input == null) {
         return null;
      } else {
         String full = input.getString();
         if (!full.toLowerCase().contains(target.toLowerCase())) {
            return input;
         } else {
            full = full.replaceAll("(?i)" + Pattern.quote(target), replacement);
            MutableText out = Text.empty();
            List<StyledChar> styledChars = flatten(input);
            int index = 0;

            for (int i = 0; i < full.length(); ++i) {
               Style style = index < styledChars.size() ? styledChars.get(index).style() : Style.EMPTY;
               out.append(Text.literal(String.valueOf(full.charAt(i))).setStyle(style));
               ++index;
            }

            return out;
         }
      }
   }

   @Native
   private static List<StyledChar> flatten(Text text) {
      List<StyledChar> list = new ArrayList();
      collect(text, list);
      return list;
   }

   private static void collect(Text text, List<StyledChar> list) {
      Style style = text.getStyle();
      TextContent var4 = text.getContent();
      if (var4 instanceof Literal literal) {
         String s = literal.string();
         for (int i = 0; i < s.length(); ++i) {
            list.add(new StyledChar(s.charAt(i), style));
         }
      }

      for (Text sibling : text.getSiblings()) {
         collect(sibling, list);
      }
   }

   /** Плоская строка для MSDF: ранги → текст, малые буквы, символы префикса. */
   @Native
   public static String replaceSymbols(String s) {
      if (s == null || s.isEmpty()) {
         return s;
      }
      StringBuilder out = new StringBuilder(s.length() + 8);
      for (int i = 0; i < s.length(); ) {
         int cp = s.codePointAt(i);
         int w = Character.charCount(cp);
         if (cp == 'ꕗ' && i + w < s.length() && s.charAt(i + w) == 'ꕘ') {
            out.append("SPONSOR");
            i += w + 1;
            continue;
         }
         String rep = replaceCodePointForMsdf(cp);
         if (rep != null) {
            out.append(rep);
         } else {
            out.appendCodePoint(cp);
         }
         i += w;
      }
      return out.toString();
   }

   /**
    * Для {@link net.minecraft.text.Text}: замены, удобные через дерево Text (без дублирования плоской MSDF-логики).
    */
   public static Text replaceSymbols(Text text) {
      if (text.getString().contains("◆")) {
         text = replace(text, "◆", "@");
      }

      if (text.getString().contains("┃")) {
         text = replace(text, "┃", "|");
      }

      if (text.getString().contains("\ud83d\udd25")) {
         text = replace(text, "\ud83d\udd25", "@");
      }

      if (text.getString().contains("ᴀ")) {
         text = replace(text, "ᴀ", "A");
      }

      if (text.getString().contains("ʙ")) {
         text = replace(text, "ʙ", "B");
      }

      if (text.getString().contains("ᴄ")) {
         text = replace(text, "ᴄ", "C");
      }

      if (text.getString().contains("ᴅ")) {
         text = replace(text, "ᴅ", "D");
      }

      if (text.getString().contains("ᴇ")) {
         text = replace(text, "ᴇ", "E");
      }

      if (text.getString().contains("ғ")) {
         text = replace(text, "ғ", "F");
      }

      if (text.getString().contains("ɢ")) {
         text = replace(text, "ɢ", "G");
      }

      if (text.getString().contains("ʜ")) {
         text = replace(text, "ʜ", "H");
      }

      if (text.getString().contains("ɪ")) {
         text = replace(text, "ɪ", "I");
      }

      if (text.getString().contains("ᴊ")) {
         text = replace(text, "ᴊ", "J");
      }

      if (text.getString().contains("ᴋ")) {
         text = replace(text, "ᴋ", "K");
      }

      if (text.getString().contains("ʟ")) {
         text = replace(text, "ʟ", "L");
      }

      if (text.getString().contains("ᴍ")) {
         text = replace(text, "ᴍ", "M");
      }

      if (text.getString().contains("ɴ")) {
         text = replace(text, "ɴ", "N");
      }

      if (text.getString().contains("ꜱ")) {
         text = replace(text, "ꜱ", "S");
      }

      if (text.getString().contains("ᴏ")) {
         text = replace(text, "ᴏ", "O");
      }

      if (text.getString().contains("ᴘ")) {
         text = replace(text, "ᴘ", "P");
      }

      if (text.getString().contains("ǫ")) {
         text = replace(text, "ǫ", "Q");
      }

      if (text.getString().contains("ʀ")) {
         text = replace(text, "ʀ", "R");
      }

      if (text.getString().contains("ᴛ")) {
         text = replace(text, "ᴛ", "T");
      }

      if (text.getString().contains("ᴜ")) {
         text = replace(text, "ᴜ", "U");
      }

      if (text.getString().contains("ᴠ")) {
         text = replace(text, "ᴠ", "V");
      }

      if (text.getString().contains("ᴡ")) {
         text = replace(text, "ᴡ", "W");
      }

      if (text.getString().contains("ꜰ")) {
         text = replace(text, "ꜰ", "F");
      }

      if (text.getString().contains("ʏ")) {
         text = replace(text, "ʏ", "Y");
      }

      if (text.getString().contains("ᴢ")) {
         text = replace(text, "ᴢ", "Z");
      }

      return text;
   }

   public static String toQwerty(String text) {
      return text.replace("й", "q").replace("ц", "w").replace("у", "e").replace("к", "r").replace("е", "t").replace("н", "y").replace("г", "u").replace("ш", "i").replace("щ", "o").replace("з", "p").replace("х", "[").replace("ъ", "]").replace("ф", "a").replace("ы", "s").replace("в", "d").replace("а", "f").replace("п", "g").replace("р", "h").replace("о", "j").replace("л", "k").replace("д", "l").replace("ж", ";").replace("э", "'").replace("я", "z").replace("ч", "x").replace("с", "c").replace("м", "v").replace("и", "b").replace("т", "n").replace("ь", "m").replace("б", ",").replace("ю", ".").replace("ё", "`").replace("Й", "Q").replace("Ц", "W").replace("У", "E").replace("К", "R").replace("Е", "T").replace("Н", "Y").replace("Г", "U").replace("Ш", "I").replace("Щ", "O").replace("З", "P").replace("Х", "{").replace("Ъ", "}").replace("Ф", "A").replace("Ы", "S").replace("В", "D").replace("А", "F").replace("П", "G").replace("Р", "H").replace("О", "J").replace("Л", "K").replace("Д", "L").replace("Ж", ":").replace("Э", "\"").replace("Я", "Z").replace("Ч", "X").replace("С", "C").replace("М", "V").replace("И", "B").replace("Т", "N").replace("Ь", "M").replace("Б", "<").replace("Ю", ">").replace("Ё", "~");
   }

   private static record StyledChar(char c, Style style) {
      private StyledChar(char c, Style style) {
         this.c = c;
         this.style = style;
      }

      public char c() {
         return this.c;
      }

      public Style style() {
         return this.style;
      }
   }
}
