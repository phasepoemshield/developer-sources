package This.skycore.util.mixin.mixinnew;


import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.tyca1337.client.modules.impl.combat.Aura;

@Mixin(Camera.class)
public abstract class MixinCamera {

    @Shadow
    private float yaw;

    @Shadow
    private float pitch;

    /**
     * Применяем визуальное смещение камеры ПОСЛЕ того, как камера обновила свою позицию.
     * Это влияет ТОЛЬКО на рендер — серверные пакеты ротации отправляются через
     * RotationComponent и не затрагиваются этим миксином.
     *
     * Другие игроки видят серверную ротацию (из пакетов), а не клиентскую камеру.
     */
    @Inject(method = "update", at = @At("RETURN"))
    private void onCameraUpdate(CallbackInfo ci) {
        if (Aura.INSTANCE != null && Aura.INSTANCE.isEnabled() && Aura.INSTANCE.isVisuallyTurnedBack()) {
            float offset = Aura.INSTANCE.getVisualYawOffset();

            // Добавляем смещение к yaw камеры (разворот назад)
            this.yaw += offset;

            // Опционально: зеркалим pitch при развороте больше 90°
            // Это делает визуал более естественным — вы как бы "оглядываетесь назад"
            if (offset > 90.0F) {
                float factor = (offset - 90.0F) / 90.0F; // 0..1
                this.pitch = this.pitch * (1.0F - factor) + (-this.pitch) * factor;
            }
        }
    }
}