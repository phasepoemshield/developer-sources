package This.skycore.util.mixin.client;

import This.skycore.tyca1337.helpers.EventPlace;
import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.client.MinecraftClient;

@Mixin(ClientPlayerInteractionManager.class)
public class MixinClientPlayerInteractionManager {

    @Inject(method = "interactBlock", at = @At("RETURN"))
    private void onInteractBlock(ClientPlayerEntity player, Hand hand, BlockHitResult hitResult, CallbackInfoReturnable<ActionResult> cir) {
        try {
            if (cir.getReturnValue() == ActionResult.SUCCESS || cir.getReturnValue().isAccepted()) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.world == null) return;

                BlockPos placePos = hitResult.getBlockPos().offset(hitResult.getSide());
                var blockState = mc.world.getBlockState(placePos);

                EventManager.call(new EventPlace(blockState.getBlock(), placePos));
            }
        } catch (Exception ignored) {}
    }
}