package This.skycore.util.capes;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.PlayerEntityModel;

public interface CapeRenderer {

    void render(AbstractClientPlayerEntity player,
                int part,
                PlayerEntityModel model,
                VertexConsumerProvider vertexConsumers,
                int light);



    boolean vanillaUvValues();
}

