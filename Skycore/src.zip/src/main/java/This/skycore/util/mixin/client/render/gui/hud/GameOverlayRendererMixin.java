package This.skycore.util.mixin.client.render.gui.hud;

import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.tyca1337.client.modules.impl.player.NoPush;
import This.skycore.tyca1337.client.modules.impl.render.NoRender;

@Mixin({InGameOverlayRenderer.class})
public class GameOverlayRendererMixin {
   @Inject(
      method = {"renderFireOverlay"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void removeFireOverlay(MatrixStack matrices, VertexConsumerProvider vertexConsumers, CallbackInfo ci) {
      if (NoRender.INSTANCE.isRemoveFire()) {
         ci.cancel();
      }

   }

   @Inject(
           method = {"renderInWallOverlay"},
           at = {@At("HEAD")},
           cancellable = true,
           require = 0
   )
   private static void skycore$noPushSeeInBlocks(Sprite sprite, MatrixStack matrices, VertexConsumerProvider vertexConsumers, CallbackInfo ci) {
      // "Видно в блоках" when NoPush is enabled.
      if (NoPush.INSTANCE.isEnabled()) {
         ci.cancel();
      }
   }
}
