package This.skycore.util.mixin.minecraft.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.tyca1337.client.modules.impl.render.BabyMod;
import This.skycore.tyca1337.client.modules.impl.render.EntityESP;

@Mixin({PlayerEntityRenderer.class})
public class PlayerEntityRendererMixin {
   @Inject(
      method = {"scale(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;)V"},
      at = {@At("TAIL")}
   )
   private void skycore$babyModelScale(PlayerEntityRenderState state, MatrixStack matrices, CallbackInfo ci) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null) {
         return;
      }
      if (state.id != mc.player.getId()) {
         return;
      }
      if (!BabyMod.shouldApplyModel()) {
         return;
      }
      matrices.scale(BabyMod.MODEL_SCALE, BabyMod.MODEL_SCALE, BabyMod.MODEL_SCALE);
   }

   @Inject(
      method = {"renderLabelIfPresent(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void render(PlayerEntityRenderState playerEntityRenderState, Text text, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int i, CallbackInfo ci) {
      if (EntityESP.INSTANCE.isEnabled()) {
         ci.cancel();
         return;
      }
      if (BabyMod.useScaledNametag(MinecraftClient.getInstance().player)) {
         float h = playerEntityRenderState.height;
         matrixStack.translate(0.0, (double) ((1.0F - BabyMod.MODEL_SCALE) * h * 0.45F), 0.0);
      }
   }
}
