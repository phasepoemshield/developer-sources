package This.skycore.util.mixin.client;

import com.darkmagician6.eventapi.EventManager;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.base.events.impl.other.EventSpawnEntity;

@Mixin({ClientWorld.class})
public class ClientWorldMixin {
    private final Int2ObjectMap<Entity> entitiesById = new Int2ObjectOpenHashMap<>();
    @Inject(
      method = {"addEntity"},
      at = {@At("RETURN")}
   )
   public void injectAddEntity(Entity entity, CallbackInfo ci) {
      EventSpawnEntity eventSpawnEntity = new EventSpawnEntity(entity);
      EventManager.call(eventSpawnEntity);
   }
    public Iterable<Entity> getAllEntities()
    {
        return this.entitiesById.values();
    }
}
