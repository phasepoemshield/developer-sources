package This.skycore.util.mixin.client.render;

import This.skycore.helpers.WindowStyle;
import This.skycore.helpers.WindowTitleAnimation;
import This.skycore.tyca1337.client.modules.impl.misc.NoPlaceHeadSphere;
import This.skycore.tyca1337.helpers.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.RunArgs;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public abstract class  MinecraftClientMixin implements QuickImports {
    @Shadow
    @Nullable
    public abstract ClientPlayNetworkHandler getNetworkHandler();
    @Shadow @Nullable public ClientPlayerInteractionManager interactionManager;
    @Shadow @Nullable public ClientPlayerEntity player;
    @Shadow @Final
    public GameRenderer gameRenderer;
    @Shadow @Nullable public HitResult crosshairTarget;
    @Shadow @Nullable public Screen currentScreen;
    private WindowTitleAnimation titleUtil;

    @Inject(at = @At("TAIL"), method = "<init>")
    private void onInit(RunArgs args, CallbackInfo ci) {
        if (System.getProperty("java.version").equals("sk3dguard-production-vm")) {
            System.setProperty("sun.font.layout.ffm", "false");
        }
        //    Fonts.init();
        try {
            titleUtil = WindowTitleAnimation.getInstance();
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.getWindow() != null) {
                client.getWindow().setTitle(titleUtil.getCurrentTitle());
            }
        } catch (Exception e) {

        }
    }

    @Inject(at = @At("HEAD"), method = "stop")
    private void stop(CallbackInfo ci) {
        //    Logger.info("Stopping for MinecraftClient");
        try {
            // Skycore skycore = Skycore.getInstance();
            // if (skycore != null && skycore.isInitialized()) {
            //     try {
            //         skycore.getFileController().saveFiles();
            //     } catch (FileProcessingException e) {
            //         Logger.error("Error occurred while saving files: " + e.getMessage() + " " + e.getCause());
            //     } finally {
            //         if (skycore.getFileController() != null) {
            //             skycore.getFileController().stopAutoSave();
            //         }
            //     }
            // }
        } catch (Exception e) {
        }
    }

    @Inject(method = "doItemUse", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Hand;values()[Lnet/minecraft/util/Hand;"), cancellable = true)
    public void doItemUseHook(CallbackInfo ci) {
        if (player == null || interactionManager == null) {
            return;
        }

        // В режиме NoPlayerSpHere с шаром в оффхенде обрабатываем только MAIN_HAND
        // и полностью отменяем ванильный цикл рук, чтобы OFF_HAND не мог поставить шар.
        if (NoPlaceHeadSphere.INSTANCE.isEnabled() && player.getOffHandStack().getItem() == Items.PLAYER_HEAD) {
            if (player.getMainHandStack().isEmpty()) {
                ci.cancel();
                return;
            }

            ActionResult mainResult = ActionResult.PASS;
            HitResult hit = this.crosshairTarget;
            if (hit != null && hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit) {
                mainResult = interactionManager.interactBlock(player, Hand.MAIN_HAND, blockHit);
            }

            if (!mainResult.isAccepted()) {
                mainResult = interactionManager.interactItem(player, Hand.MAIN_HAND);
            }

            if (mainResult.isAccepted()
                    && mainResult instanceof ActionResult.Success success
                    && success.swingSource().equals(ActionResult.SwingSource.CLIENT)) {
                gameRenderer.firstPersonRenderer.resetEquipProgress(Hand.MAIN_HAND);
                player.swingHand(Hand.MAIN_HAND);
            }

            ci.cancel();
            return;
        }

        for (Hand hand : Hand.values()) {
            if (player.getStackInHand(hand).isEmpty()) continue;
            ActionResult result = ActionResult.PASS;

            // Keep vanilla order: block interaction first, then item use.
            HitResult hit = this.crosshairTarget;
            if (hit != null && hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit) {
                result = interactionManager.interactBlock(player, hand, blockHit);
            }

            if (!result.isAccepted()) {
                result = interactionManager.interactItem(player, hand);
            }

            if (result.isAccepted()) {
                if (result instanceof ActionResult.Success success && success.swingSource().equals(ActionResult.SwingSource.CLIENT)) {
                    gameRenderer.firstPersonRenderer.resetEquipProgress(hand);
                    player.swingHand(hand);
                }
                ci.cancel();
                return;
            }
        }
    }


    @Inject(method = "onResolutionChanged", at = @At("TAIL"))
    private void applyDarkMode(CallbackInfo ci) {
        try {
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("linux")) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.getWindow() != null) {
                WindowStyle.setDarkMode(client.getWindow().getHandle());
            }
        } catch (Exception e) {

        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        try {
            if (titleUtil == null) {
                titleUtil = WindowTitleAnimation.getInstance();
            }
            titleUtil.updateTitle();
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.getWindow() != null) {
                client.getWindow().setTitle(titleUtil.getCurrentTitle());
            }
        } catch (Exception e) {

        }
    }

    @Inject(method = "updateWindowTitle", at = @At("HEAD"), cancellable = true)
    private void onUpdateWindowTitle(CallbackInfo ci) {
        try {
            if (titleUtil == null) {
                titleUtil = WindowTitleAnimation.getInstance();
            }
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.getWindow() != null) {
                client.getWindow().setTitle(titleUtil.getCurrentTitle());
            }
            ci.cancel();
        } catch (Exception e) {

        }
    }

    @Inject(method = "handleInputEvents", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getInventory()Lnet/minecraft/entity/player/PlayerInventory;"), cancellable = true)
    public void handleInputEventsHook(CallbackInfo ci) {
        // HotBarUpdateEvent event = new HotBarUpdateEvent();
        //    EventManager.callEvent(event);
        //  if (event.isCancelled()) ci.cancel();
    }
}