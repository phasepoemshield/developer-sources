package This.skycore.util.render.display.base;

import lombok.Generated;
import net.minecraft.util.Identifier;
import This.skycore.SkyCore;

public class CustomSprite {
   private final Identifier texture;

   public CustomSprite(String path) {
      if (path.contains(":")) {
         this.texture = Identifier.of(path);
      } else if (path.contains("/")) {
         this.texture = SkyCore.id(path);
      } else {
         this.texture = SkyCore.id("icons/category/" + path);
      }

   }

   @Generated
   public Identifier getTexture() {
      return this.texture;
   }
}
