package This.skycore.util.math;

import java.util.ArrayList;
import java.util.List;

public class Script {
    private final List<Step> steps = new ArrayList<>();
    private int currentTick = 0;

    public Script addTickStep(int delay, Runnable action) {
        steps.add(new Step(currentTick + delay, action));
        return this;
    }

    public void update() {
        List<Step> toExecute = new ArrayList<>();
        steps.removeIf(step -> {
            if (currentTick >= step.tick) {
                toExecute.add(step);
                return true;
            }
            return false;
        });
        toExecute.forEach(step -> step.action.run());
        currentTick++;
    }

    public Script cleanup() {
        steps.clear();
        currentTick = 0;
        return this;
    }

    public boolean isFinished() {
        return steps.isEmpty();
    }

    private record Step(int tick, Runnable action) {}
}
