package This.skycore.util.mixin.client.render.gui.screen;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.tyca1337.client.modules.impl.render.Animations;

@Mixin(InventoryScreen.class)
public class InventoryScreenMixin {

    @Unique
    private boolean skycore$animPushed;

    @Inject(method = "render", at = @At("HEAD"))
    private void skycore$renderHead(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        this.skycore$animPushed = false;
    }

    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/Screen;renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V",
                    shift = At.Shift.AFTER
            ),
            require = 0
    )
    private void skycore$startInventoryScaleAfterScreenBackground(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        this.skycore$tryStartScale(context);
    }

    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/ingame/InventoryScreen;renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V",
                    shift = At.Shift.AFTER
            ),
            require = 0
    )
    private void skycore$startInventoryScaleAfterInventoryBackground(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        this.skycore$tryStartScale(context);
    }

    @Unique
    private void skycore$tryStartScale(DrawContext context) {
        if (this.skycore$animPushed) {
            return;
        }
        Animations animations = Animations.INSTANCE;
        if (!animations.isModeEnabled("Инвентарь")) {
            return;
        }

        animations.getOpenScaleAnim().update(1.0F);
        float scale = animations.getOpenScaleAnim().getValue();
        float cx = (float) MinecraftClient.getInstance().getWindow().getScaledWidth() / 2.0F;
        float cy = (float) MinecraftClient.getInstance().getWindow().getScaledHeight() / 2.0F;
        context.getMatrices().push();
        context.getMatrices().translate(cx, cy, 0.0F);
        context.getMatrices().scale(scale, scale, 1.0F);
        context.getMatrices().translate(-cx, -cy, 0.0F);
        this.skycore$animPushed = true;
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void skycore$renderReturn(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.skycore$animPushed) {
            context.getMatrices().pop();
            this.skycore$animPushed = false;
        }
    }
}
