package This.skycore.util.mixin.client;

import com.darkmagician6.eventapi.EventManager;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import This.skycore.tyca1337.client.modules.impl.combat.NoControllerWeb;
import This.skycore.tyca1337.client.modules.impl.player.NoPush;
import This.skycore.utils.events.EventBlockCollide;

@Mixin({Entity.class})
public class EntityMixin {
   @ModifyExpressionValue(
      method = {"move"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;isControlledByPlayer()Z"
)}
   )
   public boolean fixFalldistanceValue(boolean original) {
      return (Object)this == MinecraftClient.getInstance().player ? false : original;
   }

   @Inject(
      method = {"pushAwayFrom"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void pushAwayFrom(CallbackInfo ci) {
      if ((Object)this == MinecraftClient.getInstance().player && NoPush.INSTANCE.isEnabled() && NoPush.INSTANCE.getObjects().isEnable("Игроки")) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"isPushedByFluids"},
      at = {@At("RETURN")},
      cancellable = true
   )
   public void isPushedByFluids(CallbackInfoReturnable<Boolean> cir) {
      if ((Object)this == MinecraftClient.getInstance().player && NoPush.INSTANCE.isEnabled() && NoPush.INSTANCE.getObjects().isEnable("Вода")) {
         cir.setReturnValue(false);
      }

   }

   @Inject(
      method = "collidesWithStateAtPos",
      at = @At("HEAD"),
      cancellable = true
   )
   private void skycore$noControllerWeb(BlockPos pos, BlockState state, CallbackInfoReturnable<Boolean> cir) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || (Object) this != mc.player) {
         return;
      }
      if (!NoControllerWeb.INSTANCE.isEnabled() || !state.isOf(Blocks.COBWEB)) {
         return;
      }
      EventBlockCollide event = new EventBlockCollide(pos);
      EventManager.call(event);
      if (event.isCancelled()) {
         cir.setReturnValue(false);
      }
   }
}
