package This.skycore.util.mixin.minecraft.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DimensionEffects;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.tyca1337.client.modules.impl.render.CustomSky;
import This.skycore.util.render.sky.OptifineSkyLoader;
import This.skycore.util.render.sky.OptifineSkyRenderer;

@Mixin(SkyRendering.class)
public class SkyRenderingMixin {

    @Inject(method = "renderSky", at = @At("HEAD"), cancellable = true)
    private void skycore$customSkyOverworld(float red, float green, float blue, CallbackInfo ci) {
        if (!CustomSky.affectsSky()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        if (client.world.getDimensionEffects().getSkyType() != DimensionEffects.SkyType.NORMAL) {
            return;
        }
        if (!OptifineSkyLoader.INSTANCE.hasOverworldLayers()) {
            return;
        }
        float tickDelta = client.getRenderTickCounter().getTickDelta(true);
        OptifineSkyRenderer.renderOverworld(client.world, tickDelta, red, green, blue);
        ci.cancel();
    }

    @Inject(method = "renderEndSky", at = @At("HEAD"), cancellable = true)
    private void skycore$customSkyEnd(CallbackInfo ci) {
        if (!CustomSky.affectsSky()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        if (!OptifineSkyLoader.INSTANCE.hasEndLayers()) {
            return;
        }
        float tickDelta = client.getRenderTickCounter().getTickDelta(true);
        OptifineSkyRenderer.renderEnd(client.world, tickDelta);
        ci.cancel();
    }
}
