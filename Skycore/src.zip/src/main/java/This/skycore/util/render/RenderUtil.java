package This.skycore.util.render;

import com.google.common.base.Suppliers;
import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.function.Supplier;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import This.skycore.util.render.display.base.BorderRadius;
import This.skycore.util.render.display.base.color.ColorRGBA;
import This.skycore.util.render.display.shader.DrawUtil;
import This.skycore.util.interfaces.IMinecraft;

/**
 * 2D helpers ported from legacy SkyCore; uses {@link ShaderUtil} programs when available, otherwise {@link DrawUtil}.
 */
public final class RenderUtil implements IMinecraft {

    private static int vao;
    private static int vbo;
    private static final Supplier<SimpleFramebuffer> BLUR_SNAPSHOT_FBO = Suppliers.memoize(() -> new SimpleFramebuffer(1920, 1024, false));
    private static final FloatBuffer QUAD_BUFFER = ByteBuffer.allocateDirect(80)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer();

    private RenderUtil() {
    }

    private static void ensureVao() {
        if (vao != 0) {
            return;
        }
        vao = GL30.glGenVertexArrays();
        vbo = GL15.glGenBuffers();
        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL20.glEnableVertexAttribArray(0);
        GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, 20, 0);
        GL20.glEnableVertexAttribArray(1);
        GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 20, 12);
        GL30.glBindVertexArray(0);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
    }

    private static void uploadLocalTexturedQuad(float w, float h) {
        QUAD_BUFFER.clear();
        float[] data = {
                0, 0, 0, 0, 0,
                0, h, 0, 0, 1,
                w, h, 0, 1, 1,
                w, 0, 0, 1, 0
        };
        QUAD_BUFFER.put(data);
        QUAD_BUFFER.flip();
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, QUAD_BUFFER, GL15.GL_STREAM_DRAW);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
    }

    private static void drawTexturedQuadFan() {
        int prevVao = GL30.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        int prevBuf = GL15.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL11.glDrawArrays(GL11.GL_TRIANGLE_FAN, 0, 4);
        GL30.glBindVertexArray(prevVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, prevBuf);
    }

    /**
     * {@code assets/.../circle.glsl} vertex stage does {@code gl_Position = Transform * vec4(Position,1)} — must be clip space,
     * not only stack translate (otherwise arcs are clipped and invisible on HUD).
     */
    private static Matrix4f circleClipTransform(MatrixStack matrices) {
        return new Matrix4f(RenderSystem.getProjectionMatrix())
                .mul(RenderSystem.getModelViewMatrix())
                .mul(new Matrix4f(matrices.peek().getPositionMatrix()));
    }

    /**
     * Draws the internal textured quad after uniforms (including {@code Transform}) are set on the currently bound legacy GL program.
     */
    public static void drawPreparedLegacyTexturedQuad(float width, float height) {
        RenderSystem.assertOnRenderThread();
        ensureVao();
        uploadLocalTexturedQuad(width, height);
        RenderSystem.disableDepthTest();
        drawTexturedQuadFan();
        RenderSystem.enableDepthTest();
    }

    private static void rgba(int argb, float[] out) {
        out[0] = ((argb >> 16) & 0xFF) / 255.0f;
        out[1] = ((argb >> 8) & 0xFF) / 255.0f;
        out[2] = (argb & 0xFF) / 255.0f;
        int a = (argb >> 24) & 0xFF;
        out[3] = (a == 0 ? 1.0f : a / 255.0f);
    }

    private static final float[] TMP_RGBA = new float[4];

    public static void drawRoundedRectangle(MatrixStack matrices, float x, float y, float width, float height, float radius, int colorArgb) {
        if (!ShaderUtil.isRoundedRectangleReady()) {
            DrawUtil.drawRoundedRect(matrices, x, y, width, height, BorderRadius.all(radius), new ColorRGBA(colorArgb));
            return;
        }
        RenderSystem.assertOnRenderThread();
        ensureVao();
        matrices.push();
        matrices.translate(x, y, 0);
        Matrix4f mat = new Matrix4f(matrices.peek().getPositionMatrix());
        matrices.pop();

        uploadLocalTexturedQuad(width, height);
        ShaderUtil.LegacyGlProgram prog = ShaderUtil.roundedRectangleProgram();
        prog.attach();
        prog.uniformMatrix4f("Transform", mat);
        prog.uniform2f("size", width, height);
        prog.uniform4f("radius", radius, radius, radius, radius);
        rgba(colorArgb, TMP_RGBA);
        prog.uniform4f("color", TMP_RGBA[0], TMP_RGBA[1], TMP_RGBA[2], TMP_RGBA[3]);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        drawTexturedQuadFan();
        RenderSystem.enableDepthTest();
        prog.detach();
    }

    public static void drawCircle(MatrixStack matrices, float centerX, float centerY, float radius, int colorArgb) {
        if (!ShaderUtil.isCircleReady() || radius <= 0.0f) {
            DrawUtil.drawCircle(matrices, centerX, centerY, radius, new ColorRGBA(colorArgb));
            return;
        }
        RenderSystem.assertOnRenderThread();
        ensureVao();
        float diameter = radius * 2.0f;
        matrices.push();
        matrices.translate(centerX - radius, centerY - radius, 0);
        Matrix4f mat = circleClipTransform(matrices);
        matrices.pop();

        uploadLocalTexturedQuad(diameter, diameter);
        ShaderUtil.LegacyGlProgram prog = ShaderUtil.circleProgram();
        prog.attach();
        prog.uniformMatrix4f("Transform", mat);
        prog.uniform2f("size", diameter, diameter);
        rgba(colorArgb, TMP_RGBA);
        prog.uniform4f("color", TMP_RGBA[0], TMP_RGBA[1], TMP_RGBA[2], TMP_RGBA[3]);
        prog.uniform1f("radius", radius);
        prog.uniform1f("startAngle", 0.0f);
        prog.uniform1f("endAngle", 360.0f);
        prog.uniform1f("thickness", radius);
        prog.uniform1f("smoothness", 1.5f);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        drawTexturedQuadFan();
        RenderSystem.enableDepthTest();
        prog.detach();
    }

    /**
     * Дуга кольца (как legacy RenderUtils.drawCircle с углами): circle shader, {@code thickness} — толщина кольца.
     */
    public static void drawCircleArc(MatrixStack matrices, float centerX, float centerY, float radius,
                                     float startAngleDeg, float endAngleDeg, float thickness, ColorRGBA color) {
        if (radius <= 0.0f || endAngleDeg <= startAngleDeg + 0.01f) {
            return;
        }
        if (!ShaderUtil.isCircleReady()) {
            DrawUtil.drawCircleArc(matrices, centerX, centerY, radius, thickness, startAngleDeg, endAngleDeg, color);
            return;
        }
        RenderSystem.assertOnRenderThread();
        ensureVao();
        float diameter = radius * 2.0f;
        matrices.push();
        matrices.translate(centerX - radius, centerY - radius, 0);
        Matrix4f mat = circleClipTransform(matrices);
        matrices.pop();

        uploadLocalTexturedQuad(diameter, diameter);
        ShaderUtil.LegacyGlProgram prog = ShaderUtil.circleProgram();
        prog.attach();
        prog.uniformMatrix4f("Transform", mat);
        prog.uniform2f("size", diameter, diameter);
        TMP_RGBA[0] = color.getRed() / 255.0f;
        TMP_RGBA[1] = color.getGreen() / 255.0f;
        TMP_RGBA[2] = color.getBlue() / 255.0f;
        TMP_RGBA[3] = color.getAlpha() / 255.0f;
        prog.uniform4f("color", TMP_RGBA[0], TMP_RGBA[1], TMP_RGBA[2], TMP_RGBA[3]);
        prog.uniform1f("radius", radius);
        prog.uniform1f("startAngle", startAngleDeg);
        prog.uniform1f("endAngle", endAngleDeg);
        prog.uniform1f("thickness", Math.max(0.5f, thickness));
        prog.uniform1f("smoothness", 1.5f);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        drawTexturedQuadFan();
        RenderSystem.enableDepthTest();
        prog.detach();
    }

    public static void drawRectangle(MatrixStack matrices, float x, float y, float width, float height, int colorArgb) {
        DrawUtil.drawRect(matrices, x, y, width, height, new ColorRGBA(colorArgb));
    }

    /**
     * Rounded frosted rectangle: snapshot framebuffer, optional radial blur sample, SDF mask (legacy SkyCore style).
     */
    public static void drawBlurredRoundedRectangle(MatrixStack matrices, float x, float y, float width, float height,
                                                   float blurStrength, float cornerRadius, ColorRGBA multiplyColor) {
        if (!ShaderUtil.isBlurredRoundedReady()) {
            DrawUtil.drawBlur(matrices, x, y, width, height, blurStrength, BorderRadius.all(cornerRadius), multiplyColor);
            return;
        }
        RenderSystem.assertOnRenderThread();
        ensureVao();

        Framebuffer main = mc.getFramebuffer();
        SimpleFramebuffer fbo = BLUR_SNAPSHOT_FBO.get();
        if (fbo.textureWidth != main.textureWidth || fbo.textureHeight != main.textureHeight) {
            fbo.resize(main.textureWidth, main.textureHeight);
        }

        fbo.beginWrite(false);
        main.draw(fbo.textureWidth, fbo.textureHeight);
        main.beginWrite(false);

        int texId = fbo.getColorAttachment();
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texId);

        matrices.push();
        matrices.translate(x, y, 0);
        Matrix4f mat = new Matrix4f(matrices.peek().getPositionMatrix());
        matrices.pop();

        uploadLocalTexturedQuad(width, height);
        ShaderUtil.LegacyGlProgram prog = ShaderUtil.blurredRoundedRectangleProgram();
        prog.attach();
        prog.uniform1i("blurredTexture", 0);
        prog.uniform2f("resolution", (float) main.textureWidth, (float) main.textureHeight);
        prog.uniform2f("size", width, height);
        prog.uniform4f("round", cornerRadius, cornerRadius, cornerRadius, cornerRadius);
        prog.uniform1f("blurStrength", blurStrength);
        prog.uniform4f("modulate",
                multiplyColor.getRed() / 255.0f,
                multiplyColor.getGreen() / 255.0f,
                multiplyColor.getBlue() / 255.0f,
                multiplyColor.getAlpha() / 255.0f);
        prog.uniformMatrix4f("Transform", mat);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        drawTexturedQuadFan();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        prog.detach();
        RenderSystem.setShaderTexture(0, 0);
    }
}
