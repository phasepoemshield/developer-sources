package This.skycore.util.mixin.client;

import This.skycore.tyca1337.client.modules.impl.combat.Aura;
import com.google.common.base.MoreObjects;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.item.HeldItemRenderer.HandRenderType;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.tyca1337.client.modules.impl.render.SwingAnimation;
import This.skycore.tyca1337.client.modules.impl.render.ViewModel;
import This.skycore.tyca1337.client.modules.impl.player.AutoTool;

@Mixin(value = HeldItemRenderer.class, priority = 900)
public abstract class HeldItemRendererMixin {
    @Shadow
    private ItemStack field_4047;
    @Shadow
    private ItemStack field_4048;
    @Shadow
    private float field_4043;
    @Shadow
    private float field_4053;
    @Shadow
    private float field_4052;
    @Shadow
    private float field_4051;

    @Shadow
    protected abstract void renderFirstPersonItem(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light
    );

    @Shadow
    protected abstract void method_65816(
            float swingProgress,
            float equipProgress,
            MatrixStack matrices,
            int armX,
            Arm arm
    );

    // ======== ViewModel инжекты ========

    /**
     * Vanilla HeldItemRenderer#renderItem adds subtle extra rotations before calling
     * renderFirstPersonItem, which looks like hand "shake/sway" during camera movement.
     *
     * This overwrite keeps vanilla hand selection + equip progress logic, but skips those
     * pre-rotations entirely (same idea as the code you sent).
     */
    @Overwrite
    public void renderItem(float tickDelta, MatrixStack matrices, Immediate vertexConsumers, ClientPlayerEntity player, int light) {
        float swing = player.getHandSwingProgress(tickDelta);
        Hand preferredHand = MoreObjects.firstNonNull(player.preferredHand, Hand.MAIN_HAND);
        float pitch = player.getLerpedPitch(tickDelta);

        HandRenderType type = HeldItemRenderer.getHandRenderType(player);
        float handSwing;
        float equipProgress;

        if (type.renderMainHand) {
            handSwing = preferredHand == Hand.MAIN_HAND ? swing : 0.0F;
            equipProgress = 1.0F - MathHelper.lerp(tickDelta, this.field_4053, this.field_4043);
            this.renderFirstPersonItem(player, tickDelta, pitch, Hand.MAIN_HAND, handSwing, this.field_4047, equipProgress, matrices, vertexConsumers, light);
        }

        if (type.renderOffHand) {
            handSwing = preferredHand == Hand.OFF_HAND ? swing : 0.0F;
            equipProgress = 1.0F - MathHelper.lerp(tickDelta, this.field_4051, this.field_4052);
            this.renderFirstPersonItem(player, tickDelta, pitch, Hand.OFF_HAND, handSwing, this.field_4048, equipProgress, matrices, vertexConsumers, light);
        }

        vertexConsumers.draw();
    }

     @Inject(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
                    ordinal = 0
            )
    )
    private void injectBeforeRenderCrossBowItem(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        ViewModel viewModel = ViewModel.INSTANCE;
        if (viewModel.isEnabled()) {
            boolean isMainHand = hand == Hand.MAIN_HAND;
            Arm arm = isMainHand
                    ? player.getMainArm()
                    : player.getMainArm().getOpposite();
            viewModel.applyHandScale(matrices, arm);
        }
    }

    @Inject(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
                    ordinal = 1
            )
    )
    private void injectBeforeRenderItem(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        ViewModel viewModel = ViewModel.INSTANCE;
        if (viewModel.isEnabled()) {
            boolean isMainHand = hand == Hand.MAIN_HAND;
            Arm arm = isMainHand
                    ? player.getMainArm()
                    : player.getMainArm().getOpposite();
            viewModel.applyHandScale(matrices, arm);
        }
    }

    @Inject(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
                    shift = Shift.AFTER,
                    ordinal = 0
            )
    )
    private void injectAfterMatrixPushHandPosition(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        ViewModel viewModel = ViewModel.INSTANCE;
        if (viewModel.isEnabled()
                && !item.isEmpty()
                && !item.contains(DataComponentTypes.MAP_ID)) {
            boolean isMainHand = hand == Hand.MAIN_HAND;
            Arm arm = isMainHand
                    ? player.getMainArm()
                    : player.getMainArm().getOpposite();
            viewModel.applyHandPosition(matrices, arm);
        }
    }

    // ======== SwingAnimation редирект ========

    @org.spongepowered.asm.mixin.Unique
    private static boolean skycore$useCameraForAuraHands() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc != null
                && mc.options.getPerspective() == net.minecraft.client.option.Perspective.FIRST_PERSON
                && Aura.INSTANCE != null
                && Aura.INSTANCE.isEnabled()
                && mc.gameRenderer != null
                && mc.gameRenderer.getCamera() != null;
    }

    @Redirect(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;getPitch()F"
            ),
            require = 0
    )
    private float skycore$handsPitchFromCamera(AbstractClientPlayerEntity player) {
        if (skycore$useCameraForAuraHands()) {
            return MinecraftClient.getInstance().gameRenderer.getCamera().getPitch();
        }
        return player.getPitch();
    }

    @Redirect(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;getYaw()F"
            ),
            require = 0
    )
    private float skycore$handsYawFromCamera(AbstractClientPlayerEntity player) {
        if (skycore$useCameraForAuraHands()) {
            return MinecraftClient.getInstance().gameRenderer.getCamera().getYaw();
        }
        return player.getYaw();
    }

    @Redirect(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;swingArm(FFLnet/minecraft/client/util/math/MatrixStack;ILnet/minecraft/util/Arm;)V",
                    ordinal = 2
            )
    )
    private void redirectSwingArmForCustomAnim(
            HeldItemRenderer instance,
            float swingProgress,
            float equipProgress,
            MatrixStack matrices,
            int armX,
            Arm arm
    ) {
        SwingAnimation swingAnimation = SwingAnimation.INSTANCE;
        if (swingAnimation.isEnabled()) {
            if (arm == Arm.RIGHT) {
                swingAnimation.renderSwordAnimation(
                        matrices, swingProgress, equipProgress, arm
                );
            } else {
                this.method_65816(swingProgress, equipProgress, matrices, armX, arm);
            }
        } else {
            this.method_65816(swingProgress, equipProgress, matrices, armX, arm);
        }
    }

    // AutoTool: подмена стека главной руки без @Overwrite renderItem (совместимость с Hold My Items и др.)

    @ModifyArg(
            method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
                    ordinal = 0
            ),
            index = 5
    )
    private ItemStack skycore$autotoolMainHandStack(ItemStack stack) {
        int visualSlot = AutoTool.getVisualSlot();
        if (visualSlot != -1 && visualSlot < 9) {
            ClientPlayerEntity player = MinecraftClient.getInstance().player;
            if (player != null) {
                return player.getInventory().getStack(visualSlot);
            }
        }
        return stack;
    }

}
