package This.skycore.util.render.sky;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.MathHelper;
import org.joml.AxisAngle4f;
import org.joml.Matrix4f;

/**
 * OptiFine custom sky: внутренний купол (верхняя полусфера), UV как у типичного custom sky в OptiFine.
 */
public final class OptifineSkyRenderer {
    /** Дальше камеры — меньше искажения «пузыря». */
    private static final float RADIUS = 4096f;
    private static final int SLICES = 64;
    private static final int STACKS = 32;
    /** Угол от зенита (+Y) до горизонта (π/2). */
    private static final float HEMI = (float) (Math.PI * 0.5);

    private OptifineSkyRenderer() {
    }

    public static void renderOverworld(ClientWorld world, float tickDelta, float br, float bg, float bb) {
        render(world, tickDelta, br, bg, bb, OptifineSkyLoader.INSTANCE.getLayersForOverworld());
    }

    public static void renderEnd(ClientWorld world, float tickDelta) {
        render(world, tickDelta, 0.08f, 0.02f, 0.12f, OptifineSkyLoader.INSTANCE.getLayersForEnd());
    }

    private static void render(ClientWorld world, float tickDelta, float br, float bg, float bb, List<OptifineSkyLayer> layers) {
        if (layers.isEmpty()) {
            return;
        }

        try {
            RenderSystem.depthMask(false);
            RenderSystem.disableDepthTest();
            RenderSystem.disableCull();

            drawBaseGradient(br, bg, bb);

            for (OptifineSkyLayer layer : layers) {
                if (!weatherMatches(layer, world)) {
                    continue;
                }
                float bright = layerBrightness(layer, world.getTimeOfDay());
                if (bright <= 0.001f) {
                    continue;
                }

                Matrix4f mat = new Matrix4f(RenderSystem.getModelViewMatrix());
                if (layer.rotate) {
                    float ax = layer.axisX;
                    float ay = layer.axisY;
                    float az = layer.axisZ;
                    float len = MathHelper.sqrt(ax * ax + ay * ay + az * az);
                    if (len > 1e-4f) {
                        ax /= len;
                        ay /= len;
                        az /= len;
                    } else {
                        ax = 0;
                        ay = 0;
                        az = 1;
                    }
                    float ang = ((world.getTimeOfDay() % 24000L) + tickDelta) / 24000f * ((float) Math.PI * 2f) * layer.speed;
                    mat.mul(new Matrix4f().rotation(new AxisAngle4f(ang, ax, ay, az)));
                }

                RenderSystem.enableBlend();
                RenderSystem.blendFunc(layer.blend.src, layer.blend.dst);
                RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
                RenderSystem.setShaderTexture(0, layer.texture);

                int a = Math.min(255, Math.round(255 * bright));
                BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
                tessellateDome(mat, buffer, a);
                BufferRenderer.drawWithGlobalProgram(buffer.end());
            }

            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
        } finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
        }
    }

    private static void drawBaseGradient(float br, float bg, float bb) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SrcFactor.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Matrix4f mat = new Matrix4f(RenderSystem.getModelViewMatrix());
        int top = Math.min(255, (int) (255 * Math.min(1f, (br + bg + bb) / 3f * 1.4f + 0.15f)));
        int bot = Math.min(255, (int) (255 * (br * 0.6f + 0.05f)));
        int rT = (int) (br * top), gT = (int) (bg * top), bT = (int) (bb * top);
        int rB = (int) (br * bot), gB = (int) (bg * bot), bB = (int) (bb * bot);
        BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        tessellateDomeColor(mat, buffer, rT, gT, bT, rB, gB, bB);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.disableBlend();
    }

    /** Купол: phi от 0 (зенит +Y) до π/2 (горизонт). */
    private static void tessellateDomeColor(Matrix4f mat, BufferBuilder buffer, int rT, int gT, int bT, int rB, int gB, int bB) {
        for (int lat = 0; lat < STACKS; lat++) {
            float v0 = (float) lat / STACKS;
            float v1 = (float) (lat + 1) / STACKS;
            float phi0 = v0 * HEMI;
            float phi1 = v1 * HEMI;
            float y0 = RADIUS * (float) Math.cos(phi0);
            float y1 = RADIUS * (float) Math.cos(phi1);
            float r0 = RADIUS * (float) Math.sin(phi0);
            float r1 = RADIUS * (float) Math.sin(phi1);
            int c0r = MathHelper.lerp(v0, rB, rT);
            int c0g = MathHelper.lerp(v0, gB, gT);
            int c0b = MathHelper.lerp(v0, bB, bT);
            int c1r = MathHelper.lerp(v1, rB, rT);
            int c1g = MathHelper.lerp(v1, gB, gT);
            int c1b = MathHelper.lerp(v1, bB, bT);
            for (int lon = 0; lon < SLICES; lon++) {
                float u0 = (float) lon / SLICES;
                float u1 = (float) (lon + 1) / SLICES;
                double th0 = u0 * Math.PI * 2;
                double th1 = u1 * Math.PI * 2;
                float x00 = r0 * (float) Math.sin(th0);
                float z00 = r0 * (float) Math.cos(th0);
                float x01 = r0 * (float) Math.sin(th1);
                float z01 = r0 * (float) Math.cos(th1);
                float x10 = r1 * (float) Math.sin(th0);
                float z10 = r1 * (float) Math.cos(th0);
                float x11 = r1 * (float) Math.sin(th1);
                float z11 = r1 * (float) Math.cos(th1);
                buffer.vertex(mat, x00, y0, z00).color(c0r, c0g, c0b, 255);
                buffer.vertex(mat, x01, y0, z01).color(c0r, c0g, c0b, 255);
                buffer.vertex(mat, x11, y1, z11).color(c1r, c1g, c1b, 255);
                buffer.vertex(mat, x10, y1, z10).color(c1r, c1g, c1b, 255);
            }
        }
    }

    /**
     * Внутренний купол: текстура от зенита (v≈0) к горизонту (v≈1), по кругу u 0…1 (как в OptiFine custom sky).
     */
    private static void tessellateDome(Matrix4f mat, BufferBuilder buffer, int alpha) {
        for (int lat = 0; lat < STACKS; lat++) {
            float v0 = (float) lat / STACKS;
            float v1 = (float) (lat + 1) / STACKS;
            float phi0 = v0 * HEMI;
            float phi1 = v1 * HEMI;
            float y0 = RADIUS * (float) Math.cos(phi0);
            float y1 = RADIUS * (float) Math.cos(phi1);
            float r0 = RADIUS * (float) Math.sin(phi0);
            float r1 = RADIUS * (float) Math.sin(phi1);
            float texV0 = phi0 / HEMI;
            float texV1 = phi1 / HEMI;
            for (int lon = 0; lon < SLICES; lon++) {
                float u0 = (float) lon / SLICES;
                float u1 = (float) (lon + 1) / SLICES;
                double th0 = u0 * Math.PI * 2;
                double th1 = u1 * Math.PI * 2;
                float x00 = r0 * (float) Math.sin(th0);
                float z00 = r0 * (float) Math.cos(th0);
                float x01 = r0 * (float) Math.sin(th1);
                float z01 = r0 * (float) Math.cos(th1);
                float x10 = r1 * (float) Math.sin(th0);
                float z10 = r1 * (float) Math.cos(th0);
                float x11 = r1 * (float) Math.sin(th1);
                float z11 = r1 * (float) Math.cos(th1);
                buffer.vertex(mat, x00, y0, z00).texture(u0, texV0).color(255, 255, 255, alpha);
                buffer.vertex(mat, x01, y0, z01).texture(u1, texV0).color(255, 255, 255, alpha);
                buffer.vertex(mat, x11, y1, z11).texture(u1, texV1).color(255, 255, 255, alpha);
                buffer.vertex(mat, x10, y1, z10).texture(u0, texV1).color(255, 255, 255, alpha);
            }
        }
    }

    private static boolean weatherMatches(OptifineSkyLayer layer, ClientWorld world) {
        int m = layer.weatherMask;
        boolean clear = !world.isRaining() && !world.isThundering();
        boolean rain = world.isRaining();
        boolean thunder = world.isThundering();
        if ((m & 1) != 0 && clear) {
            return true;
        }
        if ((m & 2) != 0 && rain) {
            return true;
        }
        return (m & 4) != 0 && thunder;
    }

    /**
     * Яркость слоя по fade (OptiFine hh:mm). Учитывает окно через полночь (типично: ночной слой 18:00–6:00).
     */
    private static float layerBrightness(OptifineSkyLayer layer, long worldTime) {
        if (!layer.hasFade) {
            return 1f;
        }
        int t = (int) (worldTime % 24000L);
        int sfi = layer.startFadeIn != Integer.MIN_VALUE ? layer.startFadeIn : 0;
        int efi = layer.endFadeIn != Integer.MIN_VALUE ? layer.endFadeIn : sfi;
        int sfo = layer.startFadeOut != Integer.MIN_VALUE ? layer.startFadeOut : 24000;
        int efo = layer.endFadeOut != Integer.MIN_VALUE ? layer.endFadeOut : 24000;
        if (efi <= sfi) {
            efi = Math.min(sfi + 1, 23999);
        }
        // Fade-out через полночь: startFadeOut > endFadeOut (например 5:00 → 6:00)
        if (sfo > efo) {
            if (inSemiOpenWrap(t, sfo, efo)) {
                int span = (efo - sfo + 24000) % 24000;
                if (span <= 0) {
                    return 1f;
                }
                int pos = (t - sfo + 24000) % 24000;
                return lerp(1f, 0f, pos / (float) span);
            }
            if (t >= sfi && t < efi) {
                return lerp(0f, 1f, (t - sfi) / (float) Math.max(1, efi - sfi));
            }
            if (t >= efi && t < sfo) {
                return 1f;
            }
            return 0f;
        }
        // Обычный порядок на шкале 0…24000
        if (t < sfi) {
            return 0f;
        }
        if (t < efi) {
            return lerp(0f, 1f, (t - sfi) / (float) Math.max(1, efi - sfi));
        }
        if (t < sfo) {
            return 1f;
        }
        if (t < efo) {
            return lerp(1f, 0f, (t - sfo) / (float) Math.max(1, efo - sfo));
        }
        return 0f;
    }

    /** Полуинтервал [start, end) по кругу 0…24000; если start > end — через 0. */
    private static boolean inSemiOpenWrap(int t, int start, int end) {
        if (start < end) {
            return t >= start && t < end;
        }
        if (start > end) {
            return t >= start || t < end;
        }
        return false;
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * MathHelper.clamp(t, 0f, 1f);
    }
}
