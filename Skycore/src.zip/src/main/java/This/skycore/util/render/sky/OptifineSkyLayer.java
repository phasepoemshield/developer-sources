package This.skycore.util.render.sky;

import net.minecraft.util.Identifier;

/**
 * One OptiFine custom sky layer ({@code optifine/sky/worldN/sky*.properties}).
 */
public final class OptifineSkyLayer {
    public final int order;
    public final Identifier texture;
    public final OptifineSkyBlend blend;
    public final boolean rotate;
    public final float speed;
    public final float axisX;
    public final float axisY;
    public final float axisZ;
    /** Fade edges in world ticks 0–24000; absent entries are {@link Integer#MIN_VALUE}. */
    public final int startFadeIn;
    public final int endFadeIn;
    public final int startFadeOut;
    public final int endFadeOut;
    public final boolean hasFade;
    public final int weatherMask; // bit 1 clear, 2 rain, 4 thunder

    public OptifineSkyLayer(
            int order,
            Identifier texture,
            OptifineSkyBlend blend,
            boolean rotate,
            float speed,
            float axisX,
            float axisY,
            float axisZ,
            int startFadeIn,
            int endFadeIn,
            int startFadeOut,
            int endFadeOut,
            boolean hasFade,
            int weatherMask
    ) {
        this.order = order;
        this.texture = texture;
        this.blend = blend;
        this.rotate = rotate;
        this.speed = speed;
        this.axisX = axisX;
        this.axisY = axisY;
        this.axisZ = axisZ;
        this.startFadeIn = startFadeIn;
        this.endFadeIn = endFadeIn;
        this.startFadeOut = startFadeOut;
        this.endFadeOut = endFadeOut;
        this.hasFade = hasFade;
        this.weatherMask = weatherMask;
    }
}
