package This.skycore.util.game.player.rotation;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import This.skycore.util.game.other.SensUtil;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.math.MultipointUtils;

import static net.minecraft.util.math.MathHelper.wrapDegrees;
import static java.lang.Math.*;

public class ReallyWorldRotation implements IMinecraft {
    private Rotation rotation = new Rotation(0, 0);
    
    public void update(LivingEntity target, float distance) {
        if (Float.isNaN(this.rotation.getYaw())) this.rotation = new Rotation(0, this.rotation.getPitch());
        if (Float.isNaN(this.rotation.getPitch())) this.rotation = new Rotation(this.rotation.getYaw(), 0);
        
        Vec3d vec = calculateTargetVector(target, distance);
        
        float yawToTarget = (float) wrapDegrees(toDegrees(atan2(vec.z, vec.x)) - 90.0);
        float pitchToTarget = (float) (-toDegrees(atan2(vec.y, hypot(vec.x, vec.z))));
        
        float yawDelta = wrapDegrees(yawToTarget - this.rotation.getYaw());
        float pitchDelta = wrapDegrees(pitchToTarget - this.rotation.getPitch());
        
        float clampedYaw = Math.max(Math.abs(yawDelta), 0.0f);
        float clampedPitch = Math.max(Math.abs(pitchDelta), 0.0f);
        
        float yaw = this.rotation.getYaw() + (yawDelta > 0 ? clampedYaw : -clampedYaw);
        float pitch = MathHelper.clamp(this.rotation.getPitch() + (pitchDelta > 0 ? clampedPitch : -clampedPitch), -89.0F, 89.0F);
        
        float gcd = SensUtil.getGCDValue();
        yaw -= (yaw - this.rotation.getYaw()) % gcd;
        pitch -= (pitch - this.rotation.getPitch()) % gcd;
        
        this.rotation = new Rotation(yaw, pitch);
    }
    
    private Vec3d calculateTargetVector(LivingEntity target, float distance) {
        Vec3d eyes = mc.player.getEyePos();
        Vec3d targetPoint = MultipointUtils.getNearestPoint(target, (double)distance);
        return targetPoint.subtract(eyes);
    }
    
    public Rotation getRotation() {
        return this.rotation;
    }
    
    public void setRotation(Rotation rotation) {
        this.rotation = rotation;
    }
}