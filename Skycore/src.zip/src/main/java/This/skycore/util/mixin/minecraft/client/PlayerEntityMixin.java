package This.skycore.util.mixin.minecraft.client;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import This.skycore.util.capes.CapeHolder;
import This.skycore.util.capes.sim.StickSimulation;

/**
 * Mixin, добавляющий к клиентскому игроку поддержку симуляции плаща.
 */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class PlayerEntityMixin implements CapeHolder {

    @Unique
    private StickSimulation stickSimulation = new StickSimulation();

    @Override
    public StickSimulation getSimulation() {
        return stickSimulation;
    }
}

