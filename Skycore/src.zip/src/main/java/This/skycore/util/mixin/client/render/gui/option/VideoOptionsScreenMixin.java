package This.skycore.util.mixin.client.render.gui.option;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import java.util.Arrays;
import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import This.skycore.util.client.SkycoreVideoPackSkyOption;

@Mixin(VideoOptionsScreen.class)
public class VideoOptionsScreenMixin {

    @ModifyReturnValue(method = "getOptions", at = @At("RETURN"))
    private static SimpleOption<?>[] skycore$appendPackCustomSky(SimpleOption<?>[] original) {
        SimpleOption<?>[] out = Arrays.copyOf(original, original.length + 1);
        out[original.length] = SkycoreVideoPackSkyOption.get();
        return out;
    }
}
