package This.skycore.util.animation.client;

public final class ClientEasings {
    public static final ClientEasing LINEAR = t -> t;
    public static final ClientEasing CUBIC_OUT = t -> 1.0 - Math.pow(1.0 - t, 3.0);

    private ClientEasings() {
    }
}
