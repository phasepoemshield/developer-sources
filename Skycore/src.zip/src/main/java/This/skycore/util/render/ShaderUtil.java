package This.skycore.util.render;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.system.MemoryStack;
import This.skycore.SkyCore;

/**
 * Loads GLSL 150 programs from {@code assets/skycore/shaders/shadersystem/} (vertex + fragment pairs).
 */
public final class ShaderUtil {

    private static LegacyGlProgram roundedRectProgram;
    private static LegacyGlProgram circleProgram;
    private static LegacyGlProgram blurredRoundedRectProgram;
    private static LegacyGlProgram blockOutlineGlProgram;

    private ShaderUtil() {
    }

    public static void reload(ResourceManager manager) {
        dispose();
        try {
            roundedRectProgram = LegacyGlProgram.link(manager, "rounded_rectangle");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            circleProgram = LegacyGlProgram.link(manager, "circle");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            blurredRoundedRectProgram = LegacyGlProgram.link(manager, "blurred_round_rectangle");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            blockOutlineGlProgram = LegacyGlProgram.link(manager, "ovbew");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void dispose() {
        if (roundedRectProgram != null) {
            roundedRectProgram.delete();
            roundedRectProgram = null;
        }
        if (circleProgram != null) {
            circleProgram.delete();
            circleProgram = null;
        }
        if (blurredRoundedRectProgram != null) {
            blurredRoundedRectProgram.delete();
            blurredRoundedRectProgram = null;
        }
        if (blockOutlineGlProgram != null) {
            blockOutlineGlProgram.delete();
            blockOutlineGlProgram = null;
        }
    }

    public static boolean isRoundedRectangleReady() {
        return roundedRectProgram != null && roundedRectProgram.programId != 0;
    }

    public static boolean isCircleReady() {
        return circleProgram != null && circleProgram.programId != 0;
    }

    public static boolean isBlurredRoundedReady() {
        return blurredRoundedRectProgram != null && blurredRoundedRectProgram.programId != 0;
    }

    public static boolean isBlockOutlineReady() {
        return blockOutlineGlProgram != null && blockOutlineGlProgram.programId != 0;
    }

    static LegacyGlProgram roundedRectangleProgram() {
        return roundedRectProgram;
    }

    static LegacyGlProgram circleProgram() {
        return circleProgram;
    }

    static LegacyGlProgram blurredRoundedRectangleProgram() {
        return blurredRoundedRectProgram;
    }

    public static LegacyGlProgram blockOutlineProgram() {
        return blockOutlineGlProgram;
    }

    public static final class LegacyGlProgram {
        final int programId;

        LegacyGlProgram(int programId) {
            this.programId = programId;
        }

        static LegacyGlProgram link(ResourceManager manager, String fragmentName) throws IOException {
            String vertexSrc = load(manager, "vertex");
            String fragmentSrc = load(manager, fragmentName);
            int vs = compile(GL20.GL_VERTEX_SHADER, vertexSrc);
            int fs = compile(GL20.GL_FRAGMENT_SHADER, fragmentSrc);
            int program = GL20.glCreateProgram();
            GL20.glAttachShader(program, vs);
            GL20.glAttachShader(program, fs);
            GL20.glBindAttribLocation(program, 0, "Position");
            GL20.glBindAttribLocation(program, 1, "UV0");
            GL20.glLinkProgram(program);
            GL20.glDeleteShader(vs);
            GL20.glDeleteShader(fs);
            if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
                String log = GL20.glGetProgramInfoLog(program);
                GL20.glDeleteProgram(program);
                throw new IllegalStateException("Program link failed (" + fragmentName + "): " + log);
            }
            return new LegacyGlProgram(program);
        }

        private static String load(ResourceManager manager, String name) throws IOException {
            Identifier id = SkyCore.id("shaders/shadersystem/" + name + ".glsl");
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    manager.getResource(id).orElseThrow().getInputStream(), StandardCharsets.UTF_8))) {
                return reader.lines().collect(Collectors.joining("\n"));
            }
        }

        private static int compile(int type, String source) {
            int shader = GL20.glCreateShader(type);
            GL20.glShaderSource(shader, source);
            GL20.glCompileShader(shader);
            if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
                String log = GL20.glGetShaderInfoLog(shader);
                GL20.glDeleteShader(shader);
                throw new IllegalStateException("Shader compile failed: " + log);
            }
            return shader;
        }

        public  void attach() {
            GL20.glUseProgram(this.programId);
        }

          public void detach() {
            GL20.glUseProgram(0);
        }

        public  void delete() {
            if (this.programId != 0) {
                GL20.glDeleteProgram(this.programId);
            }
        }

        public   void uniformMatrix4f(String name, Matrix4f matrix) {
            int loc = GL20.glGetUniformLocation(this.programId, name);
            if (loc < 0) {
                return;
            }
            try (MemoryStack stack = MemoryStack.stackPush()) {
                FloatBuffer buf = stack.mallocFloat(16);
                matrix.get(buf);
                GL20.glUniformMatrix4fv(loc, false, buf);
            }
        }

        public  void uniform2f(String name, float x, float y) {
            int loc = GL20.glGetUniformLocation(this.programId, name);
            if (loc >= 0) {
                GL20.glUniform2f(loc, x, y);
            }
        }

        public  void uniform4f(String name, float x, float y, float z, float w) {
            int loc = GL20.glGetUniformLocation(this.programId, name);
            if (loc >= 0) {
                GL20.glUniform4f(loc, x, y, z, w);
            }
        }

        public void uniform3f(String name, float x, float y, float z) {
            int loc = GL20.glGetUniformLocation(this.programId, name);
            if (loc >= 0) {
                GL20.glUniform3f(loc, x, y, z);
            }
        }

        public void uniform1f(String name, float v) {
            int loc = GL20.glGetUniformLocation(this.programId, name);
            if (loc >= 0) {
                GL20.glUniform1f(loc, v);
            }
        }

        public void uniform1i(String name, int v) {
            int loc = GL20.glGetUniformLocation(this.programId, name);
            if (loc >= 0) {
                GL20.glUniform1i(loc, v);
            }
        }
    }
}
