package This.skycore.util.math;

import lombok.Generated;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

public final class BravoUtils {
    
    public static Vec3d getBravoBoost(LivingEntity entity) {
        if (!(entity instanceof ClientPlayerEntity)) {
            return new Vec3d(1.5D, 1.5D, 1.5D);
        }
        
        float yaw = MinecraftClient.getInstance().player.getYaw();
        float pitch = MinecraftClient.getInstance().player.getPitch();
        
        // Normalize angles exactly like in the original FireworkRocketEntity
        float normalizedYaw = yaw % 180.0F;
        if (normalizedYaw > 90.0F) {
            normalizedYaw -= 180.0F;
        } else if (normalizedYaw < -90.0F) {
            normalizedYaw += 180.0F;
        }
        
        float normalizedPitch = pitch % 180.0F;
        if (normalizedPitch > 90.0F) {
            normalizedPitch -= 180.0F;
        } else if (normalizedPitch < -90.0F) {
            normalizedPitch += 180.0F;
        }
        
        // Use exact logic from original code - this matches the "else" branch in original code
        float finalSpeedXZ = getSpeedForPitch(normalizedPitch, normalizedYaw);
        float finalSpeedY = getSpeedYForPitch(normalizedPitch);
        
        return new Vec3d((double)finalSpeedXZ, (double)finalSpeedY, (double)finalSpeedXZ);
    }
    
    private static float getSpeedForPitch(float pitch, float yaw) {
        if (Math.abs(pitch) >= 38.0F && Math.abs(pitch) <= 52.0F) {
            return 1.98F;
        } else if (Math.abs(pitch) >= 32.0F && Math.abs(pitch) <= 58.0F) {
            return 1.97F;
        } else if (Math.abs(pitch) >= 28.0F && Math.abs(pitch) <= 62.0F) {
            return 1.95F;
        } else if (Math.abs(yaw) >= 29.0F && Math.abs(yaw) <= 61.0F || Math.abs(pitch) >= 29.0F && Math.abs(pitch) <= 61.0F) {
            return 1.963F;
        } else if ((!(Math.abs(yaw) >= 27.0F) || !(Math.abs(yaw) <= 63.0F)) && (!(Math.abs(pitch) >= 27.0F) || !(Math.abs(pitch) <= 63.0F))) {
            if ((!(Math.abs(yaw) >= 22.0F) || !(Math.abs(yaw) <= 68.0F)) && (!(Math.abs(pitch) >= 22.0F) || !(Math.abs(pitch) <= 68.0F))) {
                if (Math.abs(yaw) >= 15.0F && Math.abs(yaw) <= 75.0F || Math.abs(pitch) >= 15.0F && Math.abs(pitch) <= 75.0F) {
                    return 1.7F;
                } else if ((!(Math.abs(yaw) >= 13.0F) || !(Math.abs(yaw) <= 77.0F)) && (!(Math.abs(pitch) >= 13.0F) || !(Math.abs(pitch) <= 77.0F))) {
                    if ((!(Math.abs(yaw) >= 12.0F) || !(Math.abs(yaw) <= 78.0F)) && (!(Math.abs(pitch) >= 12.0F) || !(Math.abs(pitch) <= 78.0F))) {
                        if (Math.abs(yaw) >= 8.0F && Math.abs(yaw) <= 82.0F || Math.abs(pitch) >= 11.0F && Math.abs(pitch) <= 79.0F) {
                            return 1.66F;
                        } else {
                            return (!(Math.abs(yaw) >= 5.0F) || !(Math.abs(yaw) <= 85.0F)) && (!(Math.abs(pitch) >= 8.0F) || !(Math.abs(pitch) <= 82.0F)) ? 1.621F : 1.63F;
                        }
                    } else {
                        return 1.68F;
                    }
                } else {
                    return 1.68F;
                }
            } else {
                return 1.77F;
            }
        } else {
            return 1.87F;
        }
    }
    
    private static float getSpeedYForPitch(float pitch) {
        if (Math.abs(pitch) >= 37.0F && Math.abs(pitch) <= 38.0F) {
            return 2.03F;
        } else if (Math.abs(pitch) >= 20.0F && Math.abs(pitch) <= 37.0F) {
            return 2.06F;
        } else if (Math.abs(pitch) >= 25.0F && Math.abs(pitch) <= 30.0F) {
            return 2.0F;
        } else if (Math.abs(pitch) >= 35.0F && Math.abs(pitch) <= 45.0F) {
            return 1.99F;
        } else if (Math.abs(pitch) >= 40.0F && Math.abs(pitch) <= 50.0F) {
            return 1.97F;
        } else if (Math.abs(pitch) >= 50.0F && Math.abs(pitch) <= 60.0F) {
            return 1.96F;
        } else if (Math.abs(pitch) >= 51.0F && Math.abs(pitch) <= 61.0F) {
            return 1.87F;
        } else {
            return Math.abs(pitch) >= 52.0F && Math.abs(pitch) <= 65.0F ? 1.7F : 1.59F;
        }
    }
    
    @Generated
    private BravoUtils() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}