package This.skycore.util.animation.advanced;

public enum AdvEasing {
    LINEAR(x -> x),
    BOTH_SINE(x -> -(Math.cos(Math.PI * x) - 1) / 2);

    private final AdvFunction function;

    AdvEasing(AdvFunction function) {
        this.function = function;
    }

    public double apply(double arg) {
        return function.apply(arg);
    }
}
