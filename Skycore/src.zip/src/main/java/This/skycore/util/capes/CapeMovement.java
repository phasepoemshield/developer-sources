package This.skycore.util.capes;

public enum CapeMovement {
    VANILLA,
    BASIC_SIMULATION
}

