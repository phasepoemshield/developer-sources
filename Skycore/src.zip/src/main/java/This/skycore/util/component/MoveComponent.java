package This.skycore.util.component;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import lombok.Getter;
import lombok.Setter;
import This.skycore.base.events.impl.player.EventMoveInput;
import This.skycore.util.interfaces.IClient;

public class MoveComponent implements IClient {
    @Getter
    @Setter
    private static int stopTicks = 0;

    @Getter
    @Setter
    private static boolean stop = false;

    public MoveComponent() {
        EventManager.register(this);
    }

    public static boolean isStop() {
        return stop;
    }

    @EventTarget
    public void onMoveInput(EventMoveInput event) {
        if (stopTicks > 0) {
            if (stop) {
                event.setStrafe(0.0F);
                event.setForward(0.0F);
            }
            mc.options.sprintKey.setPressed(false);
            mc.player.setSprinting(false);
            stopTicks--;
        } else if (stop) {
            stop = false;
        }
    }
}
