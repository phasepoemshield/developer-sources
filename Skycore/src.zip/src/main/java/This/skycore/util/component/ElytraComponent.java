package This.skycore.util.component;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import This.skycore.tyca1337.client.modules.impl.combat.Aura;
import This.skycore.tyca1337.client.modules.impl.combat.ElytraTarget;
import This.skycore.tyca1337.client.modules.impl.misc.FreeCam;
import This.skycore.util.game.player.rotation.Rotation;
import This.skycore.util.interfaces.IClient;
import This.skycore.util.math.Timer;

import static java.lang.Math.*;
import static net.minecraft.util.math.MathHelper.clamp;

public final class ElytraComponent implements IClient {

    public static boolean defensiveActive = false;
    public static Vec3d leaveVec = Vec3d.ZERO;
    public static Vec3d lastVec = Vec3d.ZERO;
    public static boolean predictCondition = false;
    public static boolean blockPos;
    public static Vec3d pos = Vec3d.ZERO;
    public static double value2 = 0.0;
    public static Vec3d vector = Vec3d.ZERO;

    public static LivingEntity target;

    private static int movementTicks = 0;
    private static boolean prePredictCondition = false;
    private static final Timer tickStopWatch = new Timer();

    private ElytraComponent() {
    }

    public static void updateTarget(LivingEntity entity) {
        target = entity;
    }

    public static void setVector(Vec3d vector1) {
        vector = vector1;
    }

    public static void processTargetLogic() {
        ElytraTarget elytraTarget = ElytraTarget.INSTANCE;
        if (elytraTarget == null || !elytraTarget.isEnabled() || target == null) {
            return;
        }

        float distanceValue = elytraTarget.getPredictDistance();
        float forward = distanceValue < 4.0F ? 0.0F : distanceValue - 3.0F;
        Vec3d eyePos = target.getEyePos();
        Vec3d look = target.getRotationVec(1.0F);
        pos = eyePos.add(look.normalize().multiply(distanceValue));
        Vec3d forwardPos = eyePos.add(look.normalize().multiply(forward));
        updateDistances(forwardPos);
    }

    public static void updateDistances(Vec3d point) {
        if (mc.player == null || target == null) {
            return;
        }
        float eyeDistance = (float) point.distanceTo(mc.player.getEyePos());
        float entityDistance = mc.player.distanceTo(target);
        value2 = blockPos ? eyeDistance : entityDistance;
    }

    public static void smartPredict() {
        if (!tickStopWatch.finished(50L)) {
            return;
        }

        if (target != null) {
            float x = (float) (target.getX() - target.prevX);
            float y = (float) (target.getY() - target.prevY);
            float z = (float) (target.getZ() - target.prevZ);
            float dist = (float) Math.sqrt(x * x + y * y + z * z);
            float finalSpeed = dist * 20.0F;
            if (finalSpeed > 20.0F) {
                movementTicks = 0;
                prePredictCondition = false;
                predictCondition = true;
            } else {
                movementTicks++;
                if (predictCondition) {
                    prePredictCondition = true;
                }
                if (movementTicks >= 3) {
                    predictCondition = false;
                    movementTicks = 0;
                    prePredictCondition = false;
                } else {
                    predictCondition = prePredictCondition;
                }
            }
        }

        tickStopWatch.reset();
    }

    public static void updateRotation(Vec2f current) {
        Vec3d vec3d = vector;
        if (vec3d == null || vec3d.equals(Vec3d.ZERO)) {
            return;
        }

        float rawYaw = (float) MathHelper.wrapDegrees(toDegrees(atan2(vec3d.z, vec3d.x)) - 90.0);
        float rawPitch = (float) MathHelper.wrapDegrees(toDegrees(-atan2(vec3d.y, hypot(vec3d.x, vec3d.z))));

        float currentYaw = current.x;
        float currentPitch = current.y;

        float yawDelta = MathHelper.wrapDegrees(rawYaw - currentYaw);
        float pitchDelta = MathHelper.wrapDegrees(rawPitch - currentPitch);

        if (abs(yawDelta) > 180.0F && mc.player.isSwimming()) {
            yawDelta -= signum(yawDelta) * 360.0F;
        }

        float finalDeltaYaw = MathHelper.clamp(yawDelta, -180.0F, 180.0F);
        float finalDeltaPitch = MathHelper.clamp(pitchDelta, -90.0F, 90.0F);

        float newYaw = currentYaw + finalDeltaYaw;
        float newPitch = currentPitch + finalDeltaPitch;
        float finalNewPitch = MathHelper.clamp(newPitch, -89.9F, 89.9F);
        float speedYaw = blockPos ? 9999.0F : 150.0F;
        float speedPitch = blockPos ? 9999.0F : 150.0F;

        RotationComponent.update(new Rotation(newYaw, finalNewPitch), speedYaw, speedPitch, 360.0F, 360.0F, 0, 1, false);
    }

    public static Vec3d getVector3d(LivingEntity me, LivingEntity to) {
        ElytraTarget elytraTarget = ElytraTarget.INSTANCE;
        FreeCam freeCamera = FreeCam.INSTANCE;

        if (me == null || to == null || elytraTarget == null || !elytraTarget.isEnabled()) {
            return Vec3d.ZERO;
        }

        boolean testMode = elytraTarget.isTestPredict();
        boolean pedikMode = elytraTarget.isPedikPredict();

        boolean baseChase = elytraTarget.isOvertakeEnabled()
                && mc.player.isGliding()
                && to.isGliding()
                && (freeCamera == null || !freeCamera.isEnabled());

        Vec3d result;
        boolean useChasePredictPath;

        if (baseChase && testMode) {
            useChasePredictPath = true;
            Vec3d chasePoint = pos.add(to.getRotationVec(1.0F).normalize().multiply(2.0D));
            result = new Vec3d(chasePoint.x - me.getX(), chasePoint.y - me.getY(), chasePoint.z - me.getZ());
        } else if (baseChase && pedikMode) {
            useChasePredictPath = true;
            double predictDistance = elytraTarget.getPredictDistance();
            Vec3d add = new Vec3d(0.0D, MathHelper.clamp(to.getY() - to.getHeight(), 0.0D, to.getHeight() / 2.0D), 0.0D);
            Vec3d targetPos = to.getPos().add(add);
            Vec3d playerPos = me.getEyePos();
            Vec3d motionOffset = to.getVelocity().multiply(predictDistance);
            result = targetPos.subtract(playerPos).add(motionOffset);
        } else if (baseChase && predictCondition) {
            useChasePredictPath = true;
            Vec3d chasePoint = pos.add(to.getRotationVec(1.0F).normalize().multiply(2.0D));
            result = new Vec3d(chasePoint.x - me.getX(), chasePoint.y - me.getY(), chasePoint.z - me.getZ());
        } else {
            useChasePredictPath = false;
            double wHalf = to.getWidth() / 2.0F;
            double yExpand = clamp(to.getEyeY() - to.getY(), 0.0, to.getHeight() - (mc.player.isGliding() ? 0 : 0.5F));
            double xExpand = clamp(mc.player.getX() - to.getX(), -wHalf, wHalf);
            double zExpand = clamp(mc.player.getZ() - to.getZ(), -wHalf, wHalf);
            result = new Vec3d(
                    to.getX() - mc.player.getX() + xExpand,
                    to.getY() - mc.player.getEyeY() + yExpand,
                    to.getZ() - mc.player.getZ() + zExpand
            );
        }

        blockPos = useChasePredictPath;
        return result;
    }

    public static void updateDefensiveState(LivingEntity entity) {
        defensiveActive = false;
    }

    public static void resetState() {
        defensiveActive = false;
        leaveVec = Vec3d.ZERO;
        lastVec = Vec3d.ZERO;
        pos = Vec3d.ZERO;
        vector = Vec3d.ZERO;
        blockPos = false;
    }

    public static boolean isReallyWorldChaseActive() {
        Aura aura = Aura.INSTANCE;
        ElytraTarget elytraTarget = ElytraTarget.INSTANCE;
        return elytraTarget != null
                && elytraTarget.isEnabled()
                && aura != null
                && aura.isEnabled()
                && mc.player != null
                && mc.player.isGliding()
                && target != null
                && target.isGliding()
                && elytraTarget.isOvertakeEnabled()
                && (elytraTarget.isTestPredict() || elytraTarget.isPedikPredict());
    }
}
