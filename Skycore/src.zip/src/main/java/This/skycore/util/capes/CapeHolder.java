package This.skycore.util.capes;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import This.skycore.util.capes.math.Vector2;
import This.skycore.util.capes.math.Vector3;
import This.skycore.util.capes.sim.StickSimulation;

public interface CapeHolder {
    StickSimulation getSimulation();

    default void updateSimulation(final AbstractClientPlayerEntity abstractClientPlayer, final int partCount) {
        StickSimulation simulation = this.getSimulation();

        if (simulation == null) {
            return;
        }

        final boolean dirty = simulation.init(partCount);
        if (dirty) {
            simulation.applyMovement(new Vector3(1.0f, 1.0f, 0.0f));
            for (int i = 0; i < 5; ++i) {
                this.simulate(abstractClientPlayer);
            }
        }
    }

    default void simulate(AbstractClientPlayerEntity abstractClientPlayer) {
        final StickSimulation simulation = this.getSimulation();
        if (simulation == null || simulation.empty()) {
            return;
        }
        final double d = abstractClientPlayer.prevX - abstractClientPlayer.getX();
        final double m = abstractClientPlayer.prevZ - abstractClientPlayer.getZ();
        final float n = abstractClientPlayer.prevBodyYaw + abstractClientPlayer.bodyYaw - abstractClientPlayer.prevBodyYaw;
        final double o = MathHelper.sin(n * 0.017453292f);
        final double p = -MathHelper.cos(n * 0.017453292f);
        float heightMul = (float) WaveyCapesBase.config.heightMultiplier;
        final float strafeMul = (float) WaveyCapesBase.config.straveMultiplier;
        if (abstractClientPlayer.isTouchingWater()) {
            heightMul *= 2.0f;
        }
        final double fallHack = MathHelper.clamp((abstractClientPlayer.prevY - abstractClientPlayer.getY()) * 10.0, 0.0, 1.0);
        if (abstractClientPlayer.isTouchingWater()) {
            simulation.setGravity(WaveyCapesBase.config.gravity / 10.0f);
        } else {
            simulation.setGravity((float) WaveyCapesBase.config.gravity);
        }
        final Vector3 gravity = new Vector3(0.0f, -1.0f, 0.0f);
        final Vector2 strafe = new Vector2((float) (abstractClientPlayer.getX() - abstractClientPlayer.prevX), (float) (abstractClientPlayer.getZ() - abstractClientPlayer.prevZ));
        strafe.rotateDegrees(-abstractClientPlayer.getYaw());
        final double changeX = d * o + m * p + fallHack + ((abstractClientPlayer.isSneaking() && !simulation.isSneaking()) ? 3 : 0);
        final double changeY = (abstractClientPlayer.getY() - abstractClientPlayer.prevY) * heightMul + ((abstractClientPlayer.isSneaking() && !simulation.isSneaking()) ? 1 : 0);
        final double changeZ = -strafe.x * strafeMul;
        simulation.setSneaking(abstractClientPlayer.isSneaking());
        final Vector3 change = new Vector3((float) changeX, (float) changeY, (float) changeZ);
        simulation.setGravityDirection(gravity);
        simulation.applyMovement(change);
        simulation.simulate();
    }
}

