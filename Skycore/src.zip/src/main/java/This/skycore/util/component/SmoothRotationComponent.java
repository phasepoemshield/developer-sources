package This.skycore.util.component;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.util.math.MathHelper;
import This.skycore.base.events.impl.player.EventUpdate;
import This.skycore.util.game.other.SensUtil;
import This.skycore.util.game.player.rotation.Rotation;
import This.skycore.util.interfaces.IClient;

public class SmoothRotationComponent implements IClient {
    public static SmoothRotationComponent instance = new SmoothRotationComponent();

    @Getter
    @Setter
    private RotationTask currentTask = RotationTask.IDLE;
    @Getter
    @Setter
    private float currentYawSpeed;
    @Getter
    @Setter
    private float currentPitchSpeed;
    @Getter
    @Setter
    private float currentYawReturnSpeed;
    @Getter
    @Setter
    private float currentPitchReturnSpeed;
    @Getter
    @Setter
    private int currentPriority;
    @Getter
    @Setter
    private int currentTimeout;
    @Getter
    @Setter
    private int idleTicks;
    @Getter
    @Setter
    private Rotation targetRotation = new Rotation(0.0F, 0.0F);

    public SmoothRotationComponent() {
        EventManager.register(this);
    }

    private void resetRotation() {
        Rotation resetTarget = new Rotation(FreeLookComponent.getFreeYaw(), FreeLookComponent.getFreePitch());
        if (this.updateRotation(resetTarget, this.currentYawReturnSpeed, this.currentPitchReturnSpeed)) {
            this.stopRotation();
        }
    }

    @EventTarget
    public void onEventTick(EventUpdate event) {
        if (this.currentTask.equals(RotationTask.AIM) && this.idleTicks > this.currentTimeout) {
            this.currentTask = RotationTask.RESET;
        }

        if (this.currentTask.equals(RotationTask.RESET)) {
            this.resetRotation();
        }

        ++this.idleTicks;
    }

    public static void update(Rotation target, float yawSpeed, float pitchSpeed, float yawReturnSpeed, float pitchReturnSpeed, int timeout, int priority, boolean clientRotation) {
        SmoothRotationComponent inst = SmoothRotationComponent.instance;
        if (inst.currentPriority > priority) {
            return;
        }

        if (inst.currentTask.equals(RotationTask.IDLE) && !clientRotation) {
            FreeLookComponent.setActive(true);
        }

        inst.currentYawSpeed = yawSpeed;
        inst.currentPitchSpeed = pitchSpeed;
        inst.currentYawReturnSpeed = yawReturnSpeed;
        inst.currentPitchReturnSpeed = pitchReturnSpeed;
        inst.currentTimeout = timeout;
        inst.currentPriority = priority;
        inst.currentTask = RotationTask.AIM;
        inst.targetRotation = target;
        inst.updateRotation(target, yawSpeed, pitchSpeed);
    }

    public static void update(Rotation targetRotation, float turnSpeed, float returnSpeed, int timeout, int priority) {
        update(targetRotation, turnSpeed, turnSpeed, returnSpeed, returnSpeed, timeout, priority, false);
    }

    private boolean updateRotation(Rotation targetRotation, float lazinessH, float lazinessV) {
        if (mc.player == null) {
            return false;
        }

        float yaw = this.smoothRotation(mc.player.getYaw(), targetRotation.getYaw(), lazinessH);
        float pitch = MathHelper.clamp(this.smoothRotation(mc.player.getPitch(), targetRotation.getPitch(), lazinessV), -90.0F, 90.0F);
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);

        this.idleTicks = 0;
        return new Rotation(mc.player.getYaw(), mc.player.getPitch()).getDelta(targetRotation) < 1.0F;
    }

    public void stopRotation() {
        this.currentTask = RotationTask.IDLE;
        this.currentPriority = 0;
        if (!RotationComponent.instance.isRotating()) {
            FreeLookComponent.setActive(false);
        }
    }

    public boolean isRotating() {
        return !this.currentTask.equals(RotationTask.IDLE);
    }

    private float smoothRotation(float currentAngle, double targetAngle, float smoothFactor) {
        float angleDifference = MathHelper.wrapDegrees((float)(targetAngle - currentAngle));
        float adjustmentSpeed = Math.abs(angleDifference / smoothFactor);
        float angleAdjustment = adjustmentSpeed * Math.signum(Math.signum(angleDifference));

        if (Math.abs(angleAdjustment) > Math.abs(angleDifference)) {
            angleAdjustment = angleDifference;
        }

        float sens = SensUtil.getSens(angleAdjustment);
        float gcd = SensUtil.getGCDValue();
        return currentAngle + sens - sens % gcd;
    }

    public enum RotationTask {
        AIM,
        RESET,
        IDLE
    }
}
