package This.skycore.util.math;

import lombok.Generated;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import This.skycore.util.interfaces.IClient;

public final class ReallyWorldBoostUtils implements IClient {
    
    public static Vec3d getBoost(LivingEntity entity) {
        float yaw = entity.getYaw();
        float pitch = entity.getPitch();
        
        float normalizedYaw = yaw % 180.0F;
        if (normalizedYaw > 90.0F) {
            normalizedYaw -= 180.0F;
        } else if (normalizedYaw < -90.0F) {
            normalizedYaw += 180.0F;
        }
        
        float normalizedPitch = pitch % 180.0F;
        if (normalizedPitch > 90.0F) {
            normalizedPitch -= 180.0F;
        } else if (normalizedPitch < -90.0F) {
            normalizedPitch += 180.0F;
        }
        
        float speedXZ = getSpeedForPitchRange(normalizedPitch, normalizedYaw);
        float speedY = getSpeedYForPitchRange(normalizedPitch);
        
        return new Vec3d(speedXZ, speedY, speedXZ);
    }
    
    private static float getSpeedForPitchRange(float pitch, float yaw) {
        float ay = Math.abs(yaw);
        float ap = Math.abs(pitch);
        if ((ay >= 40.0F && ay <= 50.0F) || (ap >= 40.0F && ap <= 50.0F)) return 1.80F;
        if ((ay >= 35.0F && ay <= 55.0F) || (ap >= 35.0F && ap <= 55.0F)) return 1.81F;
        if ((ay >= 30.0F && ay <= 60.0F) || (ap >= 30.0F && ap <= 60.0F)) return 1.81F;
        if ((ay >= 25.0F && ay <= 65.0F) || (ap >= 25.0F && ap <= 65.0F)) return 1.70F;
        if ((ay >= 20.0F && ay <= 70.0F) || (ap >= 20.0F && ap <= 70.0F)) return 1.70F;
        if ((ay >= 15.0F && ay <= 75.0F) || (ap >= 15.0F && ap <= 75.0F)) return 1.67F;
        if ((ay >= 10.0F && ay <= 80.0F) || (ap >= 10.0F && ap <= 80.0F)) return 1.58F;
        return 1.58F;
    }
    
    private static float getSpeedYForPitchRange(float pitch) {
        float ap = Math.abs(pitch);
        if (ap >= 45.0F && ap <= 50.0F) return 2.05F;
        if (ap >= 40.0F && ap <= 45.0F) return 2.12F;
        if (ap >= 35.0F && ap <= 40.0F) return 2.19F;
        if (ap >= 30.0F && ap <= 35.0F) return 2.15F;
        if (ap >= 25.0F && ap <= 30.0F) return 2.17F;
        if (ap >= 20.0F && ap <= 25.0F) return 1.86F;
        if (ap >= 15.0F && ap <= 20.0F) return 1.72F;
        if (ap >= 10.0F && ap <= 15.0F) return 1.72F;
        if (ap >= 5.0F && ap <= 10.0F) return 1.60F;
        return 1.63F;
    }
    
    @Generated
    private ReallyWorldBoostUtils() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}
