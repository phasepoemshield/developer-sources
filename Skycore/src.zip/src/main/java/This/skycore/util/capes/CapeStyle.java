package This.skycore.util.capes;

public enum CapeStyle {
    SMOOTH,
    SEGMENTED
}

