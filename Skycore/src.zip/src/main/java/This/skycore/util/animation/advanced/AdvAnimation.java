package This.skycore.util.animation.advanced;

import This.skycore.util.math.Timer;

public class AdvAnimation {
    private final Timer timer = new Timer();
    private int speed;
    private double size = 1;
    private boolean forward;
    private AdvEasing easing = AdvEasing.LINEAR;

    public boolean finished(boolean forwardCheck) {
        return timer.finished(speed) && (forwardCheck ? this.forward : !this.forward);
    }

    public boolean finished() {
        return timer.finished(speed) && this.forward;
    }

    public AdvAnimation setForward(boolean forward) {
        if (this.forward != forward) {
            this.forward = forward;
            timer.setMillis((long) (System.currentTimeMillis() - (size - Math.min(size, timer.getElapsedTime()))));
        }
        return this;
    }

    public AdvAnimation setEasing(AdvEasing easing) {
        this.easing = easing;
        return this;
    }

    public AdvAnimation setSpeed(int speed) {
        this.speed = speed;
        return this;
    }

    public AdvAnimation setSize(float size) {
        this.size = size;
        return this;
    }

    public float get() {
        if (forward) {
            if (timer.finished(speed)) {
                return (float) size;
            }
            return (float) (easing.apply(timer.getElapsedTime() / (double) speed) * size);
        } else {
            if (timer.finished(speed)) {
                return 0.0f;
            }
            return (float) ((1 - easing.apply(timer.getElapsedTime() / (double) speed)) * size);
        }
    }

    public void reset() {
        timer.reset();
    }
}
