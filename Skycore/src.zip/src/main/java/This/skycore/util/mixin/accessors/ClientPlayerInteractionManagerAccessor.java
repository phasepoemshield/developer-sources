package This.skycore.util.mixin.accessors;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ClientPlayerInteractionManager.class)
public interface ClientPlayerInteractionManagerAccessor {

    @Invoker("syncSelectedSlot")
    void skycore$syncSelectedSlot();

    @Accessor("lastSelectedSlot")
    int skycore$getLastSelectedSlot();

    @Accessor("lastSelectedSlot")
    void skycore$setLastSelectedSlot(int slot);
}
