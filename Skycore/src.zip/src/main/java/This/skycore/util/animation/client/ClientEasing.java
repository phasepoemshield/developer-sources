package This.skycore.util.animation.client;

@FunctionalInterface
public interface ClientEasing {
    double ease(double t);
}
