package This.skycore.util.animation.advanced;

@FunctionalInterface
public interface AdvFunction {
    double apply(double arg);
}
