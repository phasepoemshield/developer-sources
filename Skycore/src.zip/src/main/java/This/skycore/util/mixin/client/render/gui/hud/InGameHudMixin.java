package This.skycore.util.mixin.client.render.gui.hud;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.world.GameMode;
import net.minecraft.entity.player.PlayerInventory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import This.skycore.base.events.impl.render.EventRender2D;
import This.skycore.tyca1337.client.modules.api.Module;
import This.skycore.tyca1337.client.modules.impl.player.AutoTool;
import This.skycore.tyca1337.client.modules.impl.render.Crosshair;
import This.skycore.tyca1337.client.modules.impl.render.Interface;
import This.skycore.util.interfaces.IMinecraft;
import This.skycore.util.render.display.base.CustomDrawContext;

@Mixin({InGameHud.class})
public abstract class InGameHudMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   public void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (AutoTool.shouldSuppressHeldItemTooltip() && IMinecraft.mc.inGameHud != null) {
         IMinecraft.mc.inGameHud.heldItemTooltipFade = 0;
      }
      CustomDrawContext customDrawContext = new CustomDrawContext(IMinecraft.mc.getBufferBuilders().getEntityVertexConsumers());
      EventManager.call(new EventRender2D(customDrawContext, tickCounter.getTickDelta(false)));
   }

   @Inject(
      method = {"renderCrosshair"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void removeVanillaCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      try {
         Module crosshairModule = Crosshair.INSTANCE;
         if (crosshairModule.isEnabled()) {
            ci.cancel();
         }
      } catch (Exception var5) {
      }

   }

   @Inject(
      method = {"renderMainHud"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void renderMainHud(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (IMinecraft.mc.interactionManager.getCurrentGameMode() != GameMode.SPECTATOR) {
         Interface interfaceModule = Interface.INSTANCE;
         if (interfaceModule.isEnabled() && interfaceModule.isEnableHotBar()) {
            ci.cancel();
         }
      }

   }

   @Inject(
      method = {"renderExperienceLevel"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void renderExperienceLevel(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (IMinecraft.mc.interactionManager.getCurrentGameMode() != GameMode.SPECTATOR) {
         Interface interfaceModule = Interface.INSTANCE;
         if (interfaceModule.isEnabled() && interfaceModule.isEnableHotBar()) {
            ci.cancel();
         }
      }

   }

   @Inject(
      method = {"renderPlayerList"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void inject(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      Interface interfaceModule = Interface.INSTANCE;
      if (interfaceModule.isEnabled() && interfaceModule.isEnableTab()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"renderOverlayMessage"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void injectRenderOverlayMessage(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (IMinecraft.mc.interactionManager.getCurrentGameMode() != GameMode.SPECTATOR) {
         Interface interfaceModule = Interface.INSTANCE;
         if (interfaceModule.isEnabled() && interfaceModule.isEnableHotBar()) {
            ci.cancel();
         }
      }

   }

   @Inject(
      method = {"renderScoreboardSidebar*"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void injectRenderScoreboardSidebar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      Interface interfaceModule = Interface.INSTANCE;
      if (interfaceModule.isEnabled() && interfaceModule.isEnableScoreBar()) {
         ci.cancel();
      }

   }

   @ModifyVariable(
      method = {"renderStatusBars"},
      at = @At("STORE"),
      ordinal = 3
   )
   private int modifyM(int original, DrawContext context) {
      if (IMinecraft.mc.interactionManager.getCurrentGameMode() != GameMode.SPECTATOR) {
         Interface interfaceModule = Interface.INSTANCE;
         if (interfaceModule.isEnabled() && interfaceModule.isEnableHotBar()) {
            return context.getScaledWindowWidth() / 2 + 90 + 36;
         }
      }

      return original;
   }

   @Redirect(
      method = {"renderHotbar"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/entity/player/PlayerInventory;selectedSlot:I"
      )
   )
   private int skycore$autotoolVisualSelectedSlot(PlayerInventory inventory) {
      int visualSlot = AutoTool.getVisualSlot();
      return visualSlot != -1 && visualSlot < 9 ? visualSlot : inventory.selectedSlot;
   }
}
