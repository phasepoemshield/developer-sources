package This.skycore.util.interfaces;

import net.minecraft.client.MinecraftClient;

public interface IMinecraft {
   MinecraftClient mc = MinecraftClient.getInstance();

}
