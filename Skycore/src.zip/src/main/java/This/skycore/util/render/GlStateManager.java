package This.skycore.util.render;

import This.skycore.tyca1337.helpers.RenderSystem;
import org.lwjgl.opengl.GL11;

public class GlStateManager {
    
    private static final ColorState COLOR = new ColorState();
    
    @Deprecated
    public static void color4f(float red, float green, float blue, float alpha) {
        RenderSystem.assertThread(RenderSystem::isOnRenderThread);
        
        if (red != COLOR.red || green != COLOR.green || blue != COLOR.blue || alpha != COLOR.alpha) {
            COLOR.red = red;
            COLOR.green = green;
            COLOR.blue = blue;
            COLOR.alpha = alpha;
            GL11.glColor4f(red, green, blue, alpha);
        }
    }
    
    private static class ColorState {
        public float red = 1.0F;
        public float green = 1.0F;
        public float blue = 1.0F;
        public float alpha = 1.0F;
    }
}
