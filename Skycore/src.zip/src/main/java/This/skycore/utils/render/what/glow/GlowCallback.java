package This.skycore.utils.render.what.glow;

@FunctionalInterface
public interface GlowCallback {
    void render();
}