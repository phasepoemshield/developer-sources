package This.skycore.utils.svinka;

public class helper {
}
