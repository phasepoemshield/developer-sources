package This.skycore.utils.events;

import lombok.Getter;
import net.minecraft.util.math.BlockPos;
import This.skycore.base.events.callables.EventCancellable;

@Getter
public class EventBlockCollide extends EventCancellable {
    private final BlockPos pos;

    public EventBlockCollide(BlockPos pos) {
        this.pos = pos;
    }
}
