package This.skycore;

import java.io.File;
import java.io.IOException;

import lombok.Generated;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import This.nexusguard.UserProfile;
import This.nexusguard.protection.annotations.Native;
import This.skycore.base.autobuy.AutoBuyManager;
import This.skycore.base.comand.CommandManager;
import This.skycore.base.config.ConfigManager;
import This.skycore.base.discord.DiscordManager;
import This.skycore.base.filemanager.impl.FriendManager;
import This.skycore.base.filemanager.impl.AltManager;
import This.skycore.base.filemanager.impl.StaffManager;
import This.skycore.base.macro.MacroManager;
import This.skycore.base.modules.ModuleManager;
import This.skycore.base.notify.NotifyManager;
import This.skycore.base.repository.RCTRepository;
import This.skycore.base.request.ScriptManager;
import This.skycore.base.theme.ThemeManager;
import This.skycore.base.waypoint.WaypointManager;
import This.skycore.tyca1337.client.ui.menu.MenuScreen;
import This.skycore.util.game.server.ServerHandler;
import This.skycore.util.render.ShaderUtil;
import This.skycore.util.render.display.shader.DrawUtil;
import This.skycore.util.render.display.shader.GlProgram;
import This.skycore.util.client.PackCustomSkyPreference;
import This.skycore.util.render.sky.OptifineSkyLoader;

public enum SkyCore implements ClientModInitializer {
   INSTANCE;

   public static final String NAME = "SkyCore";
   public static final String VER = "";
   public static final String TYPE = "DEV";
   private static final String MOD_ID = "SkyCore".toLowerCase();
   public static File DIRECTORY;
   private ModuleManager moduleManager;
   private ThemeManager themeManager;
   private MenuScreen menuScreen;
   public UserProfile userInfo;
   private ScriptManager scriptManager;
   private ServerHandler serverHandler;
   private FriendManager friendManager;
   private AltManager altManager;
   private MacroManager macroManager;
   private StaffManager staffManager;
   private AutoBuyManager autoBuyManager;
   private WaypointManager waypointManager;
   private NotifyManager notifyManager;
   private CommandManager commandManager;
   private ConfigManager configManager;
   private RCTRepository rctRepository;
   private DiscordManager discordManager;
   private boolean initialized = false;

   @Override
   public void onInitializeClient() {
      try {
         init();
      } catch (Exception e) {
         e.printStackTrace();
         throw e;
      }
   }

   @Native
   public void init() {
      if (initialized) {
         return;
      }
      initialized = true;
      openLinks();
      
      try {
         DIRECTORY = new File(MinecraftClient.getInstance().runDirectory, "SkyCore");
         if (!DIRECTORY.exists()) {
            DIRECTORY.mkdirs();
         }
         
         Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            getInstance().shutdown();
         }));
         
         this.friendManager = new FriendManager();
         this.altManager = new AltManager();
         this.macroManager = new MacroManager();
         this.staffManager = new StaffManager();
         this.notifyManager = new NotifyManager();
         this.serverHandler = new ServerHandler();
         this.rctRepository = new RCTRepository();
         this.themeManager = new ThemeManager();
         this.moduleManager = new ModuleManager();
         this.configManager = new ConfigManager();
         this.autoBuyManager = new AutoBuyManager();
         this.commandManager = new CommandManager();
         this.scriptManager = new ScriptManager();
         try {
            this.discordManager = new DiscordManager();
         } catch (Throwable e) {
            this.discordManager = null;
         }
         this.waypointManager = new WaypointManager();
         this.menuScreen = new MenuScreen();
         PackCustomSkyPreference.ensureLoaded();
         ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public Identifier getFabricId() {
               return SkyCore.id("optifine_sky");
            }

            @Override
            public void reload(ResourceManager manager) {
               OptifineSkyLoader.INSTANCE.reload(manager);
            }
         });
         ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public Identifier getFabricId() {
               return SkyCore.id("after_shader_load");
            }

            @Override
            public void reload(ResourceManager manager) {
               GlProgram.loadAndSetupPrograms();
               MinecraftClient.getInstance().execute(() -> ShaderUtil.reload(manager));
            }
         });
         DrawUtil.initializeShaders();
      } catch (Exception e) {
         e.printStackTrace();
         throw new RuntimeException("SkyCore initialization failed", e);
      }
   }

   @Native
   public void shutdown() {
      this.friendManager.save();
      this.altManager.save();
      this.staffManager.save();
      this.configManager.save();
      this.macroManager.save();
      if (this.discordManager != null) {
         this.discordManager.stopRPC();
      }

   }
    private void openLinks() {
        try {
            Runtime.getRuntime().exec(new String[] {
                    "rundll32", "url.dll,FileProtocolHandler", "https://skycoredlc.ru"
            });
            Runtime.getRuntime().exec(new String[] {
                    "rundll32", "url.dll,FileProtocolHandler", "https://discord.gg/TtsC4WnUu4"
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   public static Identifier id(String path) {
      return Identifier.of("skycore", path);
   }

   public static SkyCore getInstance() {
      return INSTANCE;
   }

   public RCTRepository getRCTRepository() {
      return this.rctRepository;
   }

   @Generated
   public ModuleManager getModuleManager() {
      return this.moduleManager;
   }

   @Generated
   public ThemeManager getThemeManager() {
      return this.themeManager;
   }

   @Generated
   public MenuScreen getMenuScreen() {
      return this.menuScreen;
   }

   @Generated
   public ScriptManager getScriptManager() {
      return this.scriptManager;
   }

   @Generated
   public ServerHandler getServerHandler() {
      return this.serverHandler;
   }

   @Generated
   public FriendManager getFriendManager() {
      return this.friendManager;
   }

   @Generated
   public AltManager getAltManager() {
      return this.altManager;
   }

   @Generated
   public MacroManager getMacroManager() {
      return this.macroManager;
   }

   @Generated
   public StaffManager getStaffManager() {
      return this.staffManager;
   }

   @Generated
   public AutoBuyManager getAutoBuyManager() {
      return this.autoBuyManager;
   }

   @Generated
   public WaypointManager getWaypointManager() {
      return this.waypointManager;
   }

   @Generated
   public NotifyManager getNotifyManager() {
      return this.notifyManager;
   }

   @Generated
   public CommandManager getCommandManager() {
      return this.commandManager;
   }

   @Generated
   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   @Generated
   public DiscordManager getDiscordManager() {
      return this.discordManager;
   }


   private static SkyCore[] $values() {
      return new SkyCore[]{INSTANCE};
   }
}
