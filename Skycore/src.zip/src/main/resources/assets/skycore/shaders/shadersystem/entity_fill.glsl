#version 150 core

in vec2 fragCoord;

uniform sampler2D uTex;
uniform vec3 colorA;
uniform vec3 colorB;
uniform float time;
uniform float alpha;

out vec4 fragColor;

void main() {
    vec2 uv = fragCoord;
    float mixFactor = (uv.x + uv.y) * 0.5 + sin(uv.x * 8.0 + time) * cos(uv.y * 8.0 + time) * 0.2;
    mixFactor = clamp(mixFactor, 0.0, 1.0);
    vec3 finalColor = mix(colorA, colorB, mixFactor);
    float texAlpha = texture(uTex, uv).a;
    fragColor = vec4(finalColor, texAlpha * alpha);
}
