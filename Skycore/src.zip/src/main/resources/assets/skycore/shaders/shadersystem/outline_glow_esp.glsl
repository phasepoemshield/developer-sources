#version 150 core

in vec2 fragCoord;

uniform vec2 texelSize;
uniform vec2 direction;
uniform sampler2D uTex;
uniform float radius;
uniform vec3 color;

out vec4 fragColor;

#define offset direction * texelSize

void main() {
    float centerAlpha = texture(uTex, fragCoord).a;
    float innerAlpha = centerAlpha;
    for (int ri = 1; ri < 32; ri++) {
        float r = float(ri);
        if (r > radius) break;
        float alphaCurrent1 = texture(uTex, fragCoord + offset * r).a;
        float alphaCurrent2 = texture(uTex, fragCoord - offset * r).a;
        innerAlpha += alphaCurrent1 + alphaCurrent2;
    }
    fragColor = vec4(color, innerAlpha) * step(0.0, -centerAlpha);
}
