#version 150 core

in vec2 fragCoord;

uniform sampler2D uImage;
uniform float offset;
uniform vec2 resolution;

out vec4 fragColor;

void main() {
    vec2 uv = fragCoord * 2.0;
    vec2 halfpixel = resolution * 2.0 * offset;
    vec3 sum = texture(uImage, uv).rgb * 4.0;
    sum += texture(uImage, uv - halfpixel).rgb;
    sum += texture(uImage, uv + halfpixel).rgb;
    sum += texture(uImage, uv + vec2(halfpixel.x, -halfpixel.y)).rgb;
    sum += texture(uImage, uv - vec2(halfpixel.x, -halfpixel.y)).rgb;
    fragColor = vec4(sum / 8.0, 1.0);
}
