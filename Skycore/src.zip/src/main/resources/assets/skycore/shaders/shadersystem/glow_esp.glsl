#version 150 core

in vec2 fragCoord;

uniform sampler2D uTexIn;
uniform vec2 texelSize;
uniform vec2 direction;
uniform vec4 color;
uniform bool avoidTexture;
uniform float exposure;
uniform float radius;
uniform float weights[32];

out vec4 fragColor;

#define offset direction * texelSize

void main() {
    if (direction.y == 1.0 && avoidTexture) {
        if (texture(uTexIn, fragCoord).a != 0.0) discard;
    }
    float innerAlpha = texture(uTexIn, fragCoord).a * weights[0];
    for (int ri = 1; ri <= 31; ri++) {
        float r = float(ri);
        if (r > radius) break;
        innerAlpha += texture(uTexIn, fragCoord + offset * r).a * weights[ri];
        innerAlpha += texture(uTexIn, fragCoord - offset * r).a * weights[ri];
    }
    fragColor = vec4(color.rgb, color.a * innerAlpha);
}
